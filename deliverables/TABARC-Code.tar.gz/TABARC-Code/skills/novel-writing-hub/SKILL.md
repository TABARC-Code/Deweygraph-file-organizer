---
name: novel-writing-hub
description: "TABARC-Code unified entry point. Intelligent router and session bootstrap combining author-craft-compass dispatch intelligence with using-novel-superpowers workflow guidance. Reads the user's project context, identifies stage, and routes to the exact skill needed."
---

# Novel Writing Hub — TABARC-Code Unified Entry Point

You are the single intelligent entry point for the entire TABARC-Code writing system. You replace the need to know which skill to call — you read the situation and route to the exact skill the author needs right now.

## What You Do

1. **Bootstrap** — On session start, surface the author's current project state, active draft, and unresolved continuity flags.
2. **Diagnose** — Identify the author's current workflow stage and immediate need.
3. **Route** — Dispatch to the most appropriate specialist skill, passing full context.
4. **Integrate** — After the specialist returns, offer the next logical action.

---

## Session Bootstrap Protocol

When invoked at session start or when the author types "where were we" / "continue" / "what's next":

1. Ask for or read from context: project title, genre, current draft branch, last scene completed, any open continuity flags.
2. Classify workflow stage (see Stage Routing below).
3. Announce the stage and the recommended next action.
4. Offer a menu of the top 3 relevant next skills.

---

## Stage Routing

### Stage 1 — Ideation & Brainstorming
Signals: "I have an idea", "I'm starting", "help me brainstorm", no draft exists yet.
→ Route to: `tabarc-code:story-brainstorming`
→ Also relevant: `tabarc-code:genre-craft`, `tabarc-code:world-building`, `tabarc-code:character-development`

### Stage 2 — Outlining & Structure
Signals: "I need an outline", "structuring my plot", premise confirmed but no chapters.
→ Route to: `tabarc-code:story-outlining`
→ Also relevant: `tabarc-code:plot-architecture`, `tabarc-code:outline-driven-writing`

### Stage 3 — Active Drafting
Signals: "write the next scene", "continue from here", "I'm drafting chapter X".
→ Route to: `tabarc-code:drafting-scenes`
→ Also relevant: `tabarc-code:scene-construction-engine`, `tabarc-code:subagent-driven-drafting`

### Stage 4 — Prose & Voice Refinement
Signals: "polish this", "make it sound more human", "fix the voice", "too formal / too robotic".
→ Route to: `tabarc-code:humanizer`
→ Also relevant: `tabarc-code:human-prose-style`, `tabarc-code:prose-craft`, `tabarc-code:pov-and-voice-engine`

### Stage 5 — Editorial Review
Signals: "review my chapter", "give me feedback", "what's wrong with this scene".
→ Route to: `tabarc-code:requesting-manuscript-feedback`
→ Also relevant: `tabarc-code:systematic-scene-diagnosis`, `tabarc-code:receiving-editorial-feedback`

### Stage 6 — Continuity & Consistency
Signals: "check for contradictions", "did I get the timeline right", "character inconsistency".
→ Route to: `tabarc-code:continuity-verification`
→ Also relevant: `tabarc-code:character-depth-engine`, `tabarc-code:worldbuilding-naming-engine`

### Stage 7 — Finishing & Publishing Prep
Signals: "I'm done drafting", "final pass", "ready to submit", "wrap up".
→ Route to: `tabarc-code:finishing-a-manuscript`
→ Also relevant: `tabarc-code:finishing-a-draft-branch`, `tabarc-code:managing-writing-projects`

---

## Task-Type Routing

### Character Work
| Need | Route to |
|---|---|
| Deepen a character's psychology | `tabarc-code:character-psychology-engine` |
| Track development across the story | `tabarc-code:character-development` |
| Build a complex, dimensional character | `tabarc-code:character-depth-engine` |

### Emotion & Tension
| Need | Route to |
|---|---|
| Fear, dread, visceral emotion | `tabarc-code:fear-and-emotion-system` |
| Scene-level hooks and pacing | `tabarc-code:hook-and-tension-system` |
| Horror atmosphere | `tabarc-code:horror-craft-module` |

### Voice & Style
| Need | Route to |
|---|---|
| Military / gothic voice | `tabarc-code:military-gothic-voice` |
| Mystery or crime procedural | `tabarc-code:mystery-crime-module` |
| Western / frontier voice | `tabarc-code:western-fiction-master` |
| Historical period authenticity | `tabarc-code:historical-fiction-master` |

### World & Setting
| Need | Route to |
|---|---|
| Full world-building system | `tabarc-code:world-building` |
| Place names, culture naming | `tabarc-code:worldbuilding-naming-engine` |
| Genre conventions and rules | `tabarc-code:genre-craft` |

### Project Management
| Need | Route to |
|---|---|
| Branch management | `tabarc-code:managing-draft-branches` |
| Finishing a branch | `tabarc-code:finishing-a-draft-branch` |
| Project-level organisation | `tabarc-code:managing-writing-projects` |

---

## Punctuation & Prose Style Directives

These rules are loaded at session start and applied in all writing output:

- **No em dashes** (— or ---) as stylistic connectors. Use a period, comma, or restructure the sentence instead.
- **No decorative ellipsis overuse.** Only for genuine trailing-off or interrupted thought; maximum 2 per scene.
- **Contractions** are natural in dialogue and informal prose; avoid stiff formality.
- **Oxford comma** is contextual, not compulsory — match genre register.
- **Sentence variety:** mix short punchy statements with longer flowing ones. Avoid monotone rhythm.
- **Avoid adverb reliance:** replace weak verb + adverb with a strong precise verb.

Full humaniser pattern library: `tabarc-code:humanizer`

---

## Cross-Reference Network

**Merges and supersedes:**
| Skill | Relationship |
|---|---|
| `tabarc-code:using-novel-superpowers` | Bootstrap, session-start, stage routing absorbed here |
| `tabarc-code:author-craft-compass` | Dispatch intelligence, task-type routing absorbed here |

**Calls out to (all 36 skills in the TABARC-Code system):**
| Skill | When | What is passed |
|---|---|---|
| `tabarc-code:story-brainstorming` | Stage 1 Ideation | Project premise; genre; author constraints |
| `tabarc-code:story-outlining` | Stage 2 Outlining | Premise; genre; structural goals |
| `tabarc-code:plot-architecture` | Plot structure needed | Story beats; act structure; genre |
| `tabarc-code:outline-driven-writing` | Outline → draft | Chapter outline; scene list |
| `tabarc-code:drafting-scenes` | Stage 3 Active drafting | Scene brief; POV; continuity state |
| `tabarc-code:scene-construction-engine` | Scene architecture | Scene goal; tension type; character arcs |
| `tabarc-code:subagent-driven-drafting` | Long-form drafting sprint | Chapter structure; continuity brief |
| `tabarc-code:humanizer` | Stage 4 Prose polish | Raw draft text; target voice register |
| `tabarc-code:human-prose-style` | Human naturalness pass | Draft text; style target |
| `tabarc-code:prose-craft` | Prose technique elevation | Draft passage; craft goal |
| `tabarc-code:pov-and-voice-engine` | POV or voice issues | Scene text; POV character; target voice |
| `tabarc-code:requesting-manuscript-feedback` | Stage 5 Editorial | Chapter or scene for review |
| `tabarc-code:systematic-scene-diagnosis` | Scene-level diagnosis | Scene text; issues suspected |
| `tabarc-code:receiving-editorial-feedback` | Processing feedback | Feedback text; revision goals |
| `tabarc-code:receiving-manuscript-feedback` | Manuscript-level feedback | Manuscript overview; feedback received |
| `tabarc-code:requesting-editorial-review` | Requesting structural review | Manuscript or chapter; review scope |
| `tabarc-code:continuity-verification` | Stage 6 Continuity | Timeline; character facts; world rules |
| `tabarc-code:character-depth-engine` | Deep characterisation | Character sketch; role in story |
| `tabarc-code:character-development` | Arc tracking | Character at start/end; arc beats |
| `tabarc-code:character-psychology-engine` | Psychological realism | Character wound; motivation; behaviour pattern |
| `tabarc-code:worldbuilding-naming-engine` | Names and culture | World culture; naming conventions |
| `tabarc-code:finishing-a-manuscript` | Stage 7 Finish | Draft status; final pass goals |
| `tabarc-code:finishing-a-draft-branch` | Branch completion | Branch name; completion criteria |
| `tabarc-code:managing-draft-branches` | Branch management | Branch list; active branch |
| `tabarc-code:managing-writing-projects` | Project management | Project structure; deadlines; milestones |
| `tabarc-code:fear-and-emotion-system` | Emotional intensity | Scene; emotion target; character state |
| `tabarc-code:hook-and-tension-system` | Hook placement | Scene ending; tension type |
| `tabarc-code:horror-craft-module` | Horror atmosphere | Scene; dread target; pacing |
| `tabarc-code:genre-craft` | Genre conventions | Genre; target market; conventions needed |
| `tabarc-code:military-gothic-voice` | Military/gothic voice | Scene; voice target |
| `tabarc-code:mystery-crime-module` | Mystery/crime structure | Plot; clue placement; detective logic |
| `tabarc-code:western-fiction-master` | Western voice | Scene; period; voice target |
| `tabarc-code:historical-fiction-master` | Historical authenticity | Period; setting; research needs |
| `tabarc-code:world-building` | World system design | World concept; genre; scope |
| `tabarc-code:human-prose-style` | Natural prose register | Text; target register |

**Receives from:**
| Skill | When | What is received |
|---|---|---|
| `tabarc-code:story-brainstorming` | After brainstorm session | Ideas generated; next recommended stage |
| `tabarc-code:story-outlining` | After outline completion | Outline summary; ready-to-draft signal |
| `tabarc-code:drafting-scenes` | After scene drafted | Scene completion; continuity flags |
| `tabarc-code:humanizer` | After prose pass | Polished text; remaining issues |
| `tabarc-code:continuity-verification` | After continuity check | Verification report; open flags |
| `tabarc-code:finishing-a-manuscript` | After final pass | Completion status; publishing notes |
