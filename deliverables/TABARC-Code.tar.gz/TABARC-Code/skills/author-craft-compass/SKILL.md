---
name: author-craft-compass
description: >
  Use when an author wants to identify which craft skills their project needs,
  understand how skills combine and influence each other, or find the right
  entry point for their genre, stage, or weakness. Triggers on: "what skills
  do I need?", "where do I start?", "I'm writing a [genre]", "my weakness is
  [X]", "how do I improve my [X]?", "what should I work on?", or any request
  to navigate or understand the Superpowers-BookWorm craft system. Also invoke
  whenever a genre master skill is activated — this compass identifies which
  compatible craft skills should run alongside it.
---

# Author Craft Compass

The craft routing and skill-influence navigator for the Superpowers-BookWorm
system. Every significant writing project benefits from multiple skills working
together. This compass identifies which skills you need, in what order, and
which unexpected combinations will strengthen your work.

---

## Step 1 — Author Profile Assessment

Ask these five questions before making any routing recommendation. One question
per message; do not combine them.

**1. Genre and subgenre**
What are you writing? (Western, historical fiction, horror, grimdark/military,
mystery/crime, fantasy, science fiction, literary fiction, biography, memoir,
self-help, workbook, textbook, or something that spans categories)

**2. Project stage**
Where are you in the project? (Concept only / Story bible exists / Outline
complete / Actively drafting / In revision / Near completion)

**3. Core craft strength**
What do you do well? (Character work, plot/structure, prose voice, world-
building, dialogue, pacing, research)

**4. Identified weakness**
What consistently gives you trouble? (Same options as above, or: continuity,
authenticity, making prose sound human, historical accuracy, genre discipline,
pacing under pressure, revision discipline)

**5. Immediate need**
What do you need to do right now? (Design the story / Build a character /
Fix a broken scene / Draft the next chapter / Revise completed work / Understand
my genre better / Polish and finish)

After receiving answers: return the Author Profile Summary (genre, stage,
strength, weakness, immediate need) and proceed to routing.

---

## Step 2 — The Six Core Craft Principles

These principles emerge from the convergence of multiple genre and craft
traditions. They apply regardless of genre. Before routing to specific skills,
confirm which principles the author is already applying and which need attention.

**Principle 1: Research precedes writing.**
Every significant factual claim — period accuracy, genre convention, historical
detail, technical fact — must be verified before it appears in prose. This is
not a phase; it is a permanent posture. Fiction that outruns research produces
anachronism, stereotype, and broken reader trust. What you don't know shows.

**Principle 2: Constraint generates story.**
What characters cannot do, cannot say, cannot know drives conflict more
reliably than what they can. Social codes, period limitations, vocabulary
discipline, moral frameworks, genre rules, physical realities — these are not
restrictions on creativity. They are its architecture. A character liberated
from all constraint has nothing at stake.

**Principle 3: Specificity defeats generality.**
A generic character, object, or voice can exist in any era and therefore
belongs to none. The era-specific detail, the vocabulary fingerprint, the
named historical constraint, the particular weapon model, the exact coin
denomination, the period smell — these place a story in its time and make it
real. Generality is the tell of a writer who didn't look closely enough.

**Principle 4: Voice is earned through discipline.**
Authentic voice requires systematic elimination of synthetic patterns.
Vocabulary bans, structural prohibitions, multi-pass audit loops, and read-
aloud tests are not optional extras — they are the mechanism. Voice without
discipline is ventriloquism. The writer who "knows their voice" but hasn't
tested it against a constraint has not yet found it.

**Principle 5: Audit before proceeding.**
No chapter, scene, or passage moves forward without verification. Continuity,
period accuracy, voice consistency, structural integrity, and genre discipline
are checked systematically, not assumed. The cost of catching errors at the
scene level is low. The cost of discovering them at the manuscript level is
structural revision.

**Principle 6: Character carries theme.**
Theme is never stated; it lives in what characters do when the cost is highest.
The character's body, choices, and silences carry the story's meaning. Direct
statement of theme is always a revision target. What a character would die for,
refuse, and betray tells the reader everything the author believes about the
story's central question.

---

## Step 3 — Genre-to-Skill Cluster Map

Match the author's genre to their primary skill cluster. The **primary** skill
is the genre master. **Required alongside** skills are non-negotiable companions
— the genre master will not function at full strength without them. **Influence
skills** deepen and complicate the work; apply in order of identified weakness.

### Western Fiction

**Primary:** `tabarc-code:western-fiction-master`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:historical-fiction-master` | Period accuracy, research methodology, sensory texture; the Western is a period genre and must meet historical fiction's accuracy standards |
| `tabarc-code:continuity-verification` | Firearms dates, legal institutions, geography — one anachronism breaks reader trust |
| `tabarc-code:character-depth-engine` | Lawmen, outlaws, settlers require contradiction and wound — archetype without psychology is caricature |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Dialogue feels false or theatrical | `tabarc-code:pov-and-voice-engine` |
| Pacing slows in the non-action scenes | `tabarc-code:hook-and-tension-system` |
| Prose sounds generic or AI-generated | `tabarc-code:humanizer` |
| Violence lacks physical reality | `tabarc-code:fear-and-emotion-system` |
| Minority and women characters feel thin | `tabarc-code:character-development` (load western-fiction-master subskill 07 first) |

---

### Historical Fiction

**Primary:** `tabarc-code:historical-fiction-master`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:world-building` | The historical world must be built with the same discipline as invented worlds |
| `tabarc-code:continuity-verification` | Historical facts, period accuracy, character knowledge states |
| `tabarc-code:character-development` | Historical constraint must press against a fully realized inner life |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Period feels like costume, not lived reality | `tabarc-code:prose-craft` (sensory specificity section) |
| Research is overwhelming the story | `tabarc-code:plot-architecture` (returns story to character function) |
| Characters think and speak like modern people | `tabarc-code:pov-and-voice-engine` (period voice section) |
| Prose feels synthetic | `tabarc-code:human-prose-style` |
| Western-era setting specifically | `tabarc-code:western-fiction-master` |

---

### Horror and Dark Fiction

**Primary:** `tabarc-code:horror-craft-module`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:fear-and-emotion-system` | The taxonomy of fear and its physical mechanics — horror without this is shock, not dread |
| `tabarc-code:hook-and-tension-system` | Every chapter ending must escalate; tension is the engine of horror |
| `tabarc-code:character-depth-engine` | Readers fear for characters they care about — fear requires investment |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Horror becomes numbing rather than escalating | `tabarc-code:systematic-scene-diagnosis` |
| Villain lacks menace or motivation | `tabarc-code:character-psychology-engine` |
| Atmosphere thin | `tabarc-code:world-building` |
| Pacing too relentless — no release | `tabarc-code:plot-architecture` |

---

### Mystery and Crime Fiction

**Primary:** `tabarc-code:mystery-crime-module`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:plot-architecture` | Clue architecture, information economy, and fair-play structure require architectural planning |
| `tabarc-code:character-depth-engine` | The detective and the villain both need full psychological profiles — the mystery lives in who they are |
| `tabarc-code:continuity-verification` | Clue planting, suspect knowledge states, and timeline integrity are continuity problems |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Detective lacks distinctive voice | `tabarc-code:pov-and-voice-engine` |
| Tension drops between set-pieces | `tabarc-code:hook-and-tension-system` |
| Villain lacks genuine motivation | `tabarc-code:character-psychology-engine` |
| Period setting | `tabarc-code:historical-fiction-master` |

---

### Fantasy (Epic, Urban, Grimdark)

**Primary:** `tabarc-code:genre-craft` (Fantasy section) + `tabarc-code:world-building`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:worldbuilding-naming-engine` | Names and NPCs must have cultural and linguistic coherence |
| `tabarc-code:plot-architecture` | Epic scale requires airtight structural planning |
| `tabarc-code:character-development` | The world serves the characters — character profiles must precede world-building |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Grimdark voice specifically | `tabarc-code:military-gothic-voice` |
| Magic system too convenient | `tabarc-code:systematic-scene-diagnosis` (constraint audit) |
| Characters feel lost in the world | `tabarc-code:character-depth-engine` |
| World-building overwhelming story | `tabarc-code:outline-driven-writing` |

---

### Grimdark and Military Dark Fiction

**Primary:** `tabarc-code:military-gothic-voice`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:character-depth-engine` | The body-as-moral-register principle requires characters with genuine wounds and thematic weight |
| `tabarc-code:prose-craft` | Sentence-level precision is structural, not decorative, in this voice |
| `tabarc-code:pov-and-voice-engine` | Close-third interiority and FID are technical requirements of the form |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Prose sounds generic despite dark content | `tabarc-code:humanizer` |
| Bleakness without theme — nihilism | `tabarc-code:plot-architecture` |
| Dialogue lacks subtext | `tabarc-code:systematic-scene-diagnosis` |
| Setting lacks specificity | `tabarc-code:world-building` |

---

### Literary Fiction

**Primary:** `tabarc-code:genre-craft` (Literary Fiction section) + `tabarc-code:prose-craft`

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:pov-and-voice-engine` | Interiority is the primary vehicle of literary fiction |
| `tabarc-code:character-depth-engine` | Character arc and wound-to-theme connection must be complete |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Prose sounds AI-generated or generic | `tabarc-code:human-prose-style` |
| Structure too loose | `tabarc-code:plot-architecture` (literary models section) |
| Theme stated rather than embodied | `tabarc-code:character-depth-engine` |

---

### Biography, Memoir, and Narrative Nonfiction

**Primary:** `tabarc-code:genre-craft` (Biography/Memoir section)

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:character-development` | The subject is a character; the profile process applies even with a real person |
| `tabarc-code:prose-craft` | Nonfiction still requires scene construction, pacing, and dialogue management |
| `tabarc-code:continuity-verification` | Factual accuracy is a continuity problem; dates, names, and sequences must be verified |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Narrative arc missing | `tabarc-code:plot-architecture` (Nonfiction Arc section) |
| Voice sounds too formal | `tabarc-code:humanizer` |
| Research overwhelming the narrative | `tabarc-code:story-brainstorming` (scope and gist) |

---

### Self-Help, Workbooks, and Instructional Works

**Primary:** `tabarc-code:genre-craft` (Self-Help / Workbook / Textbook sections)

**Required alongside:**
| Skill | Why |
|---|---|
| `tabarc-code:plot-architecture` (Nonfiction Arc) | Reader transformation requires structural arc — where they begin and end |
| `tabarc-code:prose-craft` (Nonfiction section) | Clarity, active voice, and paragraph discipline are non-negotiable |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Voice sounds robotic or AI-generated | `tabarc-code:humanizer` |
| Reader engagement drops | `tabarc-code:hook-and-tension-system` |

---

## Step 4 — Craft Strength to Influence Map

Your strongest area tells you what to invest in next. The influence skill is not
the same as your strength — it is what will deepen and complicate it. A writer
who is strong in only one area is a writer with a dominant skill and a blind spot.

| Core strength | Your blind spot | Influence skill to add |
|---|---|---|
| Character work | Plot may not serve character; scenes may meander | `tabarc-code:plot-architecture` — scene function test disciplines character-driven work |
| Character work | Interiority may crowd out external story | `tabarc-code:hook-and-tension-system` — pacing around the interiority |
| Plot and structure | Characters may be plot functions rather than people | `tabarc-code:character-depth-engine` — wound and lie structure |
| Plot and structure | Prose may be utilitarian | `tabarc-code:prose-craft` — voice and rhythm |
| Prose and voice | Structure may be absent under beautiful prose | `tabarc-code:outline-driven-writing` — enforces the scene spec |
| Prose and voice | Prose may drift from character consciousness | `tabarc-code:pov-and-voice-engine` — POV penetration depth |
| World-building | Characters may live in the world without driving it | `tabarc-code:character-development` — character precedes world |
| World-building | Story may stall while world expands | `tabarc-code:plot-architecture` — scene function disciplines the world |
| Dialogue | Dialogue may be unanchored in body and psychology | `tabarc-code:character-depth-engine` — lie and wound driving speech |
| Dialogue | Scenes may exist only for conversation | `tabarc-code:systematic-scene-diagnosis` — scene function test |
| Research | Research may crowd out fiction | `tabarc-code:story-brainstorming` — gist and scope discipline |
| Research | Research may stay in the writer's notes | `tabarc-code:prose-craft` — sensory detail, telling object |

---

## Step 5 — Craft Weakness to Priority Map

Your weakness tells you which skill to load before the next session.

| Identified weakness | First skill to load | Second skill |
|---|---|---|
| Characters feel flat or unmotivated | `tabarc-code:character-depth-engine` | `tabarc-code:character-psychology-engine` |
| Plot feels aimless or scenes don't connect | `tabarc-code:plot-architecture` | `tabarc-code:outline-driven-writing` |
| Prose sounds generic or AI-generated | `tabarc-code:humanizer` | `tabarc-code:human-prose-style` |
| Prose sounds AI-generated specifically in fiction | `tabarc-code:human-prose-style` | `tabarc-code:prose-craft` |
| Pacing is off — too fast or too slow | `tabarc-code:hook-and-tension-system` | `tabarc-code:systematic-scene-diagnosis` |
| World feels thin or unconvincing | `tabarc-code:world-building` | Genre master for your period or setting |
| Dialogue feels unnatural or expository | `tabarc-code:pov-and-voice-engine` | `tabarc-code:prose-craft` |
| Continuity errors accumulating | `tabarc-code:continuity-verification` | `tabarc-code:managing-writing-projects` |
| Historical or period detail feels wrong | `tabarc-code:historical-fiction-master` | `tabarc-code:western-fiction-master` (if Western) |
| Voice drifts between chapters | `tabarc-code:pov-and-voice-engine` | `tabarc-code:human-prose-style` |
| Scenes don't work but I can't see why | `tabarc-code:systematic-scene-diagnosis` | `tabarc-code:outline-driven-writing` |
| Fear / tension scenes lack power | `tabarc-code:fear-and-emotion-system` | `tabarc-code:hook-and-tension-system` |
| Genre conventions not being met | `tabarc-code:genre-craft` | Genre master for your specific genre |
| Character names and world naming incoherent | `tabarc-code:worldbuilding-naming-engine` | `tabarc-code:world-building` |

---

## Step 6 — Cross-Skill Compatibility Table

When you invoke any skill, the compatible skills below should run alongside it.
Loading a skill in isolation leaves its most important lever unpulled.

| Active skill | Compatible skills to load alongside |
|---|---|
| `story-brainstorming` | `plot-architecture`, `character-development`, `world-building`, `genre-craft` |
| `story-outlining` | `plot-architecture`, `outline-driven-writing`, `continuity-verification` |
| `drafting-scenes` | `outline-driven-writing`, `prose-craft`, `continuity-verification`, `pov-and-voice-engine` |
| `subagent-driven-drafting` | `continuity-verification`, `requesting-editorial-review`, `prose-craft` |
| `character-development` | `character-depth-engine`, `character-psychology-engine`, `plot-architecture` |
| `character-depth-engine` | `character-development`, `pov-and-voice-engine`, `plot-architecture` |
| `plot-architecture` | `outline-driven-writing`, `hook-and-tension-system`, `character-development` |
| `world-building` | `worldbuilding-naming-engine`, `historical-fiction-master` (period), `genre-craft` |
| `western-fiction-master` | `historical-fiction-master`, `character-depth-engine`, `hook-and-tension-system`, `humanizer` |
| `historical-fiction-master` | `world-building`, `continuity-verification`, `character-development`, `prose-craft` |
| `military-gothic-voice` | `character-depth-engine`, `prose-craft`, `pov-and-voice-engine`, `humanizer` |
| `horror-craft-module` | `fear-and-emotion-system`, `hook-and-tension-system`, `character-depth-engine` |
| `mystery-crime-module` | `plot-architecture`, `character-depth-engine`, `continuity-verification`, `hook-and-tension-system` |
| `humanizer` | `human-prose-style`, `prose-craft`, `pov-and-voice-engine` |
| `human-prose-style` | `humanizer`, `pov-and-voice-engine`, `prose-craft` |
| `pov-and-voice-engine` | `prose-craft`, `character-depth-engine`, `human-prose-style` |
| `hook-and-tension-system` | `plot-architecture`, `systematic-scene-diagnosis`, `fear-and-emotion-system` |
| `prose-craft` | `pov-and-voice-engine`, `human-prose-style`, `outline-driven-writing` |
| `systematic-scene-diagnosis` | `outline-driven-writing`, `plot-architecture`, `receiving-editorial-feedback` |
| `continuity-verification` | `managing-writing-projects`, `drafting-scenes`, `finishing-a-manuscript` |
| `requesting-editorial-review` | `receiving-editorial-feedback`, `systematic-scene-diagnosis` |
| `finishing-a-manuscript` | `continuity-verification`, `managing-writing-projects` |

---

## Step 7 — Compatible Skill Discovery Protocol

When the author is already working with a skill and asks "what else should I
use?", apply this protocol:

**1. Identify the active skill's domain:**
- Process skill (brainstorming, outlining, drafting, finishing) → look for the
  craft skills that serve the current stage
- Genre master (western, historical, horror, mystery, military) → look for craft
  skills that serve the genre's specific demands
- Craft skill (character, plot, prose, voice) → look for skills that address the
  revealed weakness or next layer

**2. Ask what the work currently lacks:**
- "What is not working in the current draft or plan?"
- "What craft area has not been addressed yet?"

**3. Map to the compatibility table (Step 6)** and recommend the 2-3 most
   relevant compatible skills.

**4. Return the recommendation with rationale:**
- Name the skill
- State specifically what it adds that the active skill cannot provide alone
- State when to invoke it (before, during, or after the current skill)

---

## Cross-Reference Network

**Called by:**
| Skill | When |
|---|---|
| `tabarc-code:using-novel-superpowers` | Any time author needs skill routing or project orientation |
| `tabarc-code:story-brainstorming` | When genre identification drives craft routing decisions |
| `tabarc-code:western-fiction-master` | When compatible skills needed alongside the genre master |
| `tabarc-code:historical-fiction-master` | When compatible skills needed alongside the genre master |
| `tabarc-code:military-gothic-voice` | When compatible skills needed alongside the genre master |
| `tabarc-code:horror-craft-module` | When compatible skills needed alongside the genre master |
| `tabarc-code:mystery-crime-module` | When compatible skills needed alongside the genre master |
| Any skill encountering an unfamiliar weakness | When a skill discovers a craft gap outside its domain |

**Calls out to:**
All skills in the system — this compass routes to every other skill.
Routing is determined by the author profile (Step 1) and the genre-to-skill
cluster map (Step 3).

Key routing targets by weakness:
- Scene-level structural weakness → `tabarc-code:scene-construction-engine`
- Opening / pacing weakness → `tabarc-code:hook-and-tension-system`
- Character flatness → `tabarc-code:character-depth-engine`
- Prose sounds synthetic → `tabarc-code:humanizer` then `tabarc-code:human-prose-style`
- POV or voice problems → `tabarc-code:pov-and-voice-engine`

**Data received from callers:**
- Genre, stage, and craft context (where known)
- Specific craft problem being experienced (if diagnostic routing)

**Data returned to callers:**
- Recommended skill cluster with rationale
- Compatibility table entries for the active skill
- Which principles (Step 2) apply most urgently
- Ordering recommendation: which skill to load first, which alongside, which next

---

## TABARC-Code Hub Integration

**Superseded by:**
| Skill | Relationship |
|---|---|
| `tabarc-code:novel-writing-hub` | Merged entry point — dispatch intelligence absorbed into hub |
| `tabarc-code:subagent-driven-drafting` | When routing from hub | Context and routing signal |
| `tabarc-code:story-outlining` | When routing from hub | Context and routing signal |
| `tabarc-code:drafting-scenes` | When routing from hub | Context and routing signal |

**Dispatches to:**
| Skill | When | What is passed |
|---|---|---|
| `tabarc-code:novel-writing-hub` | When unified routing is needed | Craft situation; session context |
| `tabarc-code:subagent-driven-drafting` | When routing from hub | Context and routing signal |
| `tabarc-code:story-outlining` | When routing from hub | Context and routing signal |
| `tabarc-code:drafting-scenes` | When routing from hub | Context and routing signal |

| `tabarc-code:drafting-scenes` | When drafting-scenes routes here | Routing context |

| `tabarc-code:story-outlining` | When story-outlining routes here | Routing context |

| `tabarc-code:subagent-driven-drafting` | When subagent-driven-drafting routes here | Routing context |
