# TABARC-Code Novel Writing Superpowers

**Version 2.0.0** | Professional Claude Code Plugin for Authors

---

## What Is This?

TABARC-Code is a complete professional writing system built as a Claude Code plugin. It provides 37 deeply interconnected skills covering every stage of novel writing — from first idea to finished manuscript.

All skills are wired into a **bidirectional cross-reference network**: when Skill A passes context to Skill B, Skill B has a structured path back to A. You get intelligent context flow across your entire writing session.

---

## Installation

One-step install from the marketplace (Claude Code 2.1.275+):

```
/plugin install tabarc-code --marketplace TABARC-Code/TABARC-Writers
```

Or manually: copy the `TABARC-Code/` directory to your Claude Code plugins folder and restart.

---

## Quick Start

Just describe what you're doing and the unified hub routes you automatically:

- *"I have an idea for a dark fantasy novel"* → Brainstorming
- *"Write the next scene — we're at the confrontation"* → Drafting
- *"Polish this passage, it sounds too formal"* → Humanizer
- *"Check for continuity errors in chapter 4"* → Continuity Verification
- *"I need a psychological deep-dive on my antagonist"* → Character Psychology Engine

Or use the entry point directly: `novel-writing-hub`

---

## Skills (37 total)

### Entry Point (Merged Hub)
- **novel-writing-hub** — Unified router combining session bootstrap + craft dispatch

### Core Workflow
- story-brainstorming, story-outlining, plot-architecture, outline-driven-writing
- drafting-scenes, scene-construction-engine, subagent-driven-drafting
- finishing-a-draft-branch, finishing-a-manuscript

### Character & Psychology
- character-development, character-depth-engine, character-psychology-engine

### Prose & Voice
- prose-craft, human-prose-style, humanizer, pov-and-voice-engine

### Tension & Emotion
- hook-and-tension-system, fear-and-emotion-system

### Genre Specialists
- genre-craft, horror-craft-module, mystery-crime-module, military-gothic-voice
- western-fiction-master, historical-fiction-master

### World & Setting
- world-building, worldbuilding-naming-engine

### Editorial
- requesting-manuscript-feedback, requesting-editorial-review
- receiving-manuscript-feedback, receiving-editorial-feedback
- systematic-scene-diagnosis, continuity-verification

### Craft Reference
- author-craft-compass, using-novel-superpowers

### Project Management
- managing-writing-projects, managing-draft-branches

---

## Punctuation Rules (Always Active)

| Rule | Directive |
|---|---|
| Em dashes | Never use as stylistic connectors |
| Ellipsis | Max 2 per scene; only for genuine trailing off |
| Contractions | Natural in dialogue; avoid stiff formality |
| Adverbs | Strong precise verb over weak verb + adverb |
| Sentence rhythm | Mix short punchy and longer flowing sentences |

---

## Plugin by TABARC-Code
