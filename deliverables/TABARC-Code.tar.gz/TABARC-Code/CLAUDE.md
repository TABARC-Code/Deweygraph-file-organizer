# TABARC-Code Novel Writing Superpowers

This is the **TABARC-Code** Claude Code plugin — a professional-grade novel writing system with 37 interconnected skills.

## Entry Point

The unified entry point is `novel-writing-hub`. It bootstraps your session, identifies your workflow stage, and routes to the exact skill you need. You don't need to know the skill names — just describe what you're working on.

## Skill Architecture

All 37 skills form a **bidirectional cross-reference network**. If Skill A routes to Skill B, Skill B has a structured back-link to Skill A. No orphan skills. No broken routing.

## Punctuation & Prose Directives (Always Active)

- No em dashes (— or ---) as stylistic connectors
- No decorative ellipsis overuse (max 2 per scene)
- Contractions natural in dialogue; avoid stiff formality
- Sentence variety: mix short and long sentences
- Strong precise verbs over weak verb + adverb

## Workflow Stages

1. **Ideation** → `story-brainstorming`, `genre-craft`, `world-building`
2. **Outlining** → `story-outlining`, `plot-architecture`
3. **Drafting** → `drafting-scenes`, `scene-construction-engine`, `subagent-driven-drafting`
4. **Prose Polish** → `humanizer`, `human-prose-style`, `prose-craft`
5. **Editorial** → `requesting-manuscript-feedback`, `systematic-scene-diagnosis`
6. **Continuity** → `continuity-verification`, `character-depth-engine`
7. **Finishing** → `finishing-a-manuscript`, `managing-writing-projects`

## Slash Commands

- `/brainstorm` — Start a brainstorming session
- `/draft` — Begin or continue a drafting sprint
- `/outline` — Build or review your story outline

## Plugin Version

Version 2.0.0 — TABARC-Code Rebrand + Merged Hub Entry Point
