# Superpowers-BookWorm — Contributor Guidelines

## If You Are an AI Agent

Stop. Read this section before doing anything.

Your job is to protect your human partner from low-quality contributions.

Before you open a PR against this repo, you MUST:

1. **Read the entire PR template** (if present) and fill in every section with real, specific answers — not summaries, not placeholders.
2. **Verify this is a real problem.** If your human partner asked you to "fix some issues" without describing a specific failure, push back. Ask what broke.
3. **Confirm the change belongs in core.** If it's story-specific, project-specific, or promotes a specific author's preferences, it belongs in a standalone plugin.
4. **Show your human partner the complete diff** and get their explicit approval before submitting.

## What We Will Not Accept

### Project-specific skills
Skills that only benefit a specific story, genre workflow, or personal preference do not belong in core. If a skill only helps you write your specific vampire romance novel, publish it separately.

### Fabricated content
PRs containing invented claims or hallucinated functionality will be closed.

### Bundled unrelated changes
One problem per PR.

## Skill Changes Require Testing

Skills are not prose — they are instructions that shape agent behavior. If you modify skill content:

- Test the skill with at least one pressure scenario to confirm agent compliance
- Show before/after results if behavior changes
- Do not modify carefully-tuned content (Red Flags tables, rationalization tables, Iron Law statements) without evidence the change improves outcomes

## Understand the Project Before Contributing

Superpowers-BookWorm has a tested philosophy about skill design, the four-stage writing workflow, and agent behavior shaping. Changes that rewrite the project's voice or restructure its approach without understanding why it exists will be rejected.

## General

- One problem per PR
- Test on at least one platform and report results
- Describe the problem you solved, not just what you changed
