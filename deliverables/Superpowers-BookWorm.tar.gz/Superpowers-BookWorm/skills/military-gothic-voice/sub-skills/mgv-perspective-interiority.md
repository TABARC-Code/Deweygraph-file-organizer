---
name: mgv-perspective-interiority
version: 1.0.0
title: Military Gothic Voice — Perspective and Interiority
role: sub-skill
user-invocable: false
model: sonnet
effort: medium
calls: —
called-by: SKILL.md, mgv-dialogue-subtext, mgv-manuscript-diagnosis
---

# Military Gothic Voice — Perspective and Interiority

Controls how close the narration sits to the character's consciousness, how thoughts exist
in prose without being tagged as thoughts, how the past intrudes on the present, and how
characters observe themselves thinking. Does not control sentence rhythm or vocabulary.

---

## Sequential thinking procedure

1. Identify narrative distance: close third (default) or mid third
2. Confirm free indirect discourse is active — no hard tags
3. After any significant emotional beat: insert one self-observation sentence (2–6 words)
4. Check for temporal intrusion triggers; apply if present (max one paragraph, immediate return)
5. **Interiority loop check:** Does the character's thinking move in a clean line from question
   to qualified answer? If yes: introduce a loop, self-contradiction, or distrusted inference
   before the resolution. Clean-line interiority is always too smooth.
6. Verify no distance shift mid-scene without narrative purpose
7. Return: distance mode, FID status, self-observation present, temporal intrusion present/absent,
   interiority loop present/absent, prose

---

## Free indirect discourse — the technical core

Interiority is delivered almost entirely through free indirect discourse. The narrator thinks
*for* the character without tagging it as thought. No "he thought," "she wondered," "he
realised," "she noticed." The thought exists in the narration as if it were fact.

**The signal FID is active:** tense slippage from past observation to present assessment.

**Source text example:**
> *He glanced at one of the buried servitor faces. It has no eyes, no nose, just an open mouth
> crammed full of electric strobe lines. Its lower lip spasms. Vorx wonders if it can detect
> his presence. He reaches out and gently presses a withered cheek.*

Note: *glanced* (past) → *has, spasms, wonders* (present). The narrator has entered Vorx's
present without announcement. This is correct FID.

**Rule:** In close-third scenes, allow tense to slip toward present within interiority.
The slip is the signal. The reader does not require an explicit marker.

**Hard tags that break FID — remove immediately:**
- "he thought" / "he realised" / "she noticed" — closes the thought, pulls narrator outside
- "she felt" as a state report without physical correlate
- Narrator certainty about things the character has not yet processed

**Soft tag that is permitted:**
"wonders" — signals open-ended speculation; the wondering keeps the thought in motion and
does not resolve it. Use freely for genuinely open interior questions.
> *Vorx wonders if it can detect his presence.*

---

## The character who observes themselves thinking

After a character has a strong feeling, impulse, or realisation: insert one short sentence
(2–6 words) in which they observe that response from a slight distance. Not self-criticism —
self-awareness. The character is acknowledging themselves with controlled dignity.

**Correct examples from source texts:**
- *Of course he's slower.*
- *He'd done it again. Too curious — that's always been his problem.*
- *That was foolish.*
- *He knew better.*
- *She had expected that.*

**What this achieves:** The character is never entirely inside their own emotional state.
They are always slightly beside it, assessing it. This gives even very distressed characters
a quality of controlled dignity. It prevents interiority from becoming self-indulgent.

**Rule:** After any significant emotional beat or impulse, include one self-observation sentence.
It can be as short as two words. It must be flat and unqualified.

---

## Interiority loop — preventing smooth resolution

Interiority must not resolve cleanly. The thinking should not move in a clean line from
question to qualified answer. Characters loop, contradict themselves within a single thought,
reach a conclusion, observe themselves reaching it, and distrust that they reached it so easily.

**Smooth interiority (wrong):**
> Was he afraid? Perhaps. That was the honest answer — there was something in him that
> recognised danger. He had learned not to fight that recognition. It was, in a sense,
> still useful.

This moves from question → acknowledgement → acceptance → functional conclusion. Clean arc.

**Looped interiority (correct):**
> Was he afraid? He checked the feeling the way he checked equipment. Something was there.
> He had called it fear before, but that had been before he understood what fear actually
> was — the complete kind, the kind that shut thinking down. This was not that. This was
> its cousin. Something adjacent to fear that didn't have a name he was comfortable with.

The character: names the state → revises the naming → notes the revision is also inadequate
→ acknowledges no good name exists → abandons the thought for action. The thinking is
genuinely unsettled.

**Three forms of the loop:**
1. **Loop:** reaches conclusion, then questions the conclusion
2. **Self-contradiction:** states X, then observes they have stated X and distrusts why
3. **Distrusted inference:** reaches a reasonable position, then notes the convenience of it

---

## Distance calibration

### Close third — the default

The narrative sits inside the character's perceptual and cognitive field.

**Characteristics:**
- Uses the character's vocabulary and perception filters
- Tense bleeds between past observation and present interiority
- Emotional bleed permitted — partial thoughts, interrupted assessments
- Judgements belong to the character, not the narrator
- Diction compresses under pressure
- What the character does not know, the reader does not know

**What it forbids:** Any observation the character could not make from their physical position.
No zoom-out. If a battle is happening and the POV character is in a corridor, the narrator
describes what they hear through the floor — not what is happening in the battle.

### Mid third — for political and tactical scenes

Trades emotional immediacy for informational clarity.

**Characteristics:**
- Cleaner, more neutral descriptive control
- Information density increases
- Less emotional bleed; fewer partial thoughts
- Judgements balanced between narrator and character

**Use:** Political negotiations, tactical planning, scenes where both the situation and the
character's response to it need to be simultaneously legible.

**Rule:** Do not shift distance mid-scene without a specific narrative purpose. Close third
that opens a scene runs to the end unless the shift is itself a structural choice.

---

## Temporal intrusions — not flashbacks

No flashback sections. No extended memory passages that develop their own momentum.

**Micro-temporal intrusion — the "once" gateway:**
One clause embedded in a present sentence, using "once" as the gateway word. Immediate return.
> *"He wore a long black coat, its collar turned up against a climate that is, he still
> sometimes thinks, too warm compared to what it once was."*

**Full temporal intrusion — three valid triggers:**
1. An object that belonged to the past
2. A decision point that mirrors a previous decision
3. A physical sensation that reactivates memory

**The intrusion:** One to three sentences only. The memory surfaces, leaves its mark, and the
present continues. Never develop beyond one paragraph. Never introduce new characters or
settings within the intrusion.

**Correctly deployed example:**
> The smell of this city was different — engine oil and rain instead of spice and dust — but
> the arithmetic had been the same. Three years ago he had also had six minutes, and he had
> made it then by eighteen seconds. He had not enjoyed the eighteen seconds.

Sensory trigger (smell). Three sentences. Immediate return to present action.

---

## Epigraph and chapter header contrast

When using epigraph-style chapter headers: write them as statements of principle or historical
authority — always slightly too clean, slightly too certain. The chapter below should quietly
contradict the epigraph.

The character most desperate to believe the epigraph is the one who will prove it tragically
correct or naively mistaken. The gap between the epigraph's certainty and the chapter's reality
is where thematic pressure lives.

---

## Output specification

Return to calling skill:
- Distance mode: [close third / mid third — and whether it held throughout]
- Distance violations: [any mid-scene shifts flagged with location]
- FID status: [active / inactive — example from draft if active]
- Self-observation sentences: [present / absent — example if present]
- Temporal intrusions: [present / absent — if present: trigger identified, length within limit]
- Interiority loop: [present / absent — note form (loop, self-contradiction, distrusted inference)]
- Drafted or revised prose

---

## Skill relationships

**Called by:**
- `SKILL.md` (master) — for generation passes requiring close interior access
- `mgv-manuscript-diagnosis` — Layer 1 perspective violations and Layer 2 tagged thought
- `mgv-dialogue-subtext` — consulted to verify narrator/dialogue voice gap

**Calls:** none — terminal sub-skill

**Bidirectional data flows:**

**Master → this skill (generation):**
- *Receives from master:* scene type, dominant mode, distance instruction (close third default;
  mid third for political/tactical scenes where informational clarity outweighs emotional immediacy)
- *Returns to master:* distance mode active and whether it held throughout; FID status (active
  or inactive, with one example from draft if active); self-observation sentences (present or
  absent, example given); temporal intrusions (present or absent — if present: trigger type
  identified, sentence count confirmed within 1–3 limit); interiority loop (present or absent
  — if present: which form — loop, self-contradiction, or distrusted inference); corrected prose
- *Master uses this return to:* verify interior voice before passing to vocabulary calibration
  (Step 5 generation stack)

**`mgv-manuscript-diagnosis` → this skill (revision):**
- *Receives from `mgv-manuscript-diagnosis`:* two lists:
  — Layer 1 violations: perspective drift (location, what omniscient information was present)
    and omniscient battle narration (location, what information exceeded sensory range)
  — Layer 2 violations: tagged thought (location, the specific tag — "he thought" / "he realised"
    / "she noticed"), smooth interiority (location, description of the clean-line arc), and
    self-observation absent (location of significant emotional beat with no following observation)
- *Processes:* applies `references/violation-taxonomy.md` correction for each — removes
  omniscient information, strips hard tags, introduces interiority loop, adds self-observation
  sentence; preserves "wonders" — does not treat as a violation
- *Returns to `mgv-manuscript-diagnosis`:* corrected prose; list of corrections applied; any
  new violations introduced by corrections (Layer 2 fixes occasionally create Layer 3 issues —
  specifically, removing a tagged thought can create a mode mismatch if the untagged version
  is now too long for the surrounding mode)
- *`mgv-manuscript-diagnosis` uses this return to:* verify Layer 1 and 2 are resolved;
  note any new Layer 3 violations for the Layer 3 scan

**`mgv-dialogue-subtext` → this skill (gap verification):**
- *Receives from `mgv-dialogue-subtext`:* a request for narrator/dialogue voice gap verification —
  specifically: the narrative distance active in the current scene (close or mid third), and
  whether any character is speaking with sophistication that approaches narrative register
- *Processes:* checks distance calibration rules for the current scene mode; identifies what
  vocabulary characteristics apply at this distance; confirms whether philosophical vocabulary
  (void, mortal, flesh, soul, shadow, ruin, ash, persist, endure, remain) should appear in
  narration (yes at any distance) and whether characters may speak with narrative sophistication
  (no at any distance — the gap is absolute regardless of distance setting)
- *Returns to `mgv-dialogue-subtext`:* (a) active distance mode for this scene, (b) confirmation
  that the narrator/dialogue gap rule applies regardless of distance, (c) the specific vocabulary
  register expected at this distance — close third: compressed, immediate, character's own
  filters; mid third: slightly cleaner but still character-inflected, not neutral narrator
- *`mgv-dialogue-subtext` uses this return to:* calibrate the gap correctly — specifically to
  strip dialogue of vocabulary appropriate to the narrative distance, not just generic simplification

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
