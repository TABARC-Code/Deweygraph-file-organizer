---
name: mgv-thematic-engine
version: 1.0.0
title: Military Gothic Voice — Thematic Engine
role: sub-skill
user-invocable: false
model: sonnet
effort: medium
calls: mgv-vocabulary-fingerprints
called-by: SKILL.md
---

# Military Gothic Voice — Thematic Engine

Themes in this voice are not stated. They are structural — built into what characters choose
to do, what they fail to say, and what they cannot stop doing. This sub-skill identifies the
active theme, places it at the structural level, and governs the motivational architecture
that keeps characters in motion.

---

## Sequential thinking procedure

1. Identify active theme: which of the four applies? More than one may be active; identify
   primary and secondary
2. Define the character's past self and present self — the gap between them
3. Identify the motivating force: what are they acting for? At least one dead or absent person
   must be part of the motivation
4. Apply the theme via action and consequence — never via statement
5. Verify: does any character speak their own theme aloud? If so: remove or redirect to action
6. Plant one motif that can return with altered weight later
7. Consult `mgv-vocabulary-fingerprints` to verify the active vocabulary cluster matches the theme
8. Return: active theme(s), presence (stated/implicit/absent), placement recommendation,
   embedded example sentences

---

## The four active themes

These are motivational and architectural forces, not topics. Each governs a different relationship
between the character and their situation.

---

### Theme 1: Identity under erasure

Every major character is becoming something they are not sure they recognise. Physical
transformation — augmentation, decay, damage, ageing — mirrors an interior transformation.
The character must decide, repeatedly and without resolution, whether what they are becoming
is still them.

**Structural requirement:** Give the character a version of themselves they remember and a
version they currently are. The gap between those versions generates their most important
choices. The character does not resolve this gap. They act inside it.

**Vocabulary cluster that activates:**
*once, before, then, no longer, had been, the man he was, what remained, the thing he had become*

The key word is *once.* Characters in this theme are always measured against a previous version.

**Placement:** When the character acts, include one sentence or beat naming which version of
themselves they are acting from — the current or the remembered. Never have them comment on
the gap directly.

**Forbids:** The character arriving at a stable new identity. Accepting who they have become
with peace or satisfaction. The gap must persist.

---

### Theme 2: Duty without faith

Characters act in service of institutions, hierarchies, and ideals that have visibly failed
them. Not naively — they know the institution is broken. They act anyway because they have
nothing else, or because they have decided the action itself is the point.

**Source text example:**
> *"'Then I will come,' said Russ. 'I will come to cut their throats and heap the bodies — it
> will be a warm-up for the work on Mars.'"*

Russ agrees not because he believes in the principle but because it is something to do.
Action as answer to despair.

**Structural requirement:** When characters face impossible situations, do not resolve through
hope or faith. Resolve through the decision to act anyway. The reasons need not be adequate.
They need to be chosen.

**Vocabulary cluster that activates:**
*obligation, purpose, task, service, function, endure, serve, call, sworn, honoured*

**Hard prohibition:** The words *hope* and *faith* are forbidden in this theme unless being
actively undermined in the same or following sentence.

**Forbids:** Resolution through inspiration. The character finding renewed belief. An institution
rewarding the character's faith in it.

---

### Theme 3: The cost of strength

Physical power is always morally compromised. Characters are capable and dangerous because
they have paid a price that is still being paid. Any display of martial or professional
competence carries a cost — in character terms, in narrative terms, or in what the competence
forecloses.

**Structural requirement:** After a character demonstrates physical or professional power,
include one sentence or beat showing what that power has done to them or cost them. Not guilt
— consequence. Structural, embodied, ongoing.

**Placement:** The competence first. Then, without comment or explanation, the cost. A character
who kills efficiently has, somewhere in the passage, one sentence about what that efficiency
has made of them. It is an observed physical fact, not a moral observation.

**Forbids:** Martial competence described without residue. Power that costs nothing. A character
being powerful and that being straightforwardly good.

---

### Theme 4: Loyalty to the dead

More than any other motivating force, characters act for people who are no longer there.
The dead are not backstory. They are active motivation — they generate choices, constrain
options, explain behaviours that would otherwise seem irrational.

**Structural requirement:** Give characters the dead as audience. At the moment of a
significant choice, the character is acting for someone who is gone. The dead person does
not need to be named in every scene. Their weight must be felt in the specific nature of
the choice — its stubbornness, its precision, its refusal.

**Placement:** The choice arrives. The character acts in one particular way rather than another.
Why this way and not another? Because of someone gone. This does not need to be stated.
The quality of the action carries the dead person's presence.

**Forbids:** Characters acting purely from ambition or survival. Every character must have
at least one motivating thread that traces to someone they have lost.

---

## Thematic placement rules

**Rule 1:** Never state theme directly. Theme exists in action, consequence, and what is not said.

**Rule 2:** Characters do not articulate their own themes aloud — ever. A speech that states
what the scene is "about" must be cut or redirected to action.

**Rule 3:** Motifs return with altered weight. Plant a motif early. Vary it. Return it under
pressure. The return carries the accumulated weight of the variation.

**Rule 4:** Theme collision is the engine of conflict. Characters operating under different
active themes simultaneously will make incompatible choices from the same facts. That
incompatibility is the conflict.

**Rule 5:** Physical actions carry themes; speeches do not. The most thematically charged
moments in this voice are silent physical acts — a character reloading a weapon, folding a
letter along its original creases, staying in a room they could leave.

**Rule 6 — Mode constraint:** When embedding thematic content into an action passage, the
addition must be expressed at action-mode sentence length (8–18 words). Introspective-mode
sentences inserted into action passages are a mode mismatch regardless of content quality.
If the content cannot be compressed to action-mode length: paragraph break, then introspective
sentence.

---

## Motivational architecture — three requirements

Every POV character must satisfy all three before drafting:

1. **A past self:** who were they before the event or transformation that defines them now?
2. **A present self:** who are they now, and what has changed that cannot be reversed?
3. **A dead or absent motivation:** at least one force driving them traces to someone or
   something no longer present.

A character without a dead motivation will feel thin. A character whose motivations are all
present and recoverable will feel small-scale. The dead exert force across scenes without
taking up space.

---

## Worked examples — theme in action, not statement

**Duty without faith:**
> *He checked the blade. It was clean enough. It always was — he had done this enough times
> that clean was the natural outcome, and the fact of that no longer bothered him, which was
> a thing he had stopped examining.*

No statement of duty. No reference to faith. The theme is in what he has stopped doing.

**Identity under erasure:**
> *He had not looked at the gate since the last time he had stood in front of it with someone
> who was no longer available to stand in front of things.*

Past self present in "with someone." Present self defined by the absence.

**Cost of strength:**
> *Her hands were steady. They were always steady. She had stopped noting how steady they were
> sometime during the second year, because noting it had started to feel like something she
> should not be noting.*

Competence demonstrated. Cost: the specific moment she learned not to look at it.

**Loyalty to the dead:**
> Character cataloguing a destroyed place involuntarily — "counting anyway, involuntarily" —
> the dead impose this behaviour from absence. No dead person named. The loyalty is entirely
> in the involuntary action.

---

## Output specification

Return to calling skill:
- Active theme(s): [primary / secondary, from the four]
- Theme presence: [stated directly (requires revision) / implicit in action / absent (embed)]
- Specific placement recommendation: [where in the passage to embed via action]
- One or two example sentences showing the theme in physical action without commentary

---

## Skill relationships

**Called by:** `SKILL.md` (master) — receives active theme and scene type

**Calls:** `mgv-vocabulary-fingerprints` — verifies active vocabulary cluster matches the active
theme; receives confirmation that cluster words are aligned

**Bidirectional data flows:**

**Master → this skill (generation):**
- *Receives from master:* active theme label (one primary from the four, one optional secondary),
  scene type, character profile (past self — who they were before; present self — who they are
  now; dead or absent motivation — at least one identified)
- *Returns to master:* theme presence status (stated directly — requires revision; implicit in
  action — correct; absent — requires embedding); specific placement recommendation (where in
  the passage to embed the theme via physical action); one or two example sentences showing the
  theme embedded in action without commentary; confirmation that no character has articulated
  their theme aloud
- *Master uses this return to:* run the theme audit at Step 6 — checks whether the theme is
  embedded in action or stated directly; if stated, revises before proceeding to flatness
  detection

**This skill → `mgv-vocabulary-fingerprints` (cluster verification):**
- *Sends to `mgv-vocabulary-fingerprints`:* the active theme label (e.g., "duty-without-faith"
  or "identity-under-erasure") and request for the corresponding vocabulary cluster
- *Receives from `mgv-vocabulary-fingerprints`:* (a) the vocabulary cluster corresponding to
  the active theme — the complete word list for that cluster, (b) any words currently in the
  worked examples this skill has generated that conflict with the cluster (pre-empted crossover
  violations), (c) confirmation that the cluster mode restriction is compatible with the scene
  mode (e.g., duty-without-faith cluster forbids "hope" and "faith" — if those are in the scene,
  flagged)
- *Uses this return to:* adjust worked examples to use cluster-appropriate vocabulary; flag any
  scene-level violations the master should address during vocabulary calibration (Step 5)

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
