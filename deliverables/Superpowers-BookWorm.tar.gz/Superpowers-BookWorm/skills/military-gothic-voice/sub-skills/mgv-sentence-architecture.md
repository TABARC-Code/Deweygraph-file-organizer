---
name: mgv-sentence-architecture
version: 1.0.0
title: Military Gothic Voice — Sentence Architecture and Paragraph Pulse
role: sub-skill
user-invocable: false
model: sonnet
effort: medium
calls: —
called-by: SKILL.md, mgv-manuscript-diagnosis
---

# Military Gothic Voice — Sentence Architecture and Paragraph Pulse

Controls cadence, sentence length, paragraph structure, and mode calibration.
Does not control vocabulary or theme — those are handled elsewhere.

---

## Sequential thinking procedure

1. Identify the current mode from the four main modes (plus two specialist modes below)
2. Apply mode-specific sentence length constraints
3. Identify paragraph structure needed: full four-stage pulse, or abbreviated variant
4. Apply accumulate-then-strike rhythm at the sentence level
5. Integrate action and atmosphere via participial stacks — never separate them
6. Apply em dash rule (two permitted uses only)
7. **Physical anchor check (introspective mode):** For each introspective paragraph, confirm
   at least one concrete noun — body part, surface, object, sound, smell. If absent: add one.
8. **Single-line paragraph check:** Confirm any single-line paragraph serves one of three
   structural functions (see below). If used for emphasis only: restructure.
9. Return: mode identified, calibration applied, prose, mode-shift notes

---

## Mode identification — mandatory first step

Identify mode before writing a sentence. Do not mix modes within a paragraph.
Transitions between modes are abrupt. No easing in. No bridging sentence.

### Introspective / reflective mode
- **Length:** 20–45 words
- **Structure:** participial phrases, subordinate clauses, em-dash asides permitted
- **Function:** character processing experience in real time
- **Voice:** free indirect discourse throughout
- **Qualifiers:** permitted; never twice within 200 words
- **Example:** *He had learned — in the long specific silence of the years after — that the
  waiting was its own kind of work, the kind that left no visible product and asked nothing
  of the hands.*

### Action mode
- **Length:** 8–18 words
- **Structure:** subject-verb dominant; objects functional, not described
- **Function:** physical events at speed
- **Voice:** pronouns replace names; no time to identify things fully
- **Qualifiers:** zero. Any qualifier in action mode must be removed.
- **Example:** *Skarr spun his sword round, switching to a two-handed grip. He parried it away
  and leapt clear.*

### Tactical observation mode
- **Length:** 15–25 words
- **Structure:** present-tense feel even in past tense; cataloguing, professional detachment
- **Function:** character assessing a situation
- **Voice:** one sentence per observation; move on immediately
- **Example:** *Skarr studied the descent carefully, noting the quickest routes down.*

### Revelation / emotional climax mode
- **Length:** 2–8 words; often fragments; often bare nouns
- **Function:** terminus — all preceding paragraphs collapse to this point
- **Deployment:** once per significant scene at most; never for general dramatic emphasis
- **Example:** *Live. Survive. A place will be found.* or *Get. Out.* or *Survive.*

### Action mode — rout variant
- **Length:** 40–70 words in a single sentence
- **Function:** loss of tactical control; the sentence length enacts the disintegration
- **Internal structure:** tripling ("sliding and skidding and dropping"), accumulating
  abandonment ("leaving weapons, leaving shields, dropping it all, forgetting it all")
- **Deployment:** one per scene; genuine rout/overwhelm context only; never for emphasis
- **Critical:** Do not break into short sentences. The length IS the meaning.

### Historical / record mode
- **Length:** 25–50 words; past-perfect dominant
- **Structure:** archival, procedural; dates, proper nouns, institutional facts
- **Function:** biography of an environment — reveals what it has become vs what it was
- **Voice:** narrator withdraws from POV entirely; cool, ironic gap between record and reality
- **Deployment:** for significant locations, ships, or institutions; one per work

---

## The accumulate-then-strike rhythm

Core sentence unit. Build pressure; release flatly.

**Pattern A (long-to-short):**
Two to four sentences of increasing complexity, then a flat sentence of four to eight words.
Do not soften the final sentence with a qualifier. Let it land.

> He had been at the edge of this kind of decision before — not once or twice but enough times
> that it had its own texture, its own particular quality of silence in the chest. He had
> learned, in those previous moments, that the thinking was never the hard part. *Acting was.
> It always was.*

**Pattern B (short-to-long):**
Fragment or bare noun opens; expansion arrives; cut ends.

> *Pain.* That was all that remained. Sometimes a dull, throbbing ache, distributed evenly
> across his body. Other times, they made it sharp and sudden. *It all depended on her mood.*

Both patterns work. The cut is always flat and unqualified.

**Short-short-long variant (punch after buildup):**
> *The humiliation of it. The raw, unbearable humiliation. That was the worst wound, far worse
> than any physical flesh-breaking.*

Fragment → expanded fragment → explanatory sentence. Functions as an inverse accumulate-then-
strike — short-short-long achieves the same release from a different direction.

---

## The four-stage paragraph pulse

Use in introspective and narrative paragraphs. Action paragraphs may use Entry-Cut only.
Over any three consecutive paragraphs, all four stages must appear across the set.

**Stage 1 — Entry:** Short declarative, often a fragment. Establishes POV and stakes.
Begins the paragraph — does not set it up.

**Stage 2 — Expansion:** Two to four sentences of building complexity. Atmosphere, interior
thought, setting detail — all embedded in action, not in separate blocks.

**Stage 3 — Complication:** One sentence that cuts against the expansion. A doubt, an
interruption, a physical detail that does not fit. Does not need to be dramatic.

**Stage 4 — Cut:** Three to five words where possible. Ends the movement. Never uses
"perhaps," "maybe," or any softening qualifier.

**Example from source text:**
> *"He is beginning to remember now."* — Entry
> *"He is beginning to piece things together again. Is he slower now than he once was?"*
> — Expansion with interior question
> *"The Little Lord starts to lick the blood from his cracked ceramite."* — Complication
> *"Of course he's slower. Everything is slowing down, congested, like running through water.
> That's the Gift, of course."* — Cut

**Anti-mechanical rule:** Never write three consecutive paragraphs with identical pulse shape.
After two full pulses: vary — end mid-expansion, open with complication, or run two expansions
before complicating. The pulse is a tool, not a template.

**Cross-skill mode constraint:** When adding thematic content or emotional weight to an action
passage, the addition must be expressed in action-mode sentence length (8–18 words).
Introspective-mode sentences inserted into action passages without a clear structural break
are a mode mismatch regardless of content quality. If the content cannot be compressed to
action-mode length: paragraph break first, then introspective sentence.

---

## The participial stack

Never separate action from atmosphere into distinct sentences. Atmosphere lives in the grammar
of motion.

**Wrong:**
> He ran. The corridor was dark. Voices shouted behind him.

**Right:**
> He ran, his boots slipping in the dark corridor's filth, the voices behind him closing
> faster than he'd allowed for.

**Method:** Subject acts → secondary physical detail via participial phrase → tertiary detail
layered in. Each layer deepens without slowing. The sentence moves at the speed of the action.

**Limit:** Three participial layers maximum. Four becomes a list.

---

## Chapter openings — in motion

Open at least three beats into the scene. Do not establish who, where, or why before the
character is in action. Setting arrives in the gaps between beats. First-paragraph disorientation
is correct. Clarity arrives through momentum.

The first sentence must contain a verb doing actual work — not a verb of being or having.

**Deferred subject identification:** Subject can be withheld for significantly longer when the
character's psychological state is itself the content. The opening of *Ashes of the Imperium*
runs five paragraphs ("Now run. Run hard. Nothing else exists...") before the subject is named.
The anonymous urgency is the content; naming the subject would anchor what must stay raw.

Use when the character's state (panic, fugue, decisive momentum) would be diluted by pausing
to identify who they are. The moment of naming arrives when the character regains coherence —
which is itself a narrative event.

**Degree scale:**
- Standard: three beats in; subject clear by paragraph two
- Extended: five to eight beats; named by paragraph three
- Extreme: five-plus paragraphs unnamed; requires genuine psychological urgency; naming carries weight

---

## Single-line paragraphs — three structural functions only

**Function 1 — Crystallisation terminus:** All preceding paragraphs have built toward this
point. The conclusion collapses the weight to a single sentence. Most powerful use.

**Function 2 — Rhythm beat in counting or enumeration:** Within a sequence where a character
counts or enumerates, single-line entries mark the beats. The prose between paragraphs fills
the spaces.

**Function 3 — Interruption of interior by exterior action:** A physical event breaks into an
introspective passage and is registered as a single-line paragraph before narration adjusts.

**Prohibition:** Never for dramatic emphasis, atmospheric intensification, or to make a sentence
feel important. Reserve entirely for structural function.

**Frequency:** Once every three to four pages at most.

---

## Em dash — two permitted uses, three hard bans

**Permitted 1 — Narrator commentary within attribution:**
> *'It can be restored,' he said — not a decision, so much as an acknowledgement of what had
> already been decided.*

**Permitted 2 — Subordinate clarification within a long introspective sentence:**
> *He had learned — in the years after the second collapse, in the long specific silence of
> it — that waiting was a skill like any other.*

**Banned 1 — Dramatic pause:** ~~She turned — and stopped.~~
**Banned 2 — Trailing effect:** ~~He had nothing left —~~
**Banned 3 — Emotional intensification:** ~~He was afraid — genuinely afraid.~~

**Frequency cap:** One em dash per paragraph maximum.
**Mode restriction:** Introspective mode only. Never in action mode sentences.

---

## Output specification

Return to calling skill:
- Mode identified: [specify from the six modes; note rout variant, historical, or extended
  fragment mode if used]
- Sentence length calibration applied: [word range for this mode]
- Physical anchor confirmation: [introspective passages — concrete noun confirmed per paragraph]
- Single-line paragraph function: [crystallisation / rhythm beat / interruption / none used]
- Drafted or revised prose
- Mode-shift notes: [any transitions — were they abrupt or soft? soft = flag for revision]

---

## Skill relationships

**Called by:** `SKILL.md` (master), `mgv-manuscript-diagnosis` (Layer 3 corrections)

**Calls:** none — terminal sub-skill

**Bidirectional data flows:**

**Master → this skill (generation):**
- *Receives from master:* dominant mode (action/introspection/tactical/revelation), scene type,
  approximate length target, confirmation of whether rout context applies
- *Returns to master:* mode confirmed from the six modes, sentence length range applied,
  physical anchor confirmation (one concrete noun per introspective paragraph confirmed or added),
  single-line paragraph function declared, prose draft, mode-shift note (abrupt or soft;
  soft transitions flagged for revision)
- *Master uses this return to:* verify rhythm is calibrated before passing draft to theme audit
  (Step 6) and style gate (Step 7)

**`mgv-manuscript-diagnosis` → this skill (revision):**
- *Receives from `mgv-manuscript-diagnosis`:* Layer 3 violation list — each item specifies:
  violation type (mode mismatch / missing cut / separated action-atmosphere / annotated action
  beat / em dash misuse), sentence or paragraph location (quoted under ten words), current word
  count if mode mismatch, required correction from `references/violation-taxonomy.md`
- *Processes:* applies the taxonomy correction for each violation type; preserves any rout
  sentence if context is genuine overwhelm (documented in return)
- *Returns to `mgv-manuscript-diagnosis`:* corrected prose passage; list of corrections applied
  with any decisions made (e.g., rout sentence preserved with justification); any new violations
  introduced by the corrections (Layer 2 or 4 only — sentence-level fixes cannot introduce
  structural violations)
- *`mgv-manuscript-diagnosis` uses this return to:* verify Layer 3 is resolved; log any new
  violations before proceeding to Layer 4

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
