# Military Gothic Voice — Activation Prompts
## Tested invocation patterns

These prompts specify what the system needs to know and what it determines for itself.
Adapt the bracketed fields to the scene. Do not fill in the emotional state — let it emerge.

---

## Prompt 1: The character who keeps going

For scenes where the core is a character acting without adequate reason — duty without faith,
loyalty to the dead, cost of strength.

> Write a scene in which a character who has lost the thing that gave their actions meaning
> continues to act anyway. They do not explain why. The setting is [X]. The action is [Y].
> Use short sentences for action, long sentences for interiority. The character should observe
> themselves thinking at least twice. The environment should reflect the historical condition
> of the place, not the character's emotional state.

**Specify in [X]:** A physical location with history — a ship, a ruined city, a corridor they
have been in before. The history should be implied by the condition, not stated.

**Specify in [Y]:** A concrete physical task, not a goal. Cleaning a weapon. Crossing ground.
Giving an order they do not believe in. The meaning is in what they do not say about why.

---

## Prompt 2: The disagreement that doesn't state itself

For dialogue-primary scenes with political charge — command structures, characters with
incompatible loyalties, Inquisition scenes.

> Write a dialogue scene between two characters who disagree. Neither should state their
> disagreement directly. Use agreement to signal conflict. Response sentences should be shorter
> than the lines they answer. No adverb attribution. At least one exchange should hinge on what
> is not said. One exchange should use Rule 4b: a character agrees while correcting the premise
> they are being assumed to agree on.

**Specify:** Who the two characters are, what each wants from the exchange, and what neither
will say aloud. The silence is the subject of the scene.

**Leave to the system:** Specific beats, action beats replacing attribution, subtext gap.

---

## Prompt 3: The chapter opening in motion

For starting a new chapter or section, particularly one involving action, pursuit, or a
character moving toward something uncertain.

> Write a chapter opening. Begin three beats into the action — do not establish setting before
> establishing the character in motion. Let the world arrive through the gaps in the action.
> The POV character is [in the process of recovering from something / moving towards something
> they are not sure they should do]. Do not explain who, where, or why before beginning.
> Clarity arrives through momentum.

**Advanced — deferred subject identification:** If the character is in extreme psychological
distress (panic, fugue, decisive momentum under collapse), defer naming the subject for five
or more paragraphs. The moment of naming should carry narrative weight — it arrives when the
character regains coherence.

**Specify:** The physical action the character is performing, and whether they are recovering
from something or moving toward something uncertain.

---

## Prompt 4: Diagnosis and revision

For existing prose that needs assessment and correction toward this voice.

> Diagnose this passage. Identify: current mode (action / introspection / tactical / revelation),
> narrative distance (close third / mid third), and all violations by layer — structural first,
> then voice, then sentence mechanics, then vocabulary. List what is working and must be
> preserved. Then apply corrections in layer order. Use the violation taxonomy as primary tool
> for each correction.
>
> [PASTE PASSAGE]

**Add for targeted revision:** Specify which layer or which specific violation type to focus
on. "Focus on the dialogue exchanges only." "The interiority is smooth — prioritise the loop
check." "The action beats are annotating themselves."

---

## Notes on invocation

**Specify physical facts, not emotional states.** Tell the system what the character is doing
and where. The emotional content should emerge from action and thematic architecture.
Specifying emotion produces stated emotion — a violation.

**Name the setting register when known.** For Warhammer 40K, specify which register: Death
Guard, Space Marine/Iron Hands, or Inquisition. For Warhammer Fantasy, specify Military or
Political. For unknown settings, the system will collect a brief automatically.

**Name the active theme only if not obvious from the scene.** If the character has lost
something and is still acting, the system identifies duty-without-faith or loyalty-to-dead
without being told. Override only when the scene might imply the wrong theme.

**Name the silence.** Every significant scene in this voice has a silence at its centre —
something no character will say, something the prose will build around. Name that silence in
the invocation and the system will build correctly.

**The most important technical specification:** which sentence mode the scene is in. Action,
introspective, tactical, or revelation. Mixed scenes: specify dominant and secondary.
