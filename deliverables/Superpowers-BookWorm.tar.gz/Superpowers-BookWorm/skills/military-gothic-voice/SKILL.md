---
name: military-gothic-voice
version: 1.0.0
title: Military Gothic Voice — Complete Prose System
role: orchestrator
user-invocable: true
model: sonnet
effort: high
calls: mgv-sentence-architecture, mgv-vocabulary-fingerprints, mgv-perspective-interiority, mgv-dialogue-subtext, mgv-world-building, mgv-thematic-engine, mgv-manuscript-diagnosis
called-by: user
description: >
  Applies a complete military gothic prose voice to any fiction across any setting. Use when
  the user wants: grimdark voice, dark military fiction, aftermath-driven interiority, close-third
  POV with self-observing characters, maximum dialogue subtext, environment as structural mirror,
  body-as-moral-register, duty-without-faith themes, formal gravity paired with raw physical
  specificity. Triggers on: "grimdark voice," "dark military fiction," "psychological interiority,"
  "close third POV," "write in a dark precise style," "military gothic," "write like serious
  fantasy fiction," "write in this voice," or any request to generate or revise prose toward
  this register. Entry point for the full sub-skill ecosystem. Covers generation, revision, and
  diagnosis modes.
---

# Military Gothic Voice — Complete Prose System

Master orchestrator. All generation and revision routes through this skill. The user never
calls sub-skills directly.

---

## Three foundational truths

These are not stylistic preferences. They are the structural laws of this voice. Every
technique in the system exists to serve them.

**Truth 1: Writing from inside aftermath.** Characters are not experiencing events — they are
*surviving* events, carrying everything that already happened into every present moment. The
past is not behind characters. It is *in* them, pressing outward. This is not backstory
technique. It is permanent narrative posture.

**Truth 2: The universe is indifferent and the individual is not.** Characters care with
painful intensity — about duty, identity, memory, the dead — inside a cosmos that does not
reciprocate. This tension drives everything. It is why the bleakness never tips into nihilism.
Someone always still cares. Someone always keeps going for reasons they can barely articulate.

**Truth 3: The body as moral register.** Physical states — decay, damage, pain, augmentation —
are never merely descriptive. They externalise interior moral and spiritual conditions. When
writing in this voice, the body is always a text to be read. The Iron Hands' metal hands are
self-disgust made literal. The Death Guard's rot is theological commitment made flesh.

---

## Mode detection — first step

Identify which mode applies before selecting sub-skills.

| Mode | Signal | First action |
|---|---|---|
| **Generation** | User wants new prose | Configure stack from routing table |
| **Revision** | User has existing prose to improve | `mgv-manuscript-diagnosis` first |
| **Diagnosis** | User wants to know what's wrong | `mgv-manuscript-diagnosis` only |
| **Setting onboarding** | Unknown setting or world | Collect setting brief before generation |

For revision and diagnosis: always run `mgv-manuscript-diagnosis` first. Revision by inference
misses structural violations that require sequenced correction.

---

## Setting check — second step before generation

Determine whether the setting is known or unknown.

**Known settings** with confirmed vocabulary registers (see `references/setting-registers.md`):
- Warhammer 40,000: Death Guard/Chaos, Space Marine (loyal), Inquisition/political
- Warhammer Fantasy (Empire): Military/campaign, Political/court

**Unknown or original settings:** ask the user for: setting name, POV character name,
faction/group, opponent faction (if conflict present), key world-specific terms with physical
descriptions. Maximum five questions. Assemble as a setting brief and pass to
`mgv-world-building` and `mgv-vocabulary-fingerprints` before generation.

Do not invent terminology. Do not proceed without a setting brief for unknown settings.

---

## Generation stack — configuration order

Configure in sequence. One or two sub-skills primary. The rest govern by constraint.

1. **Sentence mode** — which of the four modes? (`mgv-sentence-architecture`)
2. **Interiority depth** — how close to the character's consciousness? (`mgv-perspective-interiority`)
3. **Dialogue presence** — is speech primary? (`mgv-dialogue-subtext`)
4. **World density** — setting terminology load? (`mgv-world-building`)
5. **Thematic pressure** — which theme is active? (`mgv-thematic-engine`)
6. **Vocabulary calibration** — cluster check (`mgv-vocabulary-fingerprints`)

---

## Task routing table

| Task | Primary sub-skill | Secondary |
|---|---|---|
| Draft action sequence | `mgv-sentence-architecture` | `mgv-world-building` |
| Draft introspective passage | `mgv-perspective-interiority` | `mgv-vocabulary-fingerprints` |
| Draft dialogue scene | `mgv-dialogue-subtext` | `mgv-perspective-interiority` |
| Draft chapter opening | `mgv-sentence-architecture` | `mgv-perspective-interiority` |
| Build environment | `mgv-world-building` | `mgv-vocabulary-fingerprints` |
| Embed theme | `mgv-thematic-engine` | `mgv-vocabulary-fingerprints` |
| Vocabulary audit | `mgv-vocabulary-fingerprints` | `mgv-perspective-interiority` |
| Full scene generation | all sub-skills in sequence | — |
| Diagnose existing prose | `mgv-manuscript-diagnosis` | — |
| Revise existing prose | `mgv-manuscript-diagnosis` | relevant sub-skills per findings |

---

## Generation procedure — sequential thinking chain

Execute in strict order. Do not combine steps.

**Step 1 — Setting check**
Confirm setting brief is loaded. If unknown setting: collect brief (max five questions).
Pass to `mgv-world-building` and `mgv-vocabulary-fingerprints`.

**Step 2 — Mode identification**
Identify dominant sentence mode: action / introspection / tactical / revelation.
Mixed scenes: identify dominant and secondary. Pass to `mgv-sentence-architecture`.

**Step 3 — Theme identification**
Identify active theme: identity-under-erasure / duty-without-faith / cost-of-strength /
loyalty-to-dead. One primary, one optional secondary. Pass to `mgv-thematic-engine`.

**Step 4 — Stack configuration**
Select primary and secondary sub-skills from routing table above.

**Step 5 — Draft**
Execute using configured stack: sentence architecture → perspective/interiority → dialogue
(if present) → world/environment (if present) → theme → vocabulary.

**Step 6 — Theme audit**
After draft: does the active theme appear in action and consequence, or is it stated directly?
Does any character speak their own theme aloud? Does any paragraph resolve through hope or faith
without qualification? If yes to any: revise before proceeding.

**Step 7 — Style gate**
Run `references/style-checklist.md`. Any unchecked box is a revision pass.

**Step 8 — Output**
Return: setting brief status, active sub-skill stack (2–3 lines), drafted prose, post-draft
note (one risk, one suggested next beat).

---

## Revision procedure — sequential thinking chain

**Step 1 — Diagnosis**
Pass prose to `mgv-manuscript-diagnosis`. Do not touch prose before this completes.

**Step 2 — Preserve**
Identify and protect passages flagged as working. Revision works around these, not through them.

**Step 3 — Layered correction**
Structural violations first → voice violations → sentence mechanics → vocabulary. Do not apply
surface corrections to prose with unresolved structural violations.

**Step 4 — Style gate**
Run `references/style-checklist.md`.

---

## Absolute prohibitions — any of these present means stop and revise

- Omniscient narration beyond POV character's direct sensory range
- Ellipsis for emotional effect
- Em dash for dramatic pause, trailing effect, or emotional intensification
- Nature directly reflecting character's feelings (pathetic fallacy)
- Characters articulating their own themes aloud
- Hope or faith stated without immediate qualification
- "he felt X" without a following observation that complicates X
- Adverb-modified dialogue attribution
- Philosophical vocabulary (void, mortal, flesh, soul, shadow, ruin) in dialogue
- Action beats that explain what they mean

---

## Output format

1. Setting brief status: loaded / collected / confirmed
2. Active sub-skill stack: 2–3 lines
3. Drafted or revised prose
4. Post-draft note: one remaining risk, one next beat

---

## Skill relationships

**Called by:** user — sole entry point

**Calls:**
- `sub-skills/mgv-sentence-architecture.md` — rhythm, cadence, paragraph pulse, mode calibration
- `sub-skills/mgv-vocabulary-fingerprints.md` — vocabulary clusters, qualifier deployment, narrator/dialogue gap
- `sub-skills/mgv-perspective-interiority.md` — FID, distance, self-observation, temporal intrusion
- `sub-skills/mgv-dialogue-subtext.md` — subtext mechanics, attribution, exchange rhythm
- `sub-skills/mgv-world-building.md` — setting terminology, environment, battle scenes
- `sub-skills/mgv-thematic-engine.md` — thematic structure, motivational architecture
- `sub-skills/mgv-manuscript-diagnosis.md` — mandatory for all revision and diagnosis

**Bidirectional data flows:**

*Master sends to each sub-skill on invocation:*
- → `mgv-sentence-architecture`: dominant mode, scene type, approximate length target, whether rout context applies
- → `mgv-vocabulary-fingerprints`: active scene mode, active vocabulary cluster label, setting brief key terms for cluster extension
- → `mgv-perspective-interiority`: scene type, dominant mode, distance instruction (close or mid third)
- → `mgv-dialogue-subtext`: scene type, whether dialogue is primary or supporting, whether scene is major (Rule 3 mandatory) or minor
- → `mgv-world-building`: confirmed setting brief, scene type, whether conflict is present
- → `mgv-thematic-engine`: active theme label (primary and optional secondary), scene type, character profile (past self / present self / dead motivation)
- → `mgv-manuscript-diagnosis`: input prose, task mode (revision or diagnosis), scene context if known

*Each sub-skill returns to master:*
- ← `mgv-sentence-architecture`: mode confirmed, calibration applied, physical anchor confirmation, single-line paragraph function, prose draft, mode-shift note
- ← `mgv-vocabulary-fingerprints`: cluster confirmed, qualifier scan results, violations corrected, corrected prose
- ← `mgv-perspective-interiority`: distance mode, FID status with example, self-observation presence, temporal intrusion check, interiority loop status, corrected prose
- ← `mgv-dialogue-subtext`: subtext failures, rules applied, attribution violations, voice gap violations, Rule 3 status, revised dialogue
- ← `mgv-world-building`: setting terms with qualifiers, environment approach, conflict within intimacy rule; blocking signal if setting brief absent
- ← `mgv-thematic-engine`: theme presence status (stated/implicit/absent), placement recommendation, embedded examples
- ← `mgv-manuscript-diagnosis`: diagnostic summary, violation list with layers/severity/locations, preserve list, revised prose, post-revision note

*What master does with each return:*
- `mgv-sentence-architecture` return: verifies rhythm before theme audit (Step 6) and style gate (Step 7)
- `mgv-vocabulary-fingerprints` return: confirms vocabulary calibrated before style gate
- `mgv-perspective-interiority` return: verifies interior voice before vocabulary calibration
- `mgv-dialogue-subtext` return: verifies dialogue quality before theme audit
- `mgv-world-building` return: confirms world elements grounded; if blocking signal: initiates setting brief collection
- `mgv-thematic-engine` return: uses theme presence status to run Step 6 theme audit — if theme is stated rather than embedded, revises before proceeding
- `mgv-manuscript-diagnosis` return: in revision mode, uses violation list to select which correction sub-skills to invoke per layer; in diagnosis mode, presents findings to user

*Setting brief routing:*
Master (not world-building) passes setting brief key terms to `mgv-vocabulary-fingerprints` for cluster extension alongside the vocabulary cluster label from `mgv-thematic-engine`.

---

## Incoming from compatible skills

| Source | When | Data received |
|---|---|---|
| `superpowers-bookworm:author-craft-compass` | When grimdark or military gothic voice is recommended for the project | Author profile: genre, stage, weakness; compatible skill cluster |
| `superpowers-bookworm:genre-craft` | When grimdark fantasy or dark military fiction is the identified genre | Genre identified; reader contract established |
| `superpowers-bookworm:character-depth-engine` | When a character's wound/lie/flaw profile is available for interiority architecture | Character profile: wound, lie, body condition |
| `superpowers-bookworm:pov-and-voice-engine` | When close-third POV configuration is needed before generation | POV distance instruction; FID readiness |

## Calls out to

| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:humanizer` | When grimdark or military prose sounds synthetic after voice generation | Draft passage; voice context (mode, scene type, dominant register) |
| `superpowers-bookworm:prose-craft` | When sentence-level precision is needed beyond the sub-skill scope | Active scene mode; register; voice target |
| `superpowers-bookworm:scene-construction-engine` | When a scene's interiority architecture needs to be built before the voice can be applied | Scene type; dominant mode; character wound/body condition |
