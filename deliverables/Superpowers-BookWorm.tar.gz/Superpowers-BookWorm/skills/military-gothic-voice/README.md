# Military Gothic Voice — Complete Prose System

**Package name:** `military-gothic-voice`
**Version:** 1.0.0
**Entry point:** `SKILL.md`
**User-invocable skills:** `SKILL.md` only. All sub-skills are internal engines.
**Source document:** Forensic style assessment across four books spanning three settings.

---

## What this is

A complete prose generation and revision system for military gothic fiction. Built directly
from forensic corpus analysis of four books. Covers all registers: introspective, combative,
political, and philosophical.

The three foundational truths that govern all choices:
1. Writing from inside aftermath — characters are surviving events, not experiencing them
2. The universe is indifferent and the individual is not — someone always still cares
3. The body as moral register — physical states externalise moral and spiritual conditions

---

## Package structure

```
military-gothic-voice/
├── SKILL.md                          ← MASTER SKILL — only entry point
├── README.md                         ← this file
│
├── references/
│   ├── style-checklist.md            ← final gate before returning any prose
│   ├── violation-taxonomy.md         ← wrong / right / correction for every violation type
│   ├── setting-registers.md          ← four confirmed registers + cross-setting constants
│   └── activation-prompts.md         ← four tested invocation patterns with notes
│
└── sub-skills/
    ├── mgv-sentence-architecture.md  ← rhythm, cadence, modes, paragraph pulse
    ├── mgv-vocabulary-fingerprints.md ← clusters, qualifier tics, narrator/dialogue gap
    ├── mgv-perspective-interiority.md ← FID, distance, self-observation, temporal intrusion
    ├── mgv-dialogue-subtext.md       ← subtext rules, attribution, exchange rhythm
    ├── mgv-world-building.md         ← setting terminology, environment, battle scenes
    ├── mgv-thematic-engine.md        ← thematic architecture, motivational requirements
    └── mgv-manuscript-diagnosis.md   ← diagnosis and revision; mandatory for all edits
```

---

## Call graph

| Sub-skill | Called by | Calls |
|---|---|---|
| `SKILL.md` (master) | user | all seven sub-skills |
| `mgv-sentence-architecture` | master, `mgv-manuscript-diagnosis` | — |
| `mgv-vocabulary-fingerprints` | master, `mgv-manuscript-diagnosis`, `mgv-thematic-engine` | — |
| `mgv-perspective-interiority` | master, `mgv-manuscript-diagnosis`, `mgv-dialogue-subtext` | — |
| `mgv-dialogue-subtext` | master, `mgv-manuscript-diagnosis` | `mgv-perspective-interiority` |
| `mgv-world-building` | master, `mgv-manuscript-diagnosis` | — |
| `mgv-thematic-engine` | master | `mgv-vocabulary-fingerprints` |
| `mgv-manuscript-diagnosis` | master | `mgv-perspective-interiority`, `mgv-dialogue-subtext`, `mgv-vocabulary-fingerprints`, `mgv-sentence-architecture` |

---

## Task routing

| Task | Primary sub-skill | Secondary |
|---|---|---|
| Draft action sequence | `mgv-sentence-architecture` | `mgv-world-building` |
| Draft introspective passage | `mgv-perspective-interiority` | `mgv-vocabulary-fingerprints` |
| Draft dialogue scene | `mgv-dialogue-subtext` | `mgv-perspective-interiority` |
| Draft chapter opening | `mgv-sentence-architecture` | `mgv-perspective-interiority` |
| Build environment | `mgv-world-building` | `mgv-vocabulary-fingerprints` |
| Embed theme | `mgv-thematic-engine` | `mgv-vocabulary-fingerprints` |
| Vocabulary audit | `mgv-vocabulary-fingerprints` | `mgv-perspective-interiority` |
| Full scene | all sub-skills in sequence | — |
| Diagnose existing prose | `mgv-manuscript-diagnosis` | — |
| Revise existing prose | `mgv-manuscript-diagnosis` | relevant sub-skills per findings |

---

## Generation procedure (summary)

1. Setting check — brief loaded or collected (max five questions for unknown settings)
2. Mode identification — action / introspection / tactical / revelation
3. Theme identification — identity-under-erasure / duty-without-faith / cost-of-strength /
   loyalty-to-dead
4. Stack configuration — select sub-skills from routing table
5. Draft — sentence architecture > perspective > dialogue > world > theme > vocabulary
6. Theme audit — is theme in action, or stated? Revise if stated.
7. Style gate — `references/style-checklist.md`; unchecked box = revision pass
8. Output — setting status, active stack, prose, one risk, one next beat

---

## Revision procedure (summary)

1. `mgv-manuscript-diagnosis` — full violation scan
2. Preserve identification — flag what works
3. Layered correction — structural > voice > mechanics > vocabulary
4. Style gate — `references/style-checklist.md`

---

## Reference files

| File | When to read |
|---|---|
| `references/style-checklist.md` | Final gate — before every return to user |
| `references/violation-taxonomy.md` | Step 5 of every revision — primary correction tool |
| `references/setting-registers.md` | When active setting is one of the four known registers |
| `references/activation-prompts.md` | When composing an invocation for a new scene type |

---

## Version history

| Version | Date | Changes |
|---|---|---|
| 1.0.0 | 2026-04-12 | Initial build from forensic corpus analysis. Seven sub-skills, four reference files. Full sequential procedures, bidirectional backlinks, feedback logs. |
