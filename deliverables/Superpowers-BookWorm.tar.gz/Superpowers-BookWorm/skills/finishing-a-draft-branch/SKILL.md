---
name: finishing-a-draft-branch
description: Use when experimental draft branch work is complete and a decision about integration is needed. Verifies the branch, presents four structured options (merge, keep, review, discard), and handles cleanup. Triggers on: "I'm done with this experiment", "the alternate ending is written", "this draft branch is complete", or on completion of any managing-draft-branches session.
---

# Finishing a Draft Branch

## Core Idea

Guide completion of experimental draft work by presenting clear options and handling the chosen workflow. The experiment is done — decide what to do with it.

## Core Principle

Verify the experiment is complete → Present options → Execute choice → Clean up.

**Announce at start:** "I'm using the finishing-a-draft-branch skill to complete this draft branch."

## The Process

### Step 1 — Verify the draft branch is complete

Run continuity verification on the experimental draft:
- `superpowers-bookworm:continuity-verification` against the branch content
- Check that the experiment addressed what it set out to address

If continuity errors are present:
```
Continuity issues found in this draft branch before integration:
[List issues]

Resolve before proceeding with any merge or submission.
```
Stop. Don't proceed to Step 2.

If complete: Continue.

### Step 2 — Determine the working draft base

```bash
git merge-base HEAD draft-main 2>/dev/null || git merge-base HEAD main 2>/dev/null
```

### Step 3 — Present exactly these 4 options

```
Draft branch complete. What would you like to do?

1. Merge into working draft — replace the relevant sections in the main draft
2. Keep as alternate — preserve branch; don't merge; useful for comparison or later use
3. Submit for editorial review — dispatch editorial-reviewer subagent on this branch
4. Discard — this experiment didn't work

Which option?
```

### Step 4 — Execute choice

**Option 1: Merge into working draft**
```bash
git checkout [draft-main]
git pull
git merge draft/[branch-name]
# Verify continuity log integrity after merge
```
Then run `superpowers-bookworm:continuity-verification` on merged result.
Then clean up branch (Step 5).

**Option 2: Keep as alternate**
Report: "Keeping draft branch [name] at .draft-branches/[name]. Branch preserved for comparison."
Do NOT clean up.

**Option 3: Submit for editorial review**
Dispatch editorial-reviewer subagent per `superpowers-bookworm:requesting-editorial-review`.
Use the branch content, not the working draft.
After review: return to Step 3 with notes.

**Option 4: Discard**
Confirm first:
```
This will permanently delete:
- Branch: draft/[branch-name]
- All work in .draft-branches/[branch-name]
- Commits: [list]

Type 'discard' to confirm.
```
Wait for exact confirmation.
If confirmed:
```bash
git checkout [draft-main]
git branch -D draft/[branch-name]
```
Then clean up worktree (Step 5).

### Step 5 — Clean up worktree (for Options 1 and 4 only)

```bash
git worktree remove .draft-branches/[branch-name]
```

## Quick Reference

| Option | Merge | Review | Keep Worktree | Cleanup Branch |
|--------|-------|--------|---------------|----------------|
| 1. Merge | Yes | — | — | Yes |
| 2. Keep | — | — | Yes | — |
| 3. Review | — | Yes | Yes | — |
| 4. Discard | — | — | — | Yes (force) |

## Red Flags

- Merge without verifying continuity
- Automatic discard without confirmation
- Presenting more or fewer than 4 options
- Skipping continuity check on merge result

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:managing-draft-branches` | When experimental draft work is complete | Branch name, what the experiment addressed |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:continuity-verification` | Before any merge or submission — mandatory first step | Branch content; continuity log |
| `superpowers-bookworm:requesting-editorial-review` | Option 3: submit branch for review | Branch chapter content; story bible summary |
| `superpowers-bookworm:managing-writing-projects` | After merge (Option 1) — archive the integration | Merged branch name; draft version |

**Returns:**
- One of four outcomes: merged / kept as alternate / submitted for review / discarded
- For merge: continuity verification on merged result
- For discard: explicit author confirmation received before deletion
- Worktree cleaned up (Options 1 and 4)
