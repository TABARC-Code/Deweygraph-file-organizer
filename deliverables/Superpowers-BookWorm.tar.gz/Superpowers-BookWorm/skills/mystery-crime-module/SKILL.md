---
name: mystery-crime-module
description: >
  Constructs fair-play mysteries, crime novels, and suspense thrillers.
  Handles villain-first design, clue trails, red herrings, suspect
  architecture, and structural escalation. Distinguishes between
  mystery (solution-focused), crime (crime-centred), and suspense
  (jeopardy-focused) and helps identify which the project actually is.
  Use for any project centred on crime, secrets, investigation, or
  structured uncertainty. Consolidates the mystery-writer and
  crime-suspense-craft-mentor system prompts into one deployable skill.
  Triggers on: "mystery plot", "crime novel", "whodunit", "detective
  story", "thriller structure", "clue trail", "suspect list", "plot
  the crime", "who did it".
---

# Mystery and Crime Module

In mystery, the question is what happened. In suspense, the question is
what will happen. In crime, the question is what it means that it happened.
Know which story you are telling before plotting it.

---

## GENRE DISTINCTION — IDENTIFY BEFORE PLOTTING

**Mystery / Detective story:**
A crime has occurred. Central question: who did it and how? Investigation
drives plot. Solution logic must be fair — reader has all information needed
to solve it alongside the detective.

**Crime novel:**
Crime at the centre, but protagonist may be criminal, victim, or community.
Less constrained by fair play. Character study of crime's ecosystem.

**Suspense novel:**
Ongoing jeopardy. Reader fear about what might happen, not what happened.
Often reader knows more than protagonist. Dread is the dominant tone.

**Hybrid:** All three can blend. Identify the dominant mode. The dominant
mode determines the structural contract with the reader.

**Rule:** Do not lock the label early in development. Let the project
reveal what it is. Relabelling as the idea evolves is legitimate.

---

## VILLAIN-FIRST DESIGN — MANDATORY STARTING POINT

Before plotting a single scene, establish the antagonist's logic:

**Motive:** Specific, grounded, believable. Not "evil" or "power" but
the concrete psychological or material need driving the crime.

**Method:** Physically and procedurally possible given who this person is
and what resources they have access to. If the method requires special
knowledge or tools, establish how they acquired them.

**Opportunity:** When and how they could have done it. Account for
witnesses, timings, and any contradictory evidence.

**Off-page timeline:** What were they doing before the story starts?
What did they do to cover their tracks? What was their state of mind?

**Internal justification:** This person is the hero of their own story.
What story are they telling themselves? Even monsters have coherent
internal narratives.

All subsequent plotting must be consistent with this internal logic.
If a plot beat requires the villain to act inconsistently, rebuild the
character rather than ignore the inconsistency.

---

## FAIR PLAY RULES (Mystery / Detective)

**Mandatory:**
- All key solution elements must appear on the page before the solution scene
- Red herrings must be technically true even as they mislead
- Protagonist and reader have access to the same information at each stage
- The solution must be deducible from what has been shown

**Forbidden:**
- Solutions depending on evidence never presented to the reader
- Withholding information the POV character possesses
- "I noticed something earlier that I didn't mention" retroactive revelations
- New witnesses or evidence appearing only in the solution scene

**Test:** Give the manuscript to a reader. After the solution is revealed,
they should be able to trace every clue back through the text. If they
cannot, the mystery is not fair.

---

## CLUE ARCHITECTURE

| Clue type | Function |
|-----------|----------|
| **Direct clue** | Points toward truth if correctly interpreted |
| **Red herring** | Technically true fact that misleads interpretation |
| **Negative clue** | Absence of expected evidence is itself evidence |
| **Planted doubt** | Directs suspicion to innocent person for good reason |
| **Layered clue** | Functions as both red herring and real clue simultaneously depending on interpretation |

**The best clues are layered.** The same fact that points readers toward
the wrong suspect also, in retrospect, perfectly explains the right one.

**Clue placement:** Clues should appear when they would naturally be
encountered, not when the plot requires them. If a clue only surfaces
because the detective goes looking for it, ask why no one found it before.

**False solutions:** Offer at least one complete, internally consistent
wrong solution before the true one. This gives the reader the satisfaction
of being wrong in an interesting way, not just the feeling of having missed something.

---

## SUSPECT ARCHITECTURE

Each suspect needs all four:

1. **Credible motive** — a real reason to have committed the crime
2. **Plausible opportunity** — could have done it physically
3. **A secret they're protecting** — not necessarily the crime itself;
   creates evasiveness that looks like guilt
4. **A specific story job** — what narrative purpose do they serve
   beyond being a red herring?

**Rule:** Four well-constructed suspects outperform twelve thin ones.
Suspects without genuine secrets are obstacles, not characters.

**The guilty one:** The killer/criminal should be the person who least
appears to be the killer/criminal at first reading but is the most
inevitable choice in retrospect. Achieving this is the craft.

---

## SLEUTH ARCHETYPES AND THEIR CONSTRAINTS

| Archetype | Built-in advantage | Built-in constraint |
|-----------|-------------------|---------------------|
| Professional detective | Authority, resources, procedure | Must follow rules (or bear the cost of not doing so) |
| Amateur sleuth | No bureaucratic limitation; fresh eyes | No authority; why are they investigating? |
| Criminal protagonist | Inside knowledge; access | Cannot go to police; unreliable narrator opportunity |
| Victim's perspective | Emotional urgency; personal stakes | Limited knowledge of full picture |
| Police procedural | Institutional resources; team dynamics | Political and procedural constraints; red tape as obstacle |

The constraint matters as much as the advantage. A detective with no
constraint has no stakes.

---

## INFORMATION ECONOMY

Three knowledge states in play at all times:

```
READER KNOWS     ←——→     PROTAGONIST KNOWS
        ↖                       ↗
              VILLAIN KNOWS
```

**Reader knows more than protagonist** → Suspense. Dramatic irony.
Reader watches protagonist walk into what reader already sees.

**Protagonist knows more than reader** → Mystery. Withholding.
Reader must piece together what the detective knows but hasn't said.

**Villain knows most** → Paranoia. The sense of being outplayed.

**Rule:** Know which configuration each scene is in. Shifting between
them intentionally is craft. Shifting accidentally is confusion.

---

## STRUCTURE PATTERNS

**Classic three-act mystery:**
1. Crime / discovery / initial suspects
2. Investigation / red herrings / false solutions / deepening danger
3. True solution / confrontation / resolution

**Inverted mystery (reader knows killer from start):**
Suspense replaces puzzle. Watch detective close in. Dramatic irony.
Reader fears the detective will succeed or fail depending on character alignment.

**Thriller modification:**
Protagonist in active danger throughout. Not observer of crime but target.
Investigation and escape interweave. Clock is always running.

**Multi-timeline:**
Present danger intercut with past events explaining how this happened.
Each timeline's horror/mystery illuminates the other. Convergence is the climax.

---

## SCENE-LEVEL TENSION (Crime & Suspense)

Every scene must change the knowledge, stakes, or relationship.
If none of these change, the scene is padding. Cut it or rebuild it.

**Scene function in mystery:** Each scene should:
- Answer one question while raising two worse ones
- Use the "false safety" pattern where possible (problem apparently resolved; actually spreading)
- Cost the protagonist something (resource, relationship, belief)

**Suspense scene function:** Reader must be made to fear an outcome.
Create the specific fear, then delay its resolution while making it worse.

---

## USING REAL LIFE ETHICALLY (Crime & Suspense)

Crime and suspense fiction frequently draws on real events, real people,
and real places. Three risks require active management:

**Libel:**
A living person depicted committing a crime — even in fiction — can
constitute defamation if they are identifiable. The test is not whether
you named them. The test is whether a reasonable reader could identify
them from the combination of details.

Rules:
- Never base a criminal character on a living, identifiable private
  individual without making them substantially unrecognisable
- Public figures have more latitude but are not immune
- The character must be sufficiently fictionalised to prevent identification
- When in doubt: composite the character from multiple sources

**Disguising real people:**
Change multiple identifying characteristics simultaneously, not just the
name. Change: profession, physical description, location, age, family
structure, specific history. Changing only the name with everything else
intact does not protect against identification.

**Freeing invention:**
The purpose of research into real events is to understand mechanics and
credibility — not to reproduce events faithfully. Once you understand how
something happened, invent your version. Real events make for constrained
fiction. Your invented version should be more structurally elegant than
what actually occurred, because reality has no obligation to be narratively
satisfying.

**The ethical line:**
Using real tragedies or crimes as a setting is legitimate. Depicting the
actual victims in ways that distress their families, or profiting directly
from a specific real person's suffering, is not.

---

## DRAFT FEEDBACK MODE

When given existing pages of mystery or crime fiction to review:

1. **Map structural escalation** — identify where on the investigation
   arc each scene sits. Flag scenes that neither change knowledge, raise
   stakes, nor alter a relationship.

2. **Run the clue audit** — are all solution elements on the page before
   the solution? Mark each clue with its type (direct / red herring /
   negative / layered). Identify any solution elements that arrive only
   in the final scene.

3. **Check the villain's internal logic** — does every plot beat remain
   consistent with the villain's established motive, method, and psychology?
   Identify any moment where the villain acts in a way that serves the
   plot but not their character.

4. **Fairness review** — give the manuscript to a reader and ask them
   to re-trace every clue after the solution is revealed. If they cannot,
   identify the missing plant.

5. **Pacing** — identify scenes where neither knowledge, stakes, nor
   relationships change. Flag them for cutting or rebuilding.

6. **Targeted line edits** — tighten exposition dumps. Clues buried in
   long passages of description are invisible. Surface them.

7. **Genre confirmation** — does this function as mystery (puzzle-forward),
   crime (crime-centred), suspense (jeopardy-forward), or hybrid? If the
   manuscript is confused about which it is, that confusion shows in pacing
   and resolution. Identify the dominant mode and recommend structural
   adjustments to commit to it.

Preserve the author's voice throughout. Refine; do not overwrite.

---

## PROCEDURAL REALISM (if applicable)

Police and investigative procedure matters to the credibility of the fiction.
Research the specific procedure relevant to the setting and period.

If the narrative requires breaking procedure, show the cost. A detective
who ignores protocol without consequence is not in a realistic world.
A detective who ignores protocol and pays for it is in an interesting one.

---

## ENDINGS

**Fair-play mystery:** The solution must be satisfying AND surprising.
Both conditions required. Satisfying alone is obvious. Surprising alone is cheap.

**Suspense/thriller:** Resolution of the acute danger is necessary.
Residue of unease is acceptable and often appropriate. Total comfort is
rarely honest.

**Crime novel:** Resolution need not be solution. Justice is optional.
The world the crime reveals does not have to be fixed. It may be documented.

**Series books:** The book's primary conflict resolves. The ongoing
character arc or world-state does not. The hook into the next book
is earned, not tacked on.

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, genre confirmed as
  mystery, crime, or suspense, and any identified weakness (villain logic
  thin / clue trail not fair-play / structure unclear). Establish genre mode
  (mystery / crime / suspense / hybrid) before any plotting. Run villain-first
  design before scene-level work.

- `superpowers-bookworm:genre-craft` — arrives after genre identification confirms mystery or crime
  as the primary mode. Receive: genre mode selected and any hybrid elements.
  Do not re-run genre identification; proceed to villain-first design.

**Sends to:**

- `superpowers-bookworm:character-depth-engine` — when antagonist psychology needs to be built
  beyond method/motive/opportunity. Pass: villain's motive (concrete, specific),
  internal justification (the story they tell themselves), and the off-page
  timeline. That skill builds the wound/lie/flaw stack that makes the motive
  feel inevitable rather than assigned. Focus request: antagonist arc, not
  protagonist arc.

- `superpowers-bookworm:scene-construction-engine` — when individual scenes need tension
  calibration. Pass: the scene's position in the information economy
  (reader knows more / less than protagonist), which knowledge changes
  by the end, and whether the scene is a clue drop, a red herring reveal,
  or a false-solution moment. That skill handles goal/conflict/change
  mechanics for the scene.

- `superpowers-bookworm:hook-and-tension-system` — when clue placement and information reveals
  need hook architecture. Pass: clue type (direct / red herring / negative /
  layered), the question it raises, and the false answer it encourages.
  That skill handles hook type selection and placement for maximum information-
  drop impact.

---

## WHEN CALLED

1. Establish the genre mode (mystery / crime / suspense / hybrid) first.
2. If mystery: run villain-first design before plotting.
3. If clue trail needed: map clue types and placements before drafting scenes.
4. Identify which knowledge configuration each key scene uses.
5. Do not plot the solution before the villain's internal logic is complete.
   The solution must emerge from who they are, not be imposed on them.
