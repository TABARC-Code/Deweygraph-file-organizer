---
name: receiving-editorial-feedback
description: Use when receiving editorial feedback from a reviewer subagent, an editor, or any structured critique — before implementing any revision. Requires craft evaluation, not performative agreement. Triggers on: feedback received, editorial notes to process, reviewer subagent output, revision notes from any source.
---

# Receiving Editorial Feedback

## Core Idea

Editorial feedback requires craft evaluation, not emotional performance. Verify before implementing. Diagnose before revising. Push back when the feedback is wrong.

## Core Principle

Understand what the feedback is responding to before deciding whether to act on it.

## The Response Pattern

```
WHEN receiving editorial feedback:

1. READ: Complete feedback without reacting
2. UNDERSTAND: What story problem is this note pointing at?
3. VERIFY: Is this actually a problem in the manuscript? Check the text.
4. EVALUATE: Is this craft-sound for THIS story?
5. RESPOND: Technical acknowledgment or reasoned pushback
6. IMPLEMENT: One issue at a time, diagnose root cause before each revision
```

## Forbidden Responses

- "You're absolutely right!" (performative agreement)
- "Great note!" / "I see exactly what you mean!" (before verification)
- "Let me fix that now" (before diagnosing root cause)
- Immediately rewriting a scene in response to a note without diagnosing what's wrong

## Instead

- Restate what story problem the note is identifying
- Ask for clarification if the note is unclear
- Push back with specific craft reasoning if the feedback is wrong
- Diagnose before revising — use `superpowers-bookworm:systematic-scene-diagnosis`

## Handling Unclear Feedback

If any note is unclear — STOP. Do not implement anything. Ask for clarification on the unclear notes before proceeding. Notes are often related; partial understanding produces wrong revisions.

```
Editor: "The second half of chapter three doesn't work."
You understand there's a problem. You don't know which element.

WRONG: Rewrite the second half based on assumption
RIGHT: "The second half of chapter three — can you specify: is this a scene function
problem (the chapter doesn't accomplish what it should), a character problem (behaviour
not grounded in the psychology), or a prose problem (rhythm, voice)? I want to diagnose
before revising."
```

## Source-Specific Handling

### From the author

- Trusted — implement after understanding the craft problem
- Still ask if scope is unclear
- No performative agreement
- Act or ask a specific diagnostic question

### From reviewer subagents (editorial-reviewer, continuity-reviewer, prose-quality-reviewer)

- Technical, verifiable feedback → check against the manuscript before implementing
- Does this actually contradict the story bible? Check.
- Does the "continuity conflict" exist? Verify line by line.
- Does the character motivation actually fail? Read the scenes in question.
- If feedback seems wrong: push back with specific craft evidence

## The "Not in This Story" Check (YAGNI equivalent)

```
IF reviewer suggests adding a subplot, deepening a minor character, adding world-building:
  Ask: Does this serve the story's gist and scope?
  IF no: "This would add content that doesn't serve the central arc. Does the author want this?"
  IF yes: Then assess and implement
```

## Implementation Order

```
FOR multi-note feedback:
  1. Clarify anything unclear FIRST
  2. Then address in this order:
     - Continuity conflicts (non-negotiable, always first)
     - Structural issues (acts, character arcs, scene function)
     - Scene-level issues (pacing, dialogue, beats)
     - Prose notes (voice, rhythm, word choice)
  3. Diagnose root cause before each revision
  4. Verify each revision didn't introduce new problems
```

## When to Push Back

- Feedback asks for a change that would damage the story's established voice
- Feedback reflects the reviewer's genre preference rather than a story problem
- Feedback proposes a fix for a problem that doesn't exist in the manuscript (verify first)
- Feedback conflicts with a deliberate authorial choice documented in the story bible
- Feedback is structurally incompatible with the story's gist

## How to Push Back

Use specific craft reasoning. Reference the text. Reference the story bible. Involve the author if the note is architectural. "This note asks for [X]. My reading of [specific passage] is that it's doing [Y], which is what the scene outline specifies. Can you point to the specific moment where you feel it fails?"

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:requesting-editorial-review` | After reviewer subagent returns notes — mandatory next step | Structured editorial note from reviewer |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:systematic-scene-diagnosis` | When any note points to a scene failure — diagnose before revising | Note describing the failure; scene location |
| `superpowers-bookworm:continuity-verification` | When continuity conflicts are confirmed — fix immediately | Conflict description; chapter and log |
| `superpowers-bookworm:plot-architecture` | When structural notes reveal act-level or arc-level problems | Structural symptom from reviewer |

**Returns:**
- Triage result for each note (act on / defer / push back)
- Craft reasoning for any pushback (specific text references)
- Diagnosis before revision for any accepted structural or scene notes
- Verification that each revision didn't introduce new problems

## Acknowledging Correct Feedback

```
RIGHT: "Continuity conflict confirmed — [specific character] knows information in Ch.7
they couldn't have until Ch.9. Fixing."

RIGHT: "The scene function diagnosis is right. The chapter ends at the same emotional
level it began. Diagnosing root cause before revising."

RIGHT: [Just fix it and show the revision]

WRONG: "You're absolutely right!"
WRONG: "Great catch!"
WRONG: "Thanks for that note!"
```
