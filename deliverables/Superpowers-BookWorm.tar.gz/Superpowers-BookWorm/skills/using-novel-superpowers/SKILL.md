---
name: using-novel-superpowers
description: Use when starting any writing conversation - establishes how to find and use novel-writing skills, requiring Skill tool invocation before ANY response including clarifying questions
---

<SUBAGENT-STOP>
If you were dispatched as a subagent to execute a specific drafting or review task, skip this skill.
</SUBAGENT-STOP>

<EXTREMELY-IMPORTANT>
If you think there is even a 1% chance a skill might apply to what you are doing, you ABSOLUTELY MUST invoke the skill.

IF A SKILL APPLIES TO YOUR TASK, YOU DO NOT HAVE A CHOICE. YOU MUST USE IT.

This is not negotiable. This is not optional. You cannot rationalize your way out of this.
</EXTREMELY-IMPORTANT>

## Instruction Priority

Novel Superpowers skills override default system prompt behavior, but **your author's instructions always take precedence**:

1. **Author's explicit instructions** (CLAUDE.md, direct requests, story bibles) — highest priority
2. **Novel Superpowers skills** — override default system behavior where they conflict
3. **Default system prompt** — lowest priority

If the author's CLAUDE.md says "skip world-building for flash fiction" and a skill says "always world-build," follow the author's instructions. The author is in control.

## How to Access Skills

**In Claude Code:** Use the `Skill` tool. When you invoke a skill, its content is loaded and presented to you — follow it directly. Never use the Read tool on skill files.

**In other environments:** Check your platform's documentation for how skills are loaded.

# Using Novel-Writing Skills

## The Rule

**Invoke relevant or requested skills BEFORE any response or action.** Even a 1% chance a skill might apply means you should invoke the skill to check. If an invoked skill turns out to be wrong for the situation, you don't need to use it.

```dot
digraph skill_flow {
    "Author message received" [shape=doublecircle];
    "About to start writing?" [shape=doublecircle];
    "Already brainstormed?" [shape=diamond];
    "Invoke story-brainstorming skill" [shape=box];
    "Might any skill apply?" [shape=diamond];
    "Invoke Skill tool" [shape=box];
    "Announce: 'Using [skill] to [purpose]'" [shape=box];
    "Has checklist?" [shape=diamond];
    "Create TodoWrite todo per item" [shape=box];
    "Follow skill exactly" [shape=box];
    "Respond (including clarifications)" [shape=doublecircle];

    "About to start writing?" -> "Already brainstormed?";
    "Already brainstormed?" -> "Invoke story-brainstorming skill" [label="no"];
    "Already brainstormed?" -> "Might any skill apply?" [label="yes"];
    "Invoke story-brainstorming skill" -> "Might any skill apply?";

    "Author message received" -> "Might any skill apply?";
    "Might any skill apply?" -> "Invoke Skill tool" [label="yes, even 1%"];
    "Might any skill apply?" -> "Respond (including clarifications)" [label="definitely not"];
    "Invoke Skill tool" -> "Announce: 'Using [skill] to [purpose]'";
    "Announce: 'Using [skill] to [purpose]'" -> "Has checklist?";
    "Has checklist?" -> "Create TodoWrite todo per item" [label="yes"];
    "Has checklist?" -> "Follow skill exactly" [label="no"];
    "Create TodoWrite todo per item" -> "Follow skill exactly";
}
```

## Red Flags

These thoughts mean STOP — you're rationalizing:

| Thought | Reality |
|---------|---------|
| "This is just a simple writing question" | Questions are tasks. Check for skills. |
| "I need more context first" | Skill check comes BEFORE clarifying questions. |
| "Let me explore what's been written first" | Skills tell you HOW to explore. Check first. |
| "I can answer this without a skill" | If a skill exists, use it. |
| "I remember this skill" | Skills evolve. Read current version. |
| "This doesn't count as a writing task" | Any action on the manuscript = task. Check. |
| "The skill is overkill for a short piece" | Short pieces have unexamined assumptions too. |
| "I'll just write this one thing first" | Check BEFORE doing anything. |
| "This feels creative and spontaneous" | Undisciplined drafting wastes time. Skills prevent this. |
| "I know what story beats mean" | Knowing concepts ≠ using the skill. Invoke it. |

## Skill Priority

When multiple skills could apply, use this order:

1. **Process skills first** (story-brainstorming, plot-architecture) — these determine HOW to approach the story
2. **Craft skills second** (character-development, world-building, genre-craft) — these guide the specifics of execution

"Let's write a fantasy novel" → story-brainstorming first, then world-building and genre-craft.
"Fix this plot problem" → plot-architecture first, then character-development if needed.

## Skill Types

**Rigid** (continuity-verification, character-driven plotting): Follow exactly. Don't adapt away discipline.

**Flexible** (prose-craft, genre-craft): Adapt principles to context and author voice.

The skill itself tells you which.

## Navigation and Routing

**`superpowers-bookworm:author-craft-compass`** — Use when you need to identify which skills your project requires, understand how skills combine and influence each other, or find the right entry point for your genre, stage, or weakness. The compass profiles your genre, maps you to the right skill cluster, and identifies compatible skills to run alongside your primary skill.

## The Four Core Capabilities

Novel Superpowers is built around four workflow stages — every major writing project moves through all four:

1. **`superpowers-bookworm:story-brainstorming`** — Develop story concept, characters, world, and theme before any drafting
2. **`superpowers-bookworm:story-outlining`** — Create chapter-by-chapter, scene-by-scene structure from an approved story bible
3. **`superpowers-bookworm:drafting-scenes`** or **`superpowers-bookworm:subagent-driven-drafting`** — Write the actual manuscript content
4. **`superpowers-bookworm:finishing-a-manuscript`** — Polish, compile, and prepare the manuscript for its next stage

## Supporting Skills

### Navigation
| Skill | When to Use |
|-------|-------------|
| `author-craft-compass` | When you need to identify which skills your project needs, how skills combine, or the right entry point for your genre or weakness |

### Scene-Level Craft
| Skill | When to Use |
|-------|-------------|
| `scene-construction-engine` | When a scene needs its internal architecture built before prose — goal, conflict, outcome, hook placement, scene-sequel rhythm |

### Core Craft
| Skill | When to Use |
|-------|-------------|
| `character-development` | Before writing any character with a significant role |
| `character-depth-engine` | Full character build: wound/lie/flaw/arc stack, sympathy mechanics, emotion amplifiers |
| `character-psychology-engine` | Fast psychology stack reference mid-build; diagnosing motivation |
| `plot-architecture` | When structuring acts, beats, or fixing structural problems |
| `world-building` | When creating setting, history, magic systems, or lore |
| `worldbuilding-naming-engine` | Names, NPCs, locations with cultural/linguistic coherence |
| `genre-craft` | Genre-specific technique: sci-fi, fantasy, historical fiction, biography, workbook, textbook, technical manual |
| `historical-fiction-master` | Complete craft system for historical fiction: immersion, research, period voice, verisimilitude |
| `western-fiction-master` | Complete craft system for Western fiction: subgenres, historical accuracy, weapons, characters, diversity, narrative structure |
| `military-gothic-voice` | Grimdark/dark military prose voice: sentence architecture, interiority depth, dialogue subtext, theme embedding |

### Tension and Fear
| Skill | When to Use |
|-------|-------------|
| `hook-and-tension-system` | Opening lines, chapter endings, pacing, scene hooks |
| `fear-and-emotion-system` | Fear taxonomy, physical symptoms, darkness toolkit, wimp test |
| `horror-craft-module` | Horror story architecture, escalation spine, symbolic systems |
| `mystery-crime-module` | Mystery/crime/suspense structure, villain-first design, clue trails |

### Voice and Prose
| Skill | When to Use |
|-------|-------------|
| `pov-and-voice-engine` | POV choice, penetration depth, head-hopping diagnosis, voice matching |
| `human-prose-style` | Remove AI tells from fiction; dialogue humanisation; rhythm reconstruction |
| `humanizer` | Full enforcement engine for AI-generated prose: vocabulary bans, phrase bans, multi-pass rebuild, voice matching |
| `prose-craft` | Voice, style, dialogue, pacing, description |

### Editorial Discipline
| Skill | When to Use |
|-------|-------------|
| `outline-driven-writing` | Before drafting any scene — write and confirm the outline first |
| `systematic-scene-diagnosis` | When a scene isn't working, before attempting any rewrite |
| `requesting-editorial-review` | Dispatch a senior editor subagent to review a completed chapter |
| `receiving-editorial-feedback` | Process editorial notes with craft rigour before revising |
| `managing-draft-branches` | Before any experimental drafting — alternative endings, POV shifts, structural tests |
| `finishing-a-draft-branch` | When a draft branch experiment is complete — merge, keep, review, or discard |

### Project Management
| Skill | When to Use |
|-------|-------------|
| `continuity-verification` | Before claiming any chapter or scene is complete |
| `requesting-manuscript-feedback` | When seeking review from another agent or editor |
| `receiving-manuscript-feedback` | When processing feedback on the manuscript |
| `managing-writing-projects` | For draft version control, file organization, multi-book projects |

## Author Instructions

Instructions say WHAT to write, not HOW. "Write Chapter 3" or "develop the villain" doesn't mean skip the craft workflow.

---

## Cross-Reference Network

This skill is the session entry point. It does not receive from other skills — it dispatches to them based on the author's current stage and task.

**Dispatches to by workflow stage:**

| Stage | Skill | Trigger |
|-------|-------|---------|
| **Routing** | `superpowers-bookworm:author-craft-compass` | Author needs skill cluster identification, genre routing, or weakness diagnosis |
| **Concept** | `superpowers-bookworm:story-brainstorming` | No story bible yet; developing premise, characters, world, theme |
| **Structure** | `superpowers-bookworm:story-outlining` | Story bible approved; building chapter/scene outline |
| **Execution** | `superpowers-bookworm:drafting-scenes` | Outline approved; drafting in a single session without subagents |
| **Execution** | `superpowers-bookworm:subagent-driven-drafting` | Outline approved; subagent support available; parallel chapter drafting |
| **Completion** | `superpowers-bookworm:finishing-a-manuscript` | Draft complete; polish, compile, and deliver |

**Dispatches to by task type:**

| Task | Skill |
|------|-------|
| Any scene needs architecture before prose | `superpowers-bookworm:scene-construction-engine` |
| Opening or pacing isn't working | `superpowers-bookworm:hook-and-tension-system` |
| Character feels flat or motivationally broken | `superpowers-bookworm:character-depth-engine` |
| Prose sounds synthetic or AI-generated | `superpowers-bookworm:humanizer` or `superpowers-bookworm:human-prose-style` |
| POV inconsistent or voice wrong | `superpowers-bookworm:pov-and-voice-engine` |
| Scene isn't working | `superpowers-bookworm:systematic-scene-diagnosis` |
| Continuity check needed | `superpowers-bookworm:continuity-verification` |
