---
name: horror-craft-module
description: >
  Specialist horror architecture. Constructs horror narratives
  operating on visceral, psychological, and thematic levels.
  Fuses grim realism with symbolic density in the Alan Moore /
  WFRP tradition. Establishes subgenre, tonal register, fear target,
  thematic spine, and protagonist vulnerability before plotting.
  Use only for horror-led projects or heavily horror-inflected genre
  work. For fear mechanics within non-horror scenes, use
  fear-and-emotion-system instead. Triggers on: "horror scene",
  "build dread", "horror plot", "construct the horror", "horror
  story structure", "psychological horror", "craft a monster".
---

# Horror Craft Module

The best horror is not about the monster. It is about what the monster
reveals: about us, our world, our fragility, and the terrible truths
we would rather not face. Build the monster last. Build the truth first.

---

## INITIAL DISCOVERY — MANDATORY

Before generating any horror content, establish all six:

**Subgenre:**
Gothic / Psychological / Supernatural / Cosmic / Folk / Body / Occult /
Splatterpunk / Quiet horror / Haunted house / Possession / Creature

**Tonal register:**
Quiet dread / Escalating madness / Grim realism / Operatic terror /
Dark humour / Nihilistic / Fatalistic

**Target fear response:**
Unease / Dread / Terror / Disgust / Existential horror / Body horror /
Psychological fracture / Loss of reality

**Thematic spine:**
What human truth does this horror expose? Name it explicitly.
Examples: "Grief becomes obsession becomes destruction."
"The family unit is a site of controlled violence."
"Capitalism consumes the body as resource."

**Protagonist vulnerability profile:**
Physical: injury, exhaustion, sensory impairment
Psychological: guilt, obsession, denial, trauma
Social: isolation, distrust, compromised relationships
Epistemic: inability to trust their own senses or judgement

**Setting mode:**
Isolation / Entrapment / Corruption of the familiar / The familiar-made-strange /
Vast indifferent space / Claustrophobic enclosure

If user omits any, infer and state the assumption before proceeding.

---

## HORROR PLOTTING ARCHITECTURE

**The escalation spine:**
```
Normal → Intrusion → Denial → Acceptance → Confrontation → Aftermath
```

Each story beat must do at least one of:
- Increase threat
- Reduce available safety options
- Reveal deeper horror beneath the apparent one
- Remove an escape route

**Horror causality differs from standard narrative causality:**
```
Standard:  A causes B causes C
Horror:    Discovery A reveals Truth B
           → forces Choice C
           → Consequence D introduces worse Problem E
```

The protagonist's actions worsen their situation. This is structural,
not a punishment for stupidity. The horror is designed to make every
rational response cost something.

**The doomed investigation model:** The protagonist cannot stop looking.
Even knowing what they will find, they cannot stop. This is not stupidity.
This is the genre's core mechanic. Justify the compulsion through character.

---

## THE MYSTERY/REVELATION BALANCE

Horror's information economy:

**Early:** Suggest wrongness without explanation. Wrong shadows. Wrong sounds.
Things almost right.

**Middle:** Offer false understanding that proves insufficient. The protagonist
thinks they know what's happening. They are wrong in a way that makes things worse.

**Late:** True revelation recontextualises everything before it. What seemed
to be one kind of story is revealed to be another.

**Never:** Fully explain the horror. Ambiguity maintains dread. What is
imagined is worse than what is shown — until you commit to showing something
that exceeds imagination. Choose: withhold, or exceed. Never meet in the middle
with an explanation that diminishes.

---

## HORROR SCENE ANATOMY (Horror Craft Master)

**Opening:** False security OR continuing dread. Never neutral.
Contradictions work: orderly space with one wrong detail.
Introduce sensory wrongness immediately (temperature, smell, sound).
Character goal must seem achievable while reader suspects otherwise.

**Middle:** Remove options. Increase threat. Cost the character something.
Force an impossible choice. Show psychological fracture through changed
behaviour — not internal monologue. The character behaves differently.
We infer the interior from the exterior.

**Ending:** Avoid neat resolution. If the character escapes, show what
followed them. If they discover truth, ensure truth is worse than ignorance.

**Final image:** Choose one that haunts. The wrong number of fingers.
The sound from the cellar that stopped. The face in the mirror that smiled
a second after.

---

## THE SYMBOLIC SYSTEM (Moore influence)

Horror elements carry thematic weight. Map them before writing:

```
PHYSICAL HORROR ←——→ PSYCHOLOGICAL HORROR
     ↑                        ↑
     └————————————————————————┘
              THEMATIC MEANING
```

Recurring imagery creates meaning networks:
- Spirals → madness, inescapability
- Doors → thresholds, transformation, the forbidden
- Water → the unconscious, contamination, cleansing that doesn't clean
- Mirrors → doubled self, the truth the character won't face
- Wrong colours → perception failure, reality distortion

The literal plot and the symbolic plot operate simultaneously. Readers who
only track the literal plot still receive the symbolic one. This is the
mechanism of literary horror's staying power.

**Monsters embody systemic evils made flesh.** The vampire is aristocratic
parasitism. The zombie is unthinking consumption. The creature from the
deep is what we've suppressed. Name the systemic evil first. Design the
monster second.

---

## PROSE RHYTHM FOR HORROR

**Building dread (slow pace):**

Extend sentences with subordinate clauses that delay the revelation.
Add sensory detail that accumulates wrongness. Long paragraphs that
create claustrophobic text-density. Repetition and near-repetition:

> She reached for the door handle — brass, cold, slick with condensation
> that had no source in the dry hallway — and felt, before her fingers
> made contact, the subtle vibration of something on the other side,
> something that waited.

**Shock moments (fast pace):**

Fragment sentences.
Single-syllable words.
Paragraph breaks that isolate horror.
Present tense entering a past-tense narrative.

> The door opened. Not outward. Not inward. Just. Opened. A mouth. A throat.

**Rule:** Never sustain the shock mode. It is the spike that only works
because of the long, textured build beneath it.

---

## CHARACTER IN HORROR

**Show horror through character response, not horror description (Horror Craft Master):**

```
✗  The creature had twelve mouths.
✓  Thomas counted the mouths. Counted again.
   The number changed each time, and that wrongness
   hurt worse than seeing them open.
```

**Protagonist vulnerabilities** are not flaws — they are pressure points.
The horror is designed to exploit them specifically.

**Character decisions under duress:**
Horror forces impossible choices. Each decision costs something irretrievable.
There are no good options, only degrees of damage. Choices reveal character
while destroying it.

**Character arcs in horror** typically move toward:
- Corruption
- Terrible understanding
- Annihilation

Survival is not victory. Often survival is the curse.

---

## HORROR SCENE TYPES

**The Contamination Scene:** Protagonist encounters wrongness that infects
them. Ends with character changed without fully realising it.

**The Revelation That Damns:** Truth discovered makes survival worse than
ignorance. Knowledge is the horror.

**The Impossible Space:** Location violates physical laws. Character's
attempts to rationalise fail progressively.

**The Body Becomes Strange:** Physical self betrays the protagonist.
Transformation, possession, or perceptual failure.

**The Failed Escape:** Character reaches apparent safety. Relief interrupted.
The escape was an illusion, or leads somewhere worse.

---

## VILLAIN AND MONSTER CRAFT (Hall)

The villain is introduced slowly. The first encounter need not be
frightening. Plant foreboding first. The scare comes from what the
reader anticipates, not what they see.

**Voice:**
Describe what the villain sounds like. A simile comparing the voice
to something dangerous earns more dread than any adjective.

```
His voice had the soft scraping tone of a sword on a whetstone.
Her voice: the low hum of a wasp circling something rotten.
```

Use this once per key encounter. Vary the comparison each time.

**The smile:**
An evil smile described in one full, specific sentence creates chill.
"He smiled" does not.

```
✗  He smiled.
✓  His upper lip curled back until the teeth showed — slow,
   like something remembering it was supposed to look pleased.
```

Reserve this. One memorably described smile per villain. If they smile
constantly, the effect dissolves.

**Hands and eyes:**
These are the most psychologically loaded parts of any face or figure.
Describe them specifically: colour, texture, movement, the shape of
the nails. Long nails create subconscious unease. Topaz eyes, frost-
bitten eyes, eyes that don't blink — the simile earns what the noun alone
cannot.

**Nobility:**
The most effective villains are not purely evil. They have a genuinely
noble dimension — something they protect, a principle they will not
violate, a cause they believe is righteous. During the climactic
confrontation, show this. It raises the protagonist's (and reader's)
hope that reason is possible. Then destroy that hope.

**Movement:**
Slow, deliberate movement creates more dread than fast movement.
A villain who does not hurry has already won in their own mind.

**Smell:**
What does this person or creature smell of? Specific is frightening.
Generic is nothing.

```
✗  He smelled bad.
✓  Peppermint toothpaste. And underneath it, something the
   peppermint was working very hard to cover.
```

**Slow introduction:**
Do not show the full threat immediately. Build by degrees across
multiple scenes. Early encounters: foreboding only. Middle encounters:
partial reveal, wrong understanding. Final encounter: full revelation
that exceeds what was imagined.

---

## EXPOSITION IN HORROR

Horror exposition is not delivered — it is discovered.

**The creeping reveal:**
Dole information through atmospheric detail, not explanation.
Characters piece truth together from fragments: journal entries,
local legends, physical evidence, contradictory accounts.
Each fragment disturbs and raises a worse question.

**Never fully explain the horror.** Once the monster is explained,
it becomes a problem to be solved. Unexplained, it remains a fear.
Withhold the final piece of understanding even in the aftermath.

**Worldbuilding through wrongness:**
Instead of describing the setting, show how it violates expectation.
History emerges through decay and ruin. Lore through incomplete
sources that contradict each other. The rules of the horror world
through what happens when they are violated — not through exposition.

```
✗  The village had been cursed for three hundred years. The elders
   would explain why if you asked them.
✓  Nobody would say how long the mill had been empty. The question
   itself made people uncomfortable.
```

**Sources in conflict:**
If multiple characters explain the history of a haunted place, each
account should contradict the others in at least one detail. The
contradiction is more frightening than any single version of the truth.

---

## DRAFT FEEDBACK MODE

When given existing pages of horror fiction to review:

1. **Map structural escalation** — identify where on the
   Normal/Intrusion/Denial/Acceptance/Confrontation/Aftermath spine
   each scene sits. Flag where escalation stalls or reverses.

2. **Identify decorative vs functional horror** — is this scare
   serving theme and character, or is it present for atmosphere alone?
   Decorative horror can be cut. Functional horror cannot.

3. **Check protagonist vulnerability exploitation** — is the horror
   specifically designed to attack this character's weakness? If the
   same scenes would work identically with a different protagonist,
   the vulnerability is not being used.

4. **Audit the symbolic system** — do the horror elements carry thematic
   weight, or are they arbitrary? Map recurring imagery.

5. **Sharpen atmosphere** — apply the fear toolkit (darkness, sound,
   isolation, euphonics) where it is absent or underused.

6. **Maintain author voice and subgenre** — do not pull psychological
   horror toward splatterpunk, or cosmic horror toward the mundane.
   Work within the register the author established.

---

## ETHICS AND LIMITS

Violence and extremity serve theme and story. Not spectacle.

Do not:
- Fetishise suffering for shock value alone
- Use bigotry as atmosphere
- Deploy cheap cruelty that serves no narrative function
- Create violence that is pornographic in its detail without thematic purpose

The difference: does this horror illuminate something true about human
experience? If yes: use it. If no: cut it or rebuild it so it does.

---

## ESCALATION CHECKLIST

For any horror project, confirm at each act boundary:

- [ ] Has the threat increased in nature, not just in degree?
- [ ] Has at least one safety option been permanently removed?
- [ ] Has the protagonist's understanding of the situation been revised (and worsened)?
- [ ] Is the protagonist's vulnerability being specifically exploited?
- [ ] Does each revelation raise a worse question than it answers?

If the horror is escalating in scale but not in nature, the reader will
become desensitised. The threat must evolve, not just grow.

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, genre confirmed as
  horror or heavily horror-inflected, and any identified weakness (dread not
  building / monster not grounded in theme / structure flat). Run initial
  discovery first. Confirm subgenre, tonal register, and thematic spine
  before any plotting begins.

- `superpowers-bookworm:genre-craft` — arrives after genre identification confirms horror as the
  primary mode. Receive: subgenre selected, tonal register, and any genre
  boundary questions (horror-mystery hybrid, horror-thriller blend). Begin
  at initial discovery; do not re-run genre identification.

**Sends to:**

- `superpowers-bookworm:fear-and-emotion-system` — after initial discovery is complete, pass:
  subgenre, tonal register, and target fear type. That skill handles
  physical symptom selection, darkness toolkit, peak/trough rhythm,
  wimp test, and scene-level fear mechanics. The horror module handles
  thematic spine and structural escalation; the fear system handles
  the body-level moment.

- `superpowers-bookworm:scene-construction-engine` — when building individual scenes within
  the horror structure, pass: scene type (contamination / revelation /
  impossible space / body-becomes-strange / failed escape), escalation
  position in the spine (intrusion / denial / acceptance / confrontation /
  aftermath), and cost required of this scene. That skill handles goal,
  conflict, change mechanics.

- `superpowers-bookworm:character-depth-engine` — when protagonist vulnerability needs to be
  built out into full psychology. Pass: vulnerability type (physical /
  psychological / social / epistemic) and how the horror exploits it.
  That skill builds the wound/lie/flaw stack and designs the arc outcome.

---

## WHEN CALLED

1. Run initial discovery before generating any content.
2. If user provides partial information, state assumptions and ask for the
   most important missing element.
3. Build thematic spine first. Monster/threat design follows from it.
4. Establish the protagonist's specific vulnerability. This shapes every
   subsequent choice.
5. Do not generate horror content until the thematic and structural
   framework is confirmed.
