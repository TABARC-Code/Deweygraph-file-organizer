# Period Texture Engine

*Subskill of: historical-fiction-master*
*Triggers: "this feels anachronistic", "add period detail", "make this feel more historical",
"ground this in the time", "this could be set anywhere", "lacks atmosphere", "the world feels thin"*

This skill embeds time, place, class, and information-speed into prose without stopping the story to explain them.

**Parent skill:** historical-fiction-master (SKILL.md)
**Called from:** SKILL.md nodes A2, A4, G7
**Links out to:** references/sensory-writing.md; references/period-voice.md; references/research-methods.md

## Governing Principle

Period texture is never announced. It is *present* in the fabric of every sentence. The rule: **never stop the story to explain context**. Every period detail must arrive embedded in action, perception, or speech.

---

## The Four Pillars

### 1. Material World

Objects, surfaces, tools, and materials ground the reader in time more efficiently than any date. **The test:** could this object exist in any other era? If yes, find one that couldn't.

**Categories to activate:**
- **Tools and technologies:** the specific implement — a quill and pounce box, not a pen; an adze, not a plane; a tinder box, not a match
- **Materials and surfaces:** pewter, oilskin, rush-strewn floors, hand-blown glass, boiled leather, wattle-and-daub, fieldstone, raw linen
- **Transport:** foot, horse, barge, stage coach — mode shapes time, fatigue, social encounter, and what a character knows about the world they pass through
- **Money:** actual denominations; what things cost relative to wages; the difference between coin, credit, barter, and debt
- **Food and drink:** what is available, what is scarce, how it is preserved, how it is prepared, what it tastes like to a body that has never known refrigeration
- **Domestic routines:** making fire (tinder, flint, steel), fetching water, managing light (rush dip, tallow candle, beeswax, whale-oil lamp), laundering by hand

**The "yucky stuff" layer:** The biological, accidental, and grotesque details of period material life — maggots in wounds, the smell of unwashed wool, the vinegar ration, the specific weight of human waste in a chamber pot — are as much material world as any elegant object. They carry the authority of the utterly specific.
→ For full yucky stuff technique: **references/sensory-writing.md, yucky stuff section**

**Rule:** One era-specific detail per paragraph. It arrives in the action, not in a caption.

**Wrong:** *She lit the tallow candle, a form of illumination made from rendered animal fat, and opened her letter.*
**Right:** *She tilted the tallow dip toward the page. The smoke made her eyes sting.*

### 2. Social Register

Speech and thought reflect class, education, region, profession, age, and the social hierarchies of the era. These are the structural bones of the world — not decoration.

**What social register reveals:**
- **Class and education:** vocabulary range, sentence complexity, address forms, the habit of deference or command
- **Region:** idiom and characteristic phrase — represented through *what* is said, not through phonetic spelling
- **Profession:** technical vocabulary and the assumptions of the trade
- **Age and generation:** what a person of this age owes to those above and below them in the social order
- **Sex:** what may be said by whom, in what company, with what consequences

**Social register in silence:** What a character conspicuously does *not* say — in the presence of their social superior, in mixed company, in front of a servant — is as revealing as what they say.
→ For period vocabulary and anti-anachronism: **references/period-voice.md**

### 3. Behavioural Constraint

Characters live inside a web of social, economic, legal, religious, and institutional obligations that shape — and often override — individual desire. Let constraint press against the character's will. The story happens in the gap between what they want and what they are permitted.

**Types of constraint:**
- **Social:** the cost of visible deviation from expected behaviour; gossip as surveillance; the social death that follows transgression
- **Economic:** debt as a social condition; what the character cannot do because they cannot afford it; what they can afford that most cannot
- **Legal:** the specific laws that apply — coverture, entail, impressment, vagrancy law, guild regulation, the legal standing of oath and contract
- **Religious:** the specific demands of the faith; the consequence of public impiety; the inner structure of genuine belief that shapes every decision
- **Gendered:** the specific permissions and prohibitions by sex; the tactical workarounds that women and men developed within their constraints; the cost of being seen to exceed your sanctioned role
- **Period social codes:** duelling; blood feud; honour culture; the specific rituals of challenge and satisfaction that made insult a life-and-death matter in certain centuries

**Rule:** A character who simply does what they want, in defiance of all period constraint, has been liberated from their era. That is a form of anachronism.
→ For social codes in detail: **references/period-voice.md, codes and mores section**

### 4. Communication Technology and Information Speed

How news travels in your period is not merely a texture detail — it is a structural element of your fictional world. It shapes what characters can know, when they can know it, and what decisions they make in ignorance of facts they could not yet have received.

**Material texture of period communication:**
- The specific *object* that carries news: the broadsheet, the gazette, the dispatch, the letter with wax seal, the warrant with counter-signature
- The specific *person* who carries it: the town crier, the express rider, the herald, the king's messenger, the packet captain
- The specific *sound* of its arrival: the crier's bell in the street, the rider's horn at the gate, the signal cannon at the harbour mouth, the drumbeat relayed from ridge to ridge
- The specific *speed* of its travel: measured in days and weeks, not hours and seconds; shaped by weather, road condition, and institutional control

**Plot texture of period communication:**
- What does this character not yet know — and how does that ignorance press on the scene?
- What false news has arrived ahead of the true? How does the character act on it?
- Who controls the flow of information in this society, and how does that power shape the story?
- What would change if the news had arrived one day sooner, or one day later?

→ For research methodology: **references/research-methods.md, communication speed section**
→ For communication vocabulary: **references/period-voice.md, communication technology vocabulary section**

---

## Diagnosis and Repair Protocol

When a passage lacks period texture, perform this four-part diagnosis:

**Step 1 — Material audit:**
Is there at least one era-specific object the character physically uses? Could every object in the scene be from any century? Is there at least one "yucky stuff" detail in this chapter?

**Step 2 — Social register audit:**
Does the dialogue reflect the speaker's class and education? Is anyone speaking in vocabulary unavailable to their class or era? Is social hierarchy visible in who speaks first, who waits, who uses which address form?

**Step 3 — Constraint audit:**
Is there pressure on the character from social, economic, or institutional forces? Is the scene unfolding in a social vacuum — as if the characters have no obligations beyond the immediate moment? Are the period social codes (duelling, honour, guild, religious obligation) structurally present?

**Step 4 — Communication audit:**
Does the character know something they could not yet have received? Is the speed of information consistent with the period? Is there an opportunity to use the *arrival* or *delay* of news as a dramatic element?

**Output:** Return (1) texture diagnosis specifying which pillars are absent or thin, (2) texture plan with specific additions for each gap, (3) revised passage with period texture embedded throughout.

---

## Cross-Links (Bilateral)

| Direction | Destination | When |
|-----------|-------------|------|
| Called by | SKILL.md (A2, A4, G7) | During draft and during audit |
| Calls out to | references/sensory-writing.md | Material objects need sensory activation; yucky stuff technique |
| Calls out to | references/period-voice.md | Social register and communication vocabulary |
| Calls out to | references/research-methods.md | Communication speed research and data systems |
| Returns to | SKILL.md (G) | After revision, re-run full audit |
| Informs | references/character-biography.md | Material world, constraint, and social register reveal character |
