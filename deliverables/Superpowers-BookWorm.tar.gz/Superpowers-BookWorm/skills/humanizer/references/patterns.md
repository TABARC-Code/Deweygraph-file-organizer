# Pattern Library — Full Reference

Load this file when you need before/after examples for any pattern, or to show the user a worked example of the full process.

---
## FULL PATTERN DETECTION

Read `references/patterns.md` for the complete library with before/after examples. The core patterns are:

1. Inflated significance ("pivotal moment", "testament to", "key turning point")
2. Notability / media coverage padding
3. Superficial -ing clauses (highlighting, underscoring, symbolizing)
4. Promotional / advertisement tone
5. Vague attribution ("experts say", "observers note")
6. Fake authority (source list without context)
7. Copula avoidance ("serves as", "functions as", "stands as") → use "is/are/has"
8. Rule-of-three symmetry
9. False ranges
10. Passive / actorless language
11. Synonym cycling
12. Chatbot artifacts ("Great question!", "Let me know if...")
13. Negative parallelism ("It's not just X; it's Y")
14. AI vocabulary (see bans above)
15. Excessive conjunctive phrases
16. Structural symmetry (mirrored paragraphs)
17. Knowledge-cutoff hedging ("Based on available information...")
18. Generic challenge/future sections
19. Formulaic bullet lists replacing prose
20. Hyphenated word pair overuse
21. Undue emphasis / "it is important to note"
22. Over-hedging ("could potentially possibly be argued")
23. Generic positive conclusions
24. Curly quotes and typographic AI tells
25. Soulless neutrality (technically clean but voiceless)
26. Over-explanation (explaining what the reader already knows)
27. Assembly feel (paragraphs don't connect — each one is self-contained)
28. Paragraph opener monotony (The... The... The... / This recap openers)
29. Contraction avoidance ("do not" / "it is" in contexts where humans contract)
30. Missing idiomatic register (no "kind of", "honestly", "the thing is")
31. Transition sentence overuse ("However,", "Therefore," as sentence openers)
32. Overuse of "This/These" recaps mid-text
33. Uniform paragraph length (every paragraph 3–4 sentences)
34. Absence of specificity anchor (entire paragraphs with zero concrete details)
35. Redundant sentence pairs (same claim stated twice in different words)
36. Invented quotes ("One analyst noted: '...'" with no traceable source)
37. Tense inconsistency (mixing present and past tense without reason)

---

## HUMAN VOICE ENGINE

Avoiding AI patterns is half the job. Sterile, clean writing is still obviously inhuman.

### Rhythm

- Vary sentence length deliberately. Short punch. Then one that takes its time getting somewhere and earns the space.
- Vary paragraph length. One sentence can be its own paragraph.
- Break predictable cadence. If three consecutive sentences have the same rhythm, rewrite one.

### Messiness as signal

- Avoid perfect structure. Uneven pacing is human.
- Allow asymmetry in paragraph length, point emphasis, transitions.
- Rough edges are acceptable. Too smooth = failure.

### Tonal variation

- Allow register shifts: dry → sharp → reflective.
- Let opinions surface. Fake neutrality reads as AI.

### Specificity over abstraction

Replace every vague claim with at least one of: a number, a named actor, a concrete action, or a real outcome.

- "The results were significant" → "The test group finished 40% faster"
- "Experts have noted challenges" → "Three engineers at the company told me it kept suggesting deprecated patterns"

### Idiomatic naturalness

AI systematically avoids informal register markers even in casual writing. These small words signal a real person is present. Use them when register allows:

- Hedging: "kind of", "sort of", "a bit", "pretty much", "roughly"
- Emphasis: "honestly", "genuinely", "actually", "look,"
- Stance markers: "the thing is,", "here's the problem:", "what gets me is"
- Acknowledgement of complexity: "I'm not sure", "it depends", "it's complicated"

Not every piece needs these. A formal business memo shouldn't have "honestly, look." But if the register is casual or personal and none of these appear anywhere, that's a tell.

---

## CONTENT PATTERNS

### 1. Inflated significance

**Detect:** stands/serves as a testament to, pivotal moment, key turning point, underscores its importance, reflects broader, symbolizing its ongoing, setting the stage for, marks a shift, evolving landscape, indelible mark, deeply rooted

**Problem:** AI puffs up importance by adding statements about how arbitrary things represent or contribute to broader topics.

**Before:**
> The Statistical Institute of Catalonia was officially established in 1989, marking a pivotal moment in the evolution of regional statistics in Spain. This initiative was part of a broader movement to decentralize administrative functions.

**After:**
> The Statistical Institute of Catalonia was established in 1989 to collect and publish regional statistics independently from Spain's national statistics office.

---

### 2. Notability / media coverage padding

**Detect:** independent coverage, local/regional/national media outlets, written by a leading expert, active social media presence, followers

**Problem:** AI lists sources or follower counts without context to signal credibility.

**Before:**
> Her views have been cited in The New York Times, BBC, Financial Times, and The Hindu. She maintains an active social media presence with over 500,000 followers.

**After:**
> In a 2024 New York Times interview, she argued that AI regulation should focus on outcomes rather than methods.

---

### 3. Superficial -ing clauses

**Detect:** highlighting..., underscoring..., emphasizing..., ensuring..., reflecting..., symbolizing..., contributing to..., cultivating..., fostering..., showcasing...

**Problem:** Present participle phrases tacked on to add fake depth or meaning.

**Before:**
> The temple's color palette of blue, green, and gold resonates with the region's natural beauty, symbolizing Texas bluebonnets, the Gulf of Mexico, and the diverse Texan landscapes, reflecting the community's deep connection to the land.

**After:**
> The temple uses blue, green, and gold colors. The architect said these were chosen to reference local bluebonnets and the Gulf coast.

---

### 4. Promotional / advertisement tone

**Detect:** boasts a, vibrant, rich (figurative), profound, enhancing its, showcasing, exemplifies, commitment to, natural beauty, nestled, in the heart of, groundbreaking, renowned, breathtaking, must-visit, stunning

**Problem:** AI can't stay neutral on cultural or place topics. Everything becomes a brochure.

**Before:**
> Nestled within the breathtaking region of Gonder in Ethiopia, Alamata Raya Kobo stands as a vibrant town with a rich cultural heritage and stunning natural beauty.

**After:**
> Alamata Raya Kobo is a town in the Gonder region of Ethiopia, known for its weekly market and 18th-century church.

---

### 5. Vague attribution

**Detect:** experts say, industry reports, observers have cited, experts argue, some critics argue, several sources (when few cited)

**Problem:** AI attributes opinions to vague authorities without specific sources.

**Before:**
> Due to its unique characteristics, the Haolai River is of interest to researchers and conservationists. Experts believe it plays a crucial role in the regional ecosystem.

**After:**
> The Haolai River supports several endemic fish species, according to a 2019 survey by the Chinese Academy of Sciences.

---

### 6. Generic "Challenges and Future Prospects" sections

**Detect:** Despite its... faces challenges typical of..., Despite these challenges, Future Outlook, Challenges and Legacy

**Problem:** Formulaic sections that say nothing specific.

**Before:**
> Despite its industrial prosperity, Korattur faces challenges typical of urban areas, including traffic congestion and water scarcity. Despite these challenges, with its strategic location and ongoing initiatives, Korattur continues to thrive.

**After:**
> Traffic congestion increased after 2015 when three new IT parks opened. The municipal corporation began a stormwater drainage project in 2022.

---

### 7. AI vocabulary overuse

**High-frequency AI words:** additionally, align with, crucial, delve, emphasizing, enduring, enhance, fostering, garner, highlight (verb), interplay, intricate, key (adjective), landscape (abstract), pivotal, showcase, tapestry, testament, underscore (verb), valuable, vibrant

**Before:**
> Additionally, a distinctive feature of Somali cuisine is the incorporation of camel meat. An enduring testament to Italian colonial influence is the widespread adoption of pasta in the local culinary landscape.

**After:**
> Somali cuisine also includes camel meat, which is considered a delicacy. Pasta dishes, introduced during Italian colonization, remain common in the south.

---

### 8. Copula avoidance (serves as / functions as / stands as)

**Detect:** serves as, stands as, marks, represents [a], boasts, features, offers [a]

**Problem:** AI substitutes elaborate constructions for simple "is/are/has."

**Before:**
> Gallery 825 serves as LAAA's exhibition space for contemporary art. The gallery features four separate spaces and boasts over 3,000 square feet.

**After:**
> Gallery 825 is LAAA's exhibition space for contemporary art. The gallery has four rooms totaling 3,000 square feet.

---

### 9. Negative parallelism

**Detect:** It's not just about...; it's..., Not only X but Y, Not merely X, it's Y

**Before:**
> It's not just about the beat riding under the vocals; it's part of the aggression and atmosphere. It's not merely a song, it's a statement.

**After:**
> The heavy beat adds to the aggressive tone.

---

### 10. Rule of three overuse

**Problem:** AI forces ideas into threes to appear thorough.

**Before:**
> The event features keynote sessions, panel discussions, and networking opportunities. Attendees can expect innovation, inspiration, and industry insights.

**After:**
> The event includes talks and panels. There's also time for informal networking between sessions.

---

### 11. Synonym cycling (elegant variation)

**Problem:** AI's repetition-penalty code causes excessive synonym substitution for the same noun.

**Before:**
> The protagonist faces many challenges. The main character must overcome obstacles. The central figure eventually triumphs. The hero returns home.

**After:**
> The protagonist faces many challenges but eventually triumphs and returns home.

---

### 12. False ranges

**Problem:** "From X to Y" constructions where X and Y aren't on a meaningful scale.

**Before:**
> Our journey has taken us from the singularity of the Big Bang to the grand cosmic web, from the birth and death of stars to the enigmatic dance of dark matter.

**After:**
> The book covers the Big Bang, star formation, and current theories about dark matter.

---

### 13. Em dash overuse

**Problem:** AI uses em dashes more than humans, mimicking punchy sales writing.

**Before:**
> The term is primarily promoted by Dutch institutions—not by the people themselves. You don't say "Netherlands, Europe" as an address—yet this mislabeling continues—even in official documents.

**After:**
> The term is primarily promoted by Dutch institutions, not by the people themselves. You don't say "Netherlands, Europe" as an address, yet this mislabeling continues in official documents.

---

### 14. Overuse of boldface

**Problem:** AI mechanically emphasizes phrases in bold.

**Before:**
> It blends **OKRs (Objectives and Key Results)**, **KPIs (Key Performance Indicators)**, and visual strategy tools such as the **Business Model Canvas (BMC)** and **Balanced Scorecard (BSC)**.

**After:**
> It blends OKRs, KPIs, and visual strategy tools like the Business Model Canvas and Balanced Scorecard.

---

### 15. Inline-header bullet lists

**Problem:** Lists where each item starts with a bolded header followed by a colon. AI's default output structure.

**Before:**
> - **User Experience:** The user experience has been significantly improved with a new interface.
> - **Performance:** Performance has been enhanced through optimized algorithms.
> - **Security:** Security has been strengthened with end-to-end encryption.

**After:**
> The update improves the interface, speeds up load times through optimized algorithms, and adds end-to-end encryption.

---

### 16. Title case in headings

**Problem:** AI capitalizes all main words in headings.

**Before:**
> ## Strategic Negotiations And Global Partnerships

**After:**
> ## Strategic negotiations and global partnerships

---

### 17. Emojis as decoration

**Problem:** AI decorates headings or bullet points with emojis.

**Before:**
> 🚀 **Launch Phase:** The product launches in Q3
> 💡 **Key Insight:** Users prefer simplicity

**After:**
> The product launches in Q3. User research showed a preference for simplicity.

---

### 18. Curly quotation marks

**Problem:** Some AI outputs use curly/smart quotes ("...") instead of straight quotes ("..."). Flag and correct.

---

### 19. Chatbot artifacts

**Detect:** I hope this helps, Of course!, Certainly!, You're absolutely right!, Would you like..., let me know, here is a..., Great question!

**Before:**
> Here is an overview of the French Revolution. I hope this helps! Let me know if you'd like me to expand on any section.

**After:**
> The French Revolution began in 1789 when financial crisis and food shortages led to widespread unrest.

---

### 20. Knowledge-cutoff disclaimers

**Detect:** as of [date], up to my last training update, while specific details are limited, based on available information

**Before:**
> While specific details about the company's founding are not extensively documented in readily available sources, it appears to have been established sometime in the 1990s.

**After:**
> The company was founded in 1994, according to its registration documents.

---

### 21. Sycophantic tone

**Before:**
> Great question! You're absolutely right that this is a complex topic. That's an excellent point about the economic factors.

**After:**
> The economic factors you mentioned are relevant here.

---

### 22. Filler phrases

Quick replacements:
- "In order to achieve this goal" → "To achieve this"
- "Due to the fact that it was raining" → "Because it was raining"
- "At this point in time" → "Now"
- "In the event that you need help" → "If you need help"
- "The system has the ability to process" → "The system can process"
- "It is important to note that the data shows" → "The data shows"
- "In today's rapidly evolving landscape" → delete, start with the actual claim

---

### 23. Excessive hedging

**Before:**
> It could potentially possibly be argued that the policy might have some effect on outcomes.

**After:**
> The policy may affect outcomes.

---

### 24. Generic positive conclusions

**Problem:** AI almost always ends with a forward-looking, upbeat, vague summary. It signals the piece is over without actually landing anywhere. Cutting it is only half the job — the piece needs a real ending.

**Before:**
> The future looks bright for the company. Exciting times lie ahead as they continue their journey toward excellence. In conclusion, this represents a significant step forward.

**After (cut and replace):**
> The company plans to open two more locations next year, both in markets where its first trial failed. That's either confidence or stubbornness. Probably both.

**How to end well — four options:**

1. **Land on a specific detail.** End with a concrete fact, not a summary. The last sentence should be the most specific thing in the piece, not the vaguest.

2. **Circle back to the opening.** If the piece opened with an image, scene, or specific moment, return to it. Creates closure without a formal conclusion.

3. **State the unresolved thing.** Human pieces often end by naming what's still uncertain or unanswered. "Nobody knows yet whether this works at scale." More honest than a wrap-up.

4. **Stop earlier than you think.** The actual ending is usually two or three sentences before what the AI wrote. Cut the summary. See if what's left already closes.

**Rule:** never end on "the future", "journey", "excellence", "continued growth", or any upward-trending abstraction. End on something that happened or something real.

---

### 25. Hyphenated word pair overuse

**Detect:** cross-functional, client-facing, data-driven, decision-making, well-known, high-quality, real-time, long-term, end-to-end (when used formulaically)

**Problem:** AI hyphenates these with perfect consistency. Humans don't.

**Before:**
> The cross-functional team delivered a high-quality, data-driven report on our client-facing tools.

**After:**
> The cross functional team delivered a high quality, data driven report on our client facing tools.

---

## NEW PATTERNS (26–34)

### 26. Over-explanation

**Problem:** AI assumes the reader knows nothing. It explains things the audience already understands, treating basic context as revelation.

**Detect:** "As we know...", "It is well established that...", "Photosynthesis, the process by which plants convert sunlight...", explaining an acronym four times, restating the same point in different words across consecutive sentences.

**Before:**
> Machine learning, a subset of artificial intelligence where systems learn from data, has become increasingly important. These systems, which improve through experience rather than being explicitly programmed, are now used across many industries.

**After:**
> Machine learning is now used across most industries, from fraud detection to drug discovery.

Rule: if the intended reader already knows it, cut it or assume it.

---

### 27. Assembly feel

**Problem:** AI generates paragraphs as self-contained units. Each one could be rearranged or removed without the reader noticing. There's no thread running through. Ideas don't build on each other.

**Detect:**
- Paragraphs that start by restating the topic rather than advancing from the previous point
- No pronoun references or callbacks to what came before
- Transitions that reintroduce ("Another important aspect is...")
- Could you shuffle the paragraphs? If yes, it has assembly feel.

**Fix:**
- End a paragraph by creating a question or tension the next one resolves
- Start paragraphs by picking up a thread, not introducing a new one ("That's the official version. What actually happened...")
- Use pronouns and callbacks: "That decision...", "Which is why..."

**Before:**
> Remote work has become widespread in recent years. Many companies have adopted flexible policies.
>
> Employee wellbeing is an important consideration for modern organisations. Mental health support has increased.
>
> Technology plays a key role in enabling distributed teams. Video conferencing tools have improved significantly.

**After:**
> Remote work took off fast, and most companies weren't ready for it. They had the video conferencing tools but not the management culture to match.
>
> That gap showed up in the data. Burnout rates climbed in 2021 and 2022 even as companies added wellbeing perks. The problem wasn't the tools — it was that nobody had thought through what managing people remotely actually requires.

---

### 28. Paragraph opener monotony

**Problem:** AI starts paragraphs with the same syntactic structure repeatedly. "The..." four times in a row. "This..." recaps that summarise rather than advance.

**Detect:**
- Three or more consecutive paragraphs beginning with "The"
- "This X demonstrates...", "These factors show...", "This approach highlights..." (recap openers)
- "In addition...", "Furthermore...", "Moreover..." as paragraph starters
- "It is..." / "It was..." opening a paragraph (weak, impersonal, AI default)

**Before:**
> The company was founded in 2010. The founders wanted to solve a logistics problem.
>
> The first product launched in 2012. The initial reception was mixed.
>
> The team iterated quickly. The second version launched six months later.

**After:**
> Founded in 2010, the company started as a bet on last-mile logistics before anyone called it that.
>
> Their first product landed badly. Carriers didn't trust it, and the UX was rough.
>
> Six months later they shipped a second version. That one stuck.

---

### 29. Contraction avoidance

**Problem:** AI writes in full forms in contexts where a real person would contract. Sounds stiff, formal, robotic — even when the surrounding tone is casual.

**Common culprits and fixes:**

| Full form | Natural form |
|-----------|-------------|
| do not | don't |
| it is | it's |
| they are | they're |
| we are | we're |
| would not | wouldn't |
| cannot | can't |
| have not | haven't |
| will not | won't |
| it has | it's |
| that is | that's |
| there is | there's |
| I am | I'm |
| you are | you're |
| does not | doesn't |
| is not | isn't |

**Rule:** if reading the full form aloud sounds stiff in context, contract it. Exception: legal, academic, or official documents where full forms are a register requirement.

**Before:**
> We do not have a simple answer. It is important to understand that the data does not tell the whole story. There is more work to do.

**After:**
> We don't have a simple answer. The data doesn't tell the whole story, and there's more work to do.

---

### 30. Missing idiomatic register

**Problem:** AI avoids informal register markers even in casual writing. The result is technically correct prose that sounds like nobody's home.

**What humans say that AI avoids:**

- Hedging: "kind of", "sort of", "a bit", "pretty much", "roughly", "more or less"
- Emphasis: "honestly", "genuinely", "actually", "look,"
- Stance: "the thing is,", "here's the problem:", "what gets me is", "and that's the part that's tricky"
- Uncertainty: "I'm not sure", "it depends", "it's complicated", "hard to say"
- Colloquial connectors: "which is fine", "which is not fine", "and so on", "or something like that"

**Before:**
> The situation is complex. Multiple factors contribute to the outcome. The evidence is inconclusive.

**After:**
> It's complicated, honestly. The evidence points in different directions, and the factors involved don't separate cleanly.

**Rule:** Only add these in appropriate registers. A formal business memo shouldn't have "look," or "kind of." But if the piece is casual and none of these appear, that's a tell.

---

### 31. Transition sentence overuse

**Problem:** AI starts sentences and paragraphs with single-word or short-phrase transitions that announce structure rather than carry meaning.

**Banned as sentence openers:**
- "However," (opening a paragraph)
- "Therefore," (mid-essay)
- "Additionally," / "Furthermore," / "Moreover,"
- "Consequently,"
- "Nevertheless,"
- "Thus,"
- "Notably,"

**Fix:** embed the contrast or connection inside the sentence, or drop the transition entirely and let the content do the work.

**Before:**
> The project ran over budget. However, the team delivered on time. Additionally, the client was satisfied with the result. Therefore, the project was considered a success.

**After:**
> The project ran over budget but delivered on time. The client signed off without complaints.

---

### 32. "This/These" recap openers

**Problem:** A specific sub-case of assembly feel. AI opens paragraphs by recapping what it just said: "This approach demonstrates...", "These factors highlight...", "This dynamic shows..." The reader doesn't need the summary — they just read the paragraph.

**Before:**
> The company shifted to a remote-first model in 2020. Productivity increased in the first year.
>
> This shift demonstrates the potential of flexible working arrangements to improve output. These results highlight the importance of trusting employees.

**After:**
> The company went remote-first in 2020. Productivity went up in the first year, which surprised a lot of managers who'd assumed the opposite.

---

### 33. Uniform paragraph length

**Problem:** AI produces paragraphs of nearly identical length — usually 3–4 sentences each. This creates a predictable drumbeat that feels mechanical.

**Fix:** vary deliberately. One paragraph can be a single sentence. Another can run long. The variation itself signals human judgement about what deserves space.

**Before:**
> [Para 1: 3 sentences]
> [Para 2: 4 sentences]
> [Para 3: 3 sentences]
> [Para 4: 4 sentences]

**After:**
> [Para 1: 1 sentence — the point, stated plainly]
>
> [Para 2: 6 sentences — the complexity, given room]
>
> [Para 3: 2 sentences — the conclusion, direct]

---

### 34. Absence of specificity anchor

**Problem:** Entire paragraphs pass without a single concrete detail: no number, no name, no date, no place, no outcome. Abstraction builds on abstraction.

**Test:** for each paragraph, ask: is there at least one fact that couldn't apply to any other topic?

**Before:**
> Organisations that invest in their people tend to see better results. When employees feel valued, they perform at higher levels. This creates a positive cycle of engagement and productivity.

**After:**
> A 2022 Gallup study found that companies in the top quartile for employee engagement had 23% higher profitability than those in the bottom quartile. That gap has been consistent across industries for over a decade.

---

### 35. Redundant sentence pairs

**Problem:** AI writes a claim then immediately restates it in different words. The second sentence adds nothing. Extremely common at the end of paragraphs as a mini-summary of what was just said.

**Detect:** two consecutive sentences where removing the second loses no information. Often signalled by "In other words...", "Put differently...", "This means that..." — or no connector at all, just the same idea rephrased.

**Before:**
> The results were positive. The team was pleased with the outcomes.

> Remote work increased productivity. Employees working from home performed at higher levels.

> The decision was controversial. Many people disagreed with the choice that was made.

**After:**
> The results were positive.

> Remote work increased productivity.

> The decision was controversial.

**Rule:** if removing the second sentence loses nothing, remove it. If it adds a specific detail the first didn't have, keep it. Deliberate repetition for emphasis or rhythm is different — that's a choice, not redundancy.

---

### 36. Invented quotes

**Problem:** More dangerous than vague attribution (pattern 5). AI generates plausible-sounding direct quotes attributed to unnamed or vaguely-named sources. These look like primary sources but are fabricated.

**Detect:**
- `"One industry analyst noted: '...'"` — no name, no date, no publication
- `"As a leading expert observed: '...'"` — same problem
- `"A senior executive at the company stated: '...'"` — unverifiable
- Any direct quote in quotation marks where the speaker cannot be identified

**Why it's worse than vague attribution:** vague attribution is hedged. Invented quotes present fabrication as evidence.

**Fix options:**
1. If the quote is real and the source can be named: name them (first name, role, organisation, date)
2. If the source can't be named: convert to attributed paraphrase ("several engineers interviewed said the tool kept suggesting deprecated patterns")
3. If the quote is invented: delete it and state the point directly

**Rule:** flag every unattributed direct quote to the user. Never reproduce or paraphrase a potentially invented quote in the rewrite without confirmation.

---

### 37. Tense inconsistency

**Problem:** AI slips between present and past tense within analytical or narrative writing without purpose. Humans do this too, but AI does it more frequently and more randomly — especially when switching between describing a situation (past) and discussing its implications (present eternal).

**Detect:** a paragraph or section that opens in past tense and drifts to present, or vice versa, without the shift being earned by context (flashback, general truth, direct speech).

**Before:**
> The company launched its product in 2021. It targets mid-market clients and offers a subscription model. The launch was initially slow, but adoption grew quickly. The platform now integrates with over 40 tools and is used by more than 5,000 businesses.

*(Mixes "launched/was/grew" with "targets/offers/integrates/is" — two tenses with no clear logic)*

**After — pick one and stick to it:**
> The company launched its product in 2021, targeting mid-market clients with a subscription model. Adoption was slow at first but grew quickly. By 2023 the platform integrated with over 40 tools and had 5,000 business customers.

*Or, if describing the current state:*
> Launched in 2021, the platform now serves more than 5,000 businesses and integrates with over 40 tools. The subscription model targets mid-market clients — a segment competitors had largely ignored.

**Rule:** decide which tense anchors the piece. Past for narrative/historical. Present for analysis of current state. Shift deliberately only when the context demands it (general truths, ongoing conditions, direct quotes). Flag unearned tense shifts in Pass 3.

---

Pattern 25 is about technical cleanliness. This is about whether the text has a person behind it.

### Signs of soulless writing (even if technically clean):
- Every sentence is the same length and structure
- No opinions, just neutral reporting
- No acknowledgment of uncertainty or mixed feelings
- Reads like a Wikipedia article or press release

### How to add voice:

**Have opinions.** "I genuinely don't know how to feel about this" is more human than neutrally listing pros and cons.

**Vary rhythm.** Short punchy sentences. Then longer ones that take their time getting where they're going.

**Acknowledge complexity.** "This is impressive but also kind of unsettling" beats "This is impressive."

**Use first person when it fits.** "I keep coming back to..." signals a real person thinking.

**Let some mess in.** Perfect structure feels algorithmic.

**Be specific about feelings.** Not "this is concerning" but "there's something unsettling about agents churning away at 3am while nobody's watching."

---

## WORKED EXAMPLE (Full process)

### Input (AI-generated):

> Great question! Here is an essay on this topic. I hope this helps!
>
> AI-assisted coding serves as an enduring testament to the transformative potential of large language models, marking a pivotal moment in the evolution of software development. In today's rapidly evolving technological landscape, these groundbreaking tools—nestled at the intersection of research and practice—are reshaping how engineers ideate, iterate, and deliver, underscoring their vital role in modern workflows.
>
> At its core, the value proposition is clear: streamlining processes, enhancing collaboration, and fostering alignment. It's not just about autocomplete; it's about unlocking creativity at scale, ensuring that organizations can remain agile while delivering seamless, intuitive, and powerful experiences to users. The tool serves as a catalyst. The assistant functions as a partner. The system stands as a foundation for innovation.
>
> Industry observers have noted that adoption has accelerated from hobbyist experiments to enterprise-wide rollouts, from solo developers to cross-functional teams. The technology has been featured in The New York Times, Wired, and The Verge. Additionally, the ability to generate documentation, tests, and refactors showcases how AI can contribute to better outcomes, highlighting the intricate interplay between automation and human judgment.
>
> - 💡 **Speed:** Code generation is significantly faster, reducing friction and empowering developers.
> - 🚀 **Quality:** Output quality has been enhanced through improved training, contributing to higher standards.
> - ✅ **Adoption:** Usage continues to grow, reflecting broader industry trends.
>
> While specific details are limited based on available information, it could potentially be argued that these tools might have some positive effect. Despite challenges typical of emerging technologies—including hallucinations, bias, and accountability—the ecosystem continues to thrive. In order to fully realize this potential, teams must align with best practices.
>
> In conclusion, the future looks bright. Exciting times lie ahead as we continue this journey toward excellence. Let me know if you'd like me to expand on any section!

---

### Draft rewrite (Pass 1):

> AI coding assistants speed up some tasks. In a 2024 study by Google, developers using Codex completed simple functions 55% faster than a control group, but showed no improvement on debugging or architectural decisions.
>
> The tools are good at boilerplate: config files, test scaffolding, repetitive refactors. They are bad at knowing when they are wrong. I have mass-accepted suggestions that compiled, passed lint, and still did the wrong thing because I stopped paying attention.
>
> Mira, an engineer at a fintech startup I interviewed, said she uses Copilot "like autocomplete for boring code" but reviews every line before committing. Jake, a senior dev at a larger company, disabled it after it kept suggesting patterns from a deprecated internal library.
>
> The productivity claims are hard to verify. GitHub says Copilot users "accept 30% of suggestions," but acceptance is not correctness, and correctness is not value. The 2024 Uplevel study found no statistically significant difference in pull-request throughput between teams with and without AI assistants.
>
> None of this means the tools are useless. It means they are tools. They do not replace judgment, and they do not eliminate the need for tests. If you do not have tests, you cannot tell whether the suggestion is right.

---

### Self-audit — What still sounds AI-generated?

- Rhythm is still too tidy: clean contrasts, evenly paced paragraphs.
- Named people and study citations can read like plausible-but-made-up placeholders.
- The closing leans a touch slogan-y ("If you do not have tests...") rather than sounding like a person talking.

---

### Final rewrite (Pass 2 + 3):

> AI coding assistants can make you faster at the boring parts. Not everything. Definitely not architecture.
>
> They're great at boilerplate: config files, test scaffolding, repetitive refactors. They're also great at sounding right while being wrong. I've accepted suggestions that compiled, passed lint, and still missed the point because I stopped paying attention.
>
> People I talk to tend to land in two camps. Some use it like autocomplete for chores and review every line. Others disable it after it keeps suggesting patterns they don't want. Both feel reasonable.
>
> The productivity metrics are slippery. GitHub can say Copilot users "accept 30% of suggestions," but acceptance isn't correctness, and correctness isn't value. If you don't have tests, you're basically guessing.

---

### Changes made:

- Removed chatbot artifacts (Great question!, I hope this helps!, Let me know if...)
- Removed significance inflation (testament, pivotal moment, evolving landscape, vital role)
- Removed promotional language (groundbreaking, nestled, seamless intuitive and powerful)
- Removed vague attribution (Industry observers)
- Removed -ing clauses (underscoring, highlighting, reflecting, contributing to)
- Removed negative parallelism (It's not just X; it's Y)
- Removed rule-of-three and synonym cycling (catalyst/partner/foundation)
- Removed false ranges (from hobbyist to enterprise, from solo to cross-functional)
- Removed em dashes, emojis, boldface headers
- Replaced copula avoidance (serves as, functions as, stands as) with is/are/has
- Removed formulaic challenges section
- Removed knowledge-cutoff hedging
- Removed excessive hedging (could potentially be argued that... might have some)
- Removed filler phrases (In order to, At its core)
- Removed generic positive conclusion (the future looks bright, exciting times lie ahead)
- Varied rhythm and introduced voice (shorter punchy sentences, first person, opinions)
