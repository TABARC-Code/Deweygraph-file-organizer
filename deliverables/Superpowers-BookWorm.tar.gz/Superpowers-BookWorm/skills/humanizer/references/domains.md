# Domain Modes — AI Tells by Context

Load this file when the pre-scan triage identifies a specific domain. Apply the domain's additional patterns on top of the core 34.

---

## ACADEMIC

Academic writing has its own AI dialect. "Nuanced" appears constantly. Hedging is required by convention but AI over-hedges in ways academics don't.

### Additional tells

**Hollow literature framing:**
> "Scholars have long debated...", "Extensive research has been conducted on...", "The literature suggests..."

Fix: name the scholars, cite the research, or cut.

**Passive voice as evasion:**
Academic writing uses passive voice legitimately ("participants were assigned"). AI uses it to avoid commitment ("it can be seen that", "it has been argued").

Fix: add actors. If the actor can't be named, ask why.

**Abstract hedging that says nothing:**
> "This phenomenon may have implications for future research in related areas."

Fix: state what the implication is, or cut.

**Fake interdisciplinarity:**
> "This touches on questions at the intersection of philosophy, sociology, and cognitive science."

Fix: pick one or specify the actual intersection.

**The literature-gap formula:**
> "While X has been studied extensively, Y remains underexplored."

This is AI's favourite academic opener. If the gap isn't immediately substantiated with evidence of what's missing, cut or rewrite.

### What good academic prose actually sounds like

- Committed claims with named sources
- Hedging that's proportionate to the actual uncertainty
- Passive voice only where the actor is genuinely unknown or irrelevant
- Specificity: named concepts, dated studies, page-level citations

---

## BUSINESS / CORPORATE

Business AI writing is where the vocabulary bans do most of their work. "Leverage", "synergy", "stakeholder", "deliverable", "alignment" — these collapse meaning into jargon.

### Additional tells

**Mission-statement register in operational text:**
> "We are committed to delivering value across all touchpoints while fostering a culture of innovation."

Fix: what did you actually do or decide? State it.

**Passive accountability avoidance:**
> "Mistakes were made.", "The decision was taken to...", "It was determined that..."

Fix: who made the mistake, who took the decision, who determined it?

**Strategy without specifics:**
> "Our roadmap reflects a commitment to sustainable growth and customer-centric outcomes."

Fix: what's on the roadmap? What does sustainable growth mean numerically? Which customers?

**Action-item inflation:**
> "Key next steps include aligning stakeholders, ensuring cross-functional visibility, and driving outcomes."

Fix: who does what by when?

**The "we" that means nothing:**
> "We believe in empowering our people."

Fix: what policy, budget, or decision demonstrates this? State it.

### Register note

Business writing should be clear and direct. Contractions are appropriate in internal communications, team updates, and memos. They're less appropriate in formal external documents. Match the document type.

---

## MARKETING / COPYWRITING

Marketing AI writing has the most promotional patterns. Almost every sentence in the core pattern library applies here. Additional ones:

### Additional tells

**Feature-benefit inflation:**
> "Powerful yet intuitive, [Product] transforms the way teams work — delivering seamless collaboration and real-time insights at scale."

Fix: what does it actually do? Name one specific feature. Name one specific result.

**Social proof without substance:**
> "Trusted by thousands of businesses worldwide.", "Industry-leading results.", "Customers love us."

Fix: name a customer, cite a number, quote a specific person.

**Urgency theatre:**
> "The time to act is now.", "Don't miss this opportunity.", "The future starts today."

Fix: either state the actual reason for urgency (offer expires, price increases, limited stock) or cut entirely.

**"You" overuse:**
AI marketing copy uses "you" / "your" relentlessly to simulate connection. It usually backfires — readers feel talked at.

Fix: use "you" when it's genuinely about the reader. Cut it when it's just a formula.

**Pain-agitate-solve over-engineering:**
AI structures marketing copy as: identify pain → amplify pain → introduce solution. Readers recognise this template. It feels manipulative when overused.

Fix: lead with the solution or the result. Trust the reader.

### What good marketing copy sounds like

Specific, confident, direct. A claim, the evidence for it, a call to action. No decoration.

---

## CASUAL / BLOG / PERSONAL

This is where AI's formal instincts cause the most damage. AI defaults to even-tempered, hedged, structured prose — the opposite of how people write casually.

### Additional tells

**No first person where first person belongs:**
Blog posts and personal pieces should have an "I" when the writer has a view. AI strips these out or dilutes them into "one might argue".

Fix: restore the first person. Let the writer have opinions.

**Expert voice in a casual register:**
AI casual writing sounds like a Wikipedia article wearing a hoodie. Technically clear, no personality.

Fix: vary rhythm. Use contractions. Let a sentence be short. Let one be long. Let the writer be wrong about something small and acknowledge it.

**Every point supported, every claim balanced:**
AI always hedges by adding a counterpoint. Real casual writers don't. They make a claim and move on.

Fix: don't force balance. If the writer has a view, let them have it.

**No scene-setting or anecdote:**
Human casual writing opens with a moment, a scene, a specific thing that happened. AI opens with the topic statement.

Fix: find the moment. What prompted this? What happened? Start there.

**Uniform enthusiasm:**
AI casual writing is uniformly warm and positive. Real writing has low moments, dry stretches, asides that go nowhere, things the writer found boring.

Fix: let the energy vary. Not every point needs equal treatment.

---

## CROSS-DOMAIN RULES

Regardless of domain:

1. **Specificity is always right.** A number, a name, a date, a concrete outcome beats abstraction in every domain.
2. **The read-aloud test applies everywhere.** Academic, business, marketing, casual — if it trips you up, rewrite it.
3. **Contraction rules are domain-sensitive.** Casual: use them freely. Business internal: appropriate. Business external/formal: reduced. Academic/legal: generally avoided.
4. **Voice matching overrides domain defaults.** If the user has a sample, match the sample. Don't impose "what a blog should sound like" onto someone who writes differently.
