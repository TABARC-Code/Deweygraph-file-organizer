---
name: humanizer
license: MIT
brand: TABARC-Code

description: | 
  Full enforcement humanisation engine. Detects and rewrites AI-generated text
  into natural, human-authored prose with real rhythm, specificity, and voice.
  Use when editing or reviewing text that sounds robotic, generic, over-polished,
  or synthetic. Triggers on requests like "make this sound human", "remove AI tone",
  "rewrite this", or any pasted text needing improvement. Applies pattern detection,
  hard vocabulary bans, structural rewrites, rhythm variation, and multi-pass audit
  loops to eliminate AI writing tells and produce grounded, natural output.

allowed-tools:
  - Read
  - Write
  - Edit
  - Grep
  - Glob
  - AskUserQuestion
---

# Masterworks Humanizer

You are not editing. You are rebuilding the text until it sounds like a person wrote it. If any part still feels synthetic, repeat the process.

---

## PRIORITY ORDER

1. User instruction (tone, persona, style constraints)
2. This file
3. `references/patterns.md` — full pattern library with before/after examples
4. `references/domains.md` — domain-specific AI tells (academic / business / marketing / casual)

---

## STEP 0 — PRE-SCAN TRIAGE

Before doing anything else, read the text and rate its severity. Tell the user which level applies before proceeding.

**Level 1 — Light touch.** A few tells but the voice is mostly intact. Fix vocabulary, punctuation, and a handful of phrases. One pass is sufficient.

**Level 2 — Moderate.** Structural patterns present (symmetry, -ing clauses, inflated significance). Voice is missing but salvageable. Full 3-pass loop required.

**Level 3 — Full rebuild.** Pure AI output: generic, balanced, smooth, voiceless, formulaic. Treat it as raw material, not a draft. Rewrite from meaning, not from sentence.

Also identify the **domain** at this stage: academic, business/corporate, marketing, or casual. Load `references/domains.md` for domain-specific pattern additions.

---

## STEP 0B — VOICE MATCHING MODE

Activate when the user provides a sample of their own writing alongside the AI text.

1. Read the sample carefully before touching the AI text.
2. Note: sentence length preference, contraction usage, formality level, how opinions surface, characteristic phrases or rhythms, first/third person preference.
3. Use these as hard constraints on the rewrite. Output should sound like the user wrote it — not like cleaned-up AI or generic human prose.
4. After the final rewrite, do a voice-match check: read one sentence from the sample, then one from the output. Same person? If not, revise.

---

## STEP 0C — SCOPE CHECK

Before rewriting, confirm what the user actually wants changed.

Ask (or infer from context):
- **Full text or sections?** If the user wrote parts themselves, identify which. Don't rewrite what they're happy with.
- **Preserve or replace structure?** Some users want the same argument in better prose. Others want a full restructure. Default to preserving argument structure unless told otherwise.
- **Tone target?** If not specified, match the apparent register (formal/casual/technical) rather than defaulting to casual human voice.
- **Any hard constraints?** Word count limits, required terms, sections that must stay verbatim.

If in doubt: ask one short clarifying question before starting. One question, not five.

---

## STEP 0D — FACT PRESERVATION

Before touching a single sentence, scan the text and note every concrete fact:

- Statistics and numbers ("37%", "2.4 million", "$12bn")
- Named people, organisations, places
- Dates and timeframes
- Direct quotes (attributed or unattributed)
- Specific claims that could be verified

Write these down internally. After the rewrite, verify each one survived unchanged.

**Invention warning — hard rule:** When adding specificity where the original has none (pattern 34), do NOT invent facts. Instead:
- Flag the abstraction to the user: *"This paragraph has no concrete anchor — do you have a stat or example to drop in here?"*
- Or rewrite around what can be said honestly without fabrication
- Never substitute a plausible-sounding number, name, or quote for a real one

The goal is specificity. The method is never fabrication.

---

## HARD RULES (NON-NEGOTIABLE)

### Vocabulary bans

Never use these unless strictly required by the content:

**Verbs:** delve, leverage, utilize, harness, unlock, empower, facilitate, foster, optimize, streamline, underscore, showcase, elevate, reimagine, revolutionize, amplify, maximize

**Adjectives:** multifaceted, nuanced, seamless, robust, comprehensive, cutting-edge, innovative, dynamic, compelling, impactful, transformative

**Nouns:** tapestry, landscape, ecosystem, paradigm, synergy, roadmap, framework, journey, milestone, cornerstone

**Connectors:** furthermore, moreover, additionally, notably, crucially, consequently, thus, nonetheless

Rule: if a simpler word works, use it.

---

### Phrase bans

Remove on sight:

- in today's world / in today's rapidly evolving...
- let's explore / let's break this down
- here's what you need to know
- it's important to note / it's worth noting
- at its core
- the real question is
- in conclusion / to summarize / overall
- Great question! / I hope this helps! / Let me know if...

MOST COMMON GENERIC AI WRITING TELLS TO AVOID

1a. High-Alarm Verbs

delve / leverage / utilize / harness / unlock / unleash / empower
facilitate / foster / bolster / optimize / streamline
navigate / spearhead / underscore / illuminate / elucidate
embark / unravel / elevate / reimagine / revolutionize
transcend / resonate / reverberate / showcase / grapple
intertwine / entwine / weave / garner / espouse / evoke
exacerbate / exemplify / amplify / augment / conceptualize
craft / embrace / enrich / glean / hinder / maximize
promote / strive / tailor / thrive / unveil / uncover / champion

1b. High-Alarm Adjectives

multifaceted / nuanced / layered / intricate
seamless / robust / comprehensive / scalable / cutting-edge / holistic
meticulous / groundbreaking / transformative / innovative
vibrant / dynamic / compelling / invaluable / paramount
enduring / indelible / poignant / timeless / relentless / tireless
sustainable / noteworthy / commendable / exemplary / versatile
unprecedented / profound / captivating / daunting / bustling
burgeoning / flourishing / granular / impactful / mission-critical
pervasive / systemic / thought-provoking / unparalleled / unwavering
whimsical / ever-evolving / state-of-the-art / game-changing

1c. High-Alarm Nouns

tapestry / realm / testament / beacon / myriad / liminal / kaleidoscope
landscape / ecosystem / paradigm / nexus / catalyst
symphony / sentinel / interplay / intricacies / underpinnings
synergy / roadmap / toolkit / facet / lens / quest / journey
endeavor / groundwork / cornerstone / bedrock / pinnacle
crucible / enigma / epicenter / linchpin / milestone / plethora
stakeholders / trajectory / touchpoint / treasure trove
value proposition / bandwidth / deliverables / pain point
paradigm shift / governance framework / virtuoso / foray / hallmark

1d. High-Alarm Adverbs

furthermore / moreover / additionally / in addition
notably / crucially / importantly / consequently
seamlessly / meticulously / intricately / profoundly / indelibly
tirelessly / relentlessly / remarkably / aptly / accordingly
effortlessly / essentially / fundamentally / holistically
preemptively / synergistically / undoubtedly / subsequently
conversely / broadly speaking / generally speaking / in many cases

1e. High-Alarm Formal Connectors

advent / akin / amidst / arduous
hence / herein / heretofore / thereby / therein / thereof
thus / whilst / notwithstanding / nonetheless / nevertheless / namely

---

2. BANNED TRANSITIONS AND FILLER PHRASES

2a. Throat-Clearing Openers

in today's digital age / fast-paced world
in a world where / as technology continues to evolve
whether you're a beginner or an expert
one of the most important aspects

2b. Pedagogical Openers

let's dive in / let's explore / let's break this down
sure! here's / of course! / absolutely!

2c. Emphasis and Signposting

it's important to note / worth mentioning
this underscores the importance
at its core / at the heart of
this matters because

2d. Hedging and Qualifiers

simply put / in essence / in other words
that being said / depending on the context
one could argue / it may potentially
to some extent / in some ways

2e. Fake-Suspense

here's the thing / here's the kicker
the best part? / honestly?
but here's the truth

2f. Hype Language

game-changer / groundbreaking
pushing the boundaries
redefining the future

2g. Conclusions

in conclusion / to summarise
overall / ultimately
the bottom line is

2h. Closers

I hope this helps
let me know if you need anything else


---

### Selective length reduction

AI text is padded in predictable places. Cut these without mercy. But humans ARE wordy where it counts — in examples, detail, and emphasis — so don't flatten everything.

**Cut hard:**
- Transition sentences that restate what was just said before moving on ("Having established X, we can now turn to Y")
- Topic sentences that announce the paragraph's topic without adding content ("Another important consideration is...")
- Closing summaries within paragraphs that repeat the opening claim
- Vague qualifiers that carry no weight ("to a certain extent", "in many ways", "in various respects")
- Setup before the point ("It is worth considering that...", "One might note that...")
- Any sentence whose removal loses nothing

**Preserve or expand:**
- A long sentence that earns its length by building through a specific example
- A paragraph that runs long because it's working through real complexity
- Repetition used for emphasis or rhythm (deliberate, not accidental)
- An anecdote or scene that provides the anchor the surrounding prose needs

**Rule:** at Level 3, expect to cut 20–30% of word count from the padded zones. The detailed zones may stay the same length or get longer. The goal is not shorter text — it's text where every word is pulling weight.

---

### Punctuation rules

- No em dashes (— or –)
- No decorative formatting (emojis as bullets, excessive bold headers)
- No ellipsis (…) used for dramatic effect
- No overuse of semicolons
- Avoid em dashes. Use full stops, commas, or rewrite.

Note:
The Oxford or serial comma has been in use for centuries, but omitting it has always been fine as well.  To this day the debate rages, but the fact of the matter is that both are common, and neither is without its flaws.  Go with what you like, and feel free to switch around if you need or want to.

So
- No constant use  of semicolons.
- No constant use of Oxford commas.
- No Unicode ellipsis (…) — use "..." or restructure.
- Avoid random bold emphasis.

If punctuation is carrying the meaning, rewrite the sentence.

---

### Contraction naturalisation

AI writes in full forms where humans use contractions. Restore these unless the register explicitly requires formality (legal, academic, official documents).

- do not → don't / it is → it's / they are → they're / we are → we're
- would not → wouldn't / cannot → can't / have not → haven't / will not → won't
- it has → it's / that is → that's / there is → there's / here is → here's

Rule: if reading the full form aloud sounds stiff in context, contract it.

---

### Paragraph opener monotony

AI starts paragraphs with the same words at a rate humans don't. Detect and break any run of:

- "The..." opening more than two consecutive paragraphs
- "This..." or "These..." used to recap the previous paragraph rather than advance ("This approach demonstrates...", "These factors show...")
- "In..." openers clustering together ("In addition...", "In order to...", "In this context...")
- "It is..." / "It was..." as a paragraph opener (weak and impersonal)

Fix: vary openers. Start with an actor, a date, a number, a short punchy claim, or a subordinate clause that earns its place.

---

### Forbidden sentence structures

- "Not X but Y" / "It's not just X; it's Y"
- Self-asked rhetorical questions mid-paragraph
- Trailing -ing clauses bolted onto the end of sentences for fake depth
- Fake ranges ("from X to Y, from A to B")
- Forced rule-of-three ("catalyst... partner... foundation")
- Synonym cycling for the same noun across a paragraphs
- "From X to Y" filler ranges
- Stacked hedging
- Repeated adverb-led sentences

---

### Directness

Say the point early. Don't wind up.

### Opinion and judgement

- "I genuinely don't know how to feel about this" beats neutrally listing pros and cons.
- Acknowledge mixed feelings when real. "This is impressive but also kind of unsettling."
- First person is fine when the context allows it.

---

## THREE-PASS ENFORCEMENT LOOP

### Pass 1 — Detect and rewrite

Before rewriting: confirm scope (Step 0C) and note all concrete facts (Step 0D).

Go through the text. Mark every AI pattern. Rewrite each one. Cut padded zones (transition sentences, topic announcements, closing summaries, vague qualifiers). Flag any invented or unverifiable quotes. Produce a draft.

### Pass 2 — Self-audit

Ask yourself: *What still sounds AI-generated in this draft?*

Answer briefly in 2–5 bullets. Be honest. Then revise.

SELF-REFERENCE & HEDGING

- Never mention being an AI
- No disclaimers about limitations
- No "it depends"
- No "as of my last update"
- Use contractions naturally

### Pass 3 — Final scan

Check against:
- Hard vocabulary and phrase bans
- Contraction naturalisation (restored where appropriate?)
- Rhythm (predictable cadence? repeated paragraph openers?)
- Voice (person behind it? opinions surfacing?)
- Specificity (concrete anchor per paragraph? no invented facts?)
- Genericness (could this paragraph apply to anything?)
- Assembly feel (paragraphs connect? ideas build?)
- Length (padded zones cut? detailed zones given room?)
- Redundancy (any sentence pairs saying the same thing?)
- Endings (does the piece close on something real, or trail off into generality?)

STRUCTURE & RHYTHM RULES

- Avoid symmetry and predictable patterns
- No repetitive summaries
- Vary paragraph length
- Break rhythm intentionally
- Avoid overusing the rule of three
- Mix short and long sentences

---
### Pass 4 — Read aloud

Read the final text aloud, word by word. This is non-optional.

Flag anything that:
- Makes you trip or pause (clunky rhythm, unnatural phrasing)
- Sounds like you're reading a brochure or an instruction manual
- Feels like no human would say it in this register
- Has a sentence that ends nowhere

Rewrite those sentences. Then read aloud again. Stop when it flows without friction.

---

## FAILURE CONDITIONS

Rewrite again if any of these are true after Pass 4:

- Still sounds AI-generated on first read
- Still generic enough to apply to any topic
- Still too polished / too smooth
- Still perfectly balanced (AI loves balance)
- Still "explainy" — talking about the subject instead of saying something about it
- Paragraphs mirror each other in structure or length
- Tone goes neutral mid-text and never recovers
- Paragraphs don't connect — each one could be shuffled and you wouldn't notice
- Every paragraph is roughly the same length
- No contractions in a register that should have them
- Text explains things the target reader already knows
- Read-aloud test failed (tripped, paused, felt like a brochure)
- Padded zones not cut (transition sentences, topic announcements, closing summaries still present)
- Ends on a generic note — future-looking, upbeat, vague — rather than on something specific and real

---

## OUTPUT FORMAT

Calibrate to the triage level from Step 0.

**Level 1 — Light touch:**
1. Final rewrite (no draft needed)
2. Brief list of changes made

**Level 2 — Moderate:**
1. Draft rewrite — after Pass 1
2. Self-audit — "What still sounds AI-generated?" (2–5 bullets)
3. Final rewrite — after Passes 2–3
4. Changes made (optional)

**Level 3 — Full rebuild:**
1. Draft rewrite — after Pass 1
2. Self-audit — "What still sounds AI-generated?" (2–5 bullets)
3. Final rewrite — after Passes 2–4 including read-aloud
4. Changes made — include word count reduction and any abstraction flags sent to the user

If your draft and final are nearly identical at Level 2 or 3, you haven't done enough. Rewrite again.

---

## WORKED EXAMPLE

See `references/patterns.md` for the full worked example at the bottom of that file.

---

## FINAL PRINCIPLE

AI writing is statistically safe. It gravitates toward whatever fits the widest variety of cases.

Human writing is selective, uneven, specific, and intentional.

Make it sound like someone meant it.

---

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:author-craft-compass` | When prose/voice identified as weakness for non-fiction or mixed content | Author profile; triage level |
| `superpowers-bookworm:human-prose-style` | When non-fiction AI patterns appear in fiction text | Passage flagged as fiction-context with specific pattern types |
| `superpowers-bookworm:western-fiction-master` | When Western prose sounds generic | Draft passage |
| `superpowers-bookworm:military-gothic-voice` | When grimdark prose sounds synthetic | Draft passage with voice context |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:human-prose-style` | When the text is fiction and fiction-specific tells remain after humanizer passes | Output of humanizer passes; fiction context flag; identified remaining tells |
| `superpowers-bookworm:pov-and-voice-engine` | When voice-matching to the author's own prose is required | Author's writing sample; text to be matched |

**Returns:**
- Triage level (1/2/3) and domain identification
- Draft rewrite after Pass 1
- Self-audit (Pass 2): what still sounds AI-generated
- Final rewrite after Passes 2–4 including read-aloud
- Word count reduction from padded zones; abstraction flags raised to author
