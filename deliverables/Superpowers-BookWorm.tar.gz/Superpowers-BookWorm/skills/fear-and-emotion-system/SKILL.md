---
name: fear-and-emotion-system
description: >
  Full taxonomy of fear states with physical and mental signatures.
  Applies darkness, sound, isolation, pacing, and euphonics to
  construct fear. Distinguishes between fear types and matches them
  to genre and scene function. Use for horror, thriller, suspense,
  and any genre requiring controlled reader anxiety. Draws on Hall's
  fear taxonomy and Ackerman/Puglisi's amplifier system. Triggers on:
  "scene isn't scary", "how do I write fear", "tension feels flat",
  "horror beats not landing", "dread isn't building", "character
  needs to feel more afraid", "create atmosphere".
---

# Fear and Emotion System

Fear is physical before it is psychological. Show the body. The reader's
body will follow.

---

## FEAR TAXONOMY (Hall)

Match the fear type to the scene function before writing:

| State | What it is | Physical signature | Sparing use? |
|-------|-----------|-------------------|-------------|
| **Suspense** | Urge to find out what happens | Racing heart, forward lean, page-turning compulsion | No — use throughout |
| **Unease** | Something wrong, source unknown | Cold trickle, nervous habits, pushed-around food, stilted speech | No — use freely |
| **Anxiety** | Danger is real and approaching | Shallow breath, crossed/uncrossed limbs, toilet urgency, dry throat | No — use freely |
| **Apprehension** | Knows the threat, not if it will come | Prickling scalp, acute hearing, locked ankles | No — use freely |
| **Foreboding** | Senses something bad without knowing what | Stomach heaviness, dry throat, faint hand tremor | Yes — once per scene |
| **Excitement** | Fear + joy, chosen risk | Racing heart, fast movement, warmth or chill in fingers | No — use freely |
| **Dread** | Knows something terrible is imminent | Chest pressure, nail-biting, dry mouth, can't meet eyes | Yes — 3-4 times per book |
| **Shock** | Sudden sustained dread | Gasp then silence, heavy stomach, disorientation, possible euphoria | Yes — once or twice per book |
| **Revulsion** | Fear + loathing | Covering mouth, backing away, gagging, flat eyes | Yes — brief, once or twice |
| **Horror** | Terror + awareness + possible revulsion | Wild heartbeat, profuse sweat, dulled senses | Yes — 2-3 times per book |
| **Terror** | Helpless in face of known, real threat | Paralysis, narrowed awareness, bladder/bowel urgency, can't scream | Yes — once per book maximum |
| **Panic** | Brief, intense, irrational | Hyperventilation, shaking, chest pain, impaired motor function, superhuman strength | Yes — once per book maximum |

---

## SHOW DON'T TELL — THE RULE

Naming an emotion is telling. Showing the body is showing.

**Banned constructions:**
- "She felt frightened."
- "He was terrified."
- "Fear washed over her."
- "He experienced a surge of terror."

**Required approach:** Physical sensation first. Implication follows.

```
✗  She was terrified.
✓  Fear clenched like a fist around her chest.

✗  He felt afraid.
✓  Cold sweat glued the shirt to his back.

✗  Panic set in.
✓  Her heart thudded so wildly it felt like it was trying to leave.
```

---

## PHYSICAL FEAR INVENTORY

Reference for variety. Never use all of these in one scene:

**Cardiovascular:** Heart hammers / pounds / races / thuds. Pulse in the
throat. Blood loud in the ears. Chest pressure.

**Respiratory:** Shallow breath. Can't get enough air. Breath stalls.
Hyperventilation. A strangling pressure on the throat.

**Skin:** Gooseflesh. Scalp prickling. Hairs standing. Crawling sensation.
Cold sweat at armpits and sides. Sweat gluing fabric to skin.

**Digestive:** Stomach clenching / knotting / dropping / turning to ice.
Nausea. Dry mouth. Coppery taste. Bile.

**Extremities:** Weak knees. Trembling hands. Numb fingers. Sudden
urge to empty the bladder.

**Cognitive:** Tunnel vision. Time distortion. Acute sensory awareness
(hearing sharpens). Intrusive irrelevant thought. Inability to speak.

---

## THE DARKNESS TOOLKIT (Hall)

Darkness multiplies every other fear technique. Use it wherever the plot allows.

**Five levels:**
1. **Absolute darkness** — No sight at all. Character gropes, hears everything, smells everything.
2. **Near-darkness** — Shapes only. Shadows that might be moving.
3. **Flickering light** — Candles, failing torches. Uncertainty worse than dark.
4. **Partial darkness** — Some areas lit, others not. What's in the dark corner?
5. **Gradual darkening** — Dusk to night, fire burning down. Ratchets tension steadily.

**When using darkness:** Prioritise hearing first, touch second, smell third. These
senses sharpen when sight is removed. Lean into what the character hears and
touches before describing what they can barely see.

---

## SOUND AS TENSION (Hall)

A single sentence about a background noise increases atmosphere more than
several sentences of visual description.

**At peak suspense moments:** Insert a completely irrelevant background sound.
This slows pace without dropping tension. Makes the scene feel real.

```
The knife came closer to her throat. And closer.
She squirmed against the bonds, knowing it was useless.
Somewhere in the distance, a car door slammed and a motor whined.
The cold edge of steel touched her skin.
```

**Collect sounds:** Hinges, dogs, water, distant arguments, engines, wind in
wire, rats, footsteps on specific surfaces, the particular creak of that one
stair. Specific sounds > generic sounds.

---

## ISOLATION MECHANICS (Hall)

Remove support layers systematically. Each removal increases fear:

1. Separate character from companions
2. Disable or remove communications (phone dead / no signal / lost / stolen)
3. Ensure nobody knows where the character is
4. Block or compromise escape routes
5. Remove tools, weapons, or resources
6. Ensure no lucky rescue is possible

A character who can call for help is never truly in danger. The reader knows it.

---

## EUPHONICS — SOUND PSYCHOLOGY (Hall)

Letter sounds create subconscious emotional effects. Apply in revision, not
drafting. Replace some words with euphonically appropriate synonyms where
meaning permits:

| Effect desired | Sounds to use | Examples |
|---------------|--------------|---------|
| Foreboding | OW, OH, OU, OO | howl, moor, doom, slow, wound, groan |
| Spookiness | S + short I | hiss, whisper, sinister, sizzle, crisp |
| Acute fear | EE/EA + S | scream, creak, squeeze, steal, shriek |
| Action/fight | T, P, K hard | cut, block, kick, tackle, crack |
| Running | R + short vowels | run, race, scurry, rip, hurtle |
| Trouble ahead | TR cluster | trap, trick, trouble, traitor, tread |

**Door euphonics as example:**
- Foreboding: "The door groaned open."
- Spooky: "The door whispered shut."
- Fear: "The door creaked open. The door squealed shut."

---

## THE DOOR EFFECT (Hall)

Put any threshold between character and danger. Linger there before crossing.

1. Describe the door (material, condition, any danger clues)
2. Describe the approach — the weight of the key, the sound of the bell
3. Describe the sound as it opens
4. Describe the sound as it closes behind them (implies trap, blocks retreat)

Works for: literal doors, cave mouths, archways, gates, stiles, gaps in hedges,
trapdoors, portals. Any liminal point.

---

## PEAKS AND TROUGHS (Hall)

Constant fear anaesthetises. Reader needs recovery to feel fear again.

```
[PEAK]    — intense fear event
[TROUGH]  — brief relief: clean air, small win, tenderness, moment of hope
[PEAK]    — fear hits harder because of the contrast
```

Troughs can be one paragraph. A single sentence of relief is enough.
The peak only exists because of the trough beneath it.

**Trough examples:**
- Character reaches safety and catches breath
- Moment of connection or kindness amid danger
- Physical comfort (warmth, food, rest)
- Brief false security (worst kind of trough — safety that isn't)

---

## THE WIMP TEST (Hall)

Each instance earns one Wimp Point. Too many and the protagonist reads as
helpless rather than frightened.

**Wimp Point triggers:**
- Sighing, exhaling, taking deep breaths (each instance)
- Shrugging
- Hesitating without narrative justification
- Visceral response to something minor (a banging door, a shadow)
- Passive emotional wallowing beyond one sentence
- Crying (more than once)
- Internal dialogue between "parts" of the psyche
- Nervous habits: lip-biting, nail-chewing, jaw-dropping
- "Tried to", "attempted to", "endeavoured to"
- "Felt" + named emotion
- "Found himself/herself" doing something
- Body parts acting independently ("Her legs stepped forward")

**Thresholds:** 3 Wimp Points per scary scene. 10-15 per full book.
Romance allows slightly more. Thriller allows fewer.

Courage and fear coexist. A frightened character can still act decisively.
The Wimp Effect comes from a character who only reacts, never chooses.

---

## CAPTIVITY SCENES (Hall)

Imprisonment heightens fear through total isolation, sensory
deprivation or assault, and the removal of agency. The reader's
fear comes from helplessness, not danger. A captive character
who is still thinking, planning, and hoping creates tension.
One who only despairs is inert.

**Making it frightening:**

- Darkness where possible. No light, or near-darkness with a sliver
  showing from under the door. Make the character rely on other senses.
- Cold. Unheated space, concrete floor, inadequate covering, chill air.
- Solitary. No companion, or companion taken away mid-scene.
- The sounds of what is happening elsewhere — screams, footsteps, keys.

**Sensory priorities for captivity (in order of impact):**

*Hearing — highest impact:*
Rodent feet. Fellow captive's breathing. Screams from another cell.
The clanking of a door. The specific sound of keys on a ring.
Guard boots on stone. Silence that suddenly changes.

*Touch — high impact:*
Fetters or bonds chafing at wrists and ankles. Pain from bruises.
The texture of the wall (rough stone, damp brick, smooth tile).
The temperature of the floor. Cobwebs. Cold air moving.

*Smell — use sparingly, once:*
Sour urine. Old sweat. Damp straw. Mould. The smell of food
if hunger is an amplifier being deployed.

*Sight — lowest impact, use least:*
Barely visible shapes. Moving darkness. The sliver of light
under the door. Rapid movement at floor level.

*Taste — only if relevant:*
A gag. The metallic taste of fear. Bile. The particular
flavour of whatever inadequate food is provided.

**The thinking character:**

While captive, the character must not wallow. They can feel despair.
They cannot sit in it. Show them:
- Exploring the space for any weakness
- Trying to understand their captors' patterns
- Forming a plan — even a bad one
- Preserving some small private resistance

A tiny hope is more frightening to withdraw from the reader than
no hope at all. Create it. Then threaten it.

**Revulsion in captivity:**
Prison and dungeon settings are the appropriate place for a single
brief revulsion beat — one sentence, one smell, one thing glimpsed
at floor level. Do not extend it. The reader absorbs revulsion quickly
and then becomes numb to it.

---

## THE NINE-PART SCARY SCENE STRUCTURE (Hall)

A template for major scary scenes. Not mandatory for every scene, but use
it as a blueprint for setpiece horror moments and climax scenes.

**Part 1 — Scene goal.**
State what the protagonist needs and why failure is dire. Keep it short.
One paragraph. Emotion: anxiety, apprehension. Dominant fear: dread.

**Part 2 — Suspense.**
Protagonist enters dangerous territory. Often crosses a threshold (door,
gate, cave mouth). Describe the approach. Use sound. Use darkness. The
protagonist's goal still seems achievable. Emotion: foreboding, dread.

**Part 3 — Increased danger.**
Things are worse than expected. Allies fail. Tools break. Communication
cuts out. The protagonist must still take action — not just react.
Emotion: apprehension mixed with frustration. Reader: suspense.

**Part 4 — First confrontation.**
Protagonist meets a henchman, guard, or minor obstacle, not the main
threat. Physical confrontation possible. Use hard euphonics. Vary sentence
length. Short sentences in fighting. Emotion: excitement, revulsion.

**Part 5 — Escape.**
Narrow escape from Part 4. Very fast pace. Short sentences, short words.
Character runs or outsmarts but does not fully win.

**Part 6 — Trough.**
Brief false safety. Protagonist thinks they're through it.
One paragraph only. Do not let the reader relax for long.

**Part 7 — Realisation.**
Protagonist discovers they've made a mistake. The escape was incomplete.
They've walked deeper into the trap. Panic is possible here — a single
bad decision made under pressure.

**Part 8 — Main confrontation.**
Protagonist meets the actual threat. This is the longest section.
Full fear at maximum: dread, terror, or horror as appropriate.
Short sentences throughout. Outcome uncertain until the end.
The villain/monster has every advantage.

**Part 9 — Aftermath.**
Protagonist escaped or is captive. Acute danger has passed.
Pace slows: longer sentences. Character assesses situation.
Ends with a concrete decision about next action — not reflection.

---

## SCENE-LEVEL APPLICATION

When constructing a scene requiring fear:

1. Identify the target fear state from the taxonomy
2. Decide whether this is a setpiece (use 9-part structure) or atmospheric beat
3. Choose darkness level if applicable
4. Plan peak/trough rhythm — Part 6 is the trough; Parts 1-5 and 7-9 are peaks
5. Select 2-3 physical symptoms appropriate to the fear level
6. Prepare 1-2 background sounds for the setting
7. Check for isolation completeness
8. Draft, then revise for euphonics and Wimp Points

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, genre confirmed
  (horror / thriller / suspense), and weakness identified (fear not landing /
  dread not building / tension flat). Identify the target fear state from the
  taxonomy first. If the project is horror-led, route to horror-craft-module
  first for thematic spine and structural framework, then return here for
  body-level mechanics.

- `superpowers-bookworm:horror-craft-module` — arrives with: subgenre, tonal register, and target
  fear type already established. Do not re-run taxonomy selection; the horror
  module has already done that. Focus on: physical symptom selection for the
  identified fear state, darkness toolkit application, peak/trough rhythm,
  and wimp test audit. The horror module handles thematic structure; this
  skill handles the moment-to-moment body mechanics.

- `superpowers-bookworm:hook-and-tension-system` — arrives with: hook type (usually Foreshadowing
  with Warning or Ticking Clock) and scene position. Calibrate dread and
  suspense specifically. Select 2-3 physical symptoms appropriate to the
  hook's target fear state. Apply euphonics to the passage where the hook
  lands.

- `superpowers-bookworm:scene-construction-engine` — arrives with: scene type (scary / crisis /
  escape / captivity) and pace requirement. Apply the appropriate fear state
  from the taxonomy. Match pacing techniques (fast/slow) to scene type.
  Check isolation completeness.

**Sends to:**

- `superpowers-bookworm:character-depth-engine` — when an amplifier state is being applied and
  its effect on character decision-making needs to be worked through. Hand
  off: amplifier type (cold / exhaustion / pain / stress etc.) and the
  decision point in the scene. That skill handles how the amplifier warps
  the character's choices given their specific psychology.

---

## WHEN CALLED

1. Identify the fear state the scene is trying to create
2. Ask: does the scene show physical symptoms or only name emotions?
3. Check isolation completeness and darkness level
4. Count Wimp Points in any existing draft
5. Recommend the fewest changes that raise the fear level most
