---
name: managing-draft-branches
description: Use when starting any experimental story direction, alternate ending, POV experiment, or structural test that should not be committed to the working draft. Creates an isolated branch workspace sharing the project structure. Triggers on: "try an alternative ending", "experiment with POV change", "test a structural idea", "explore a different direction", or before any experimental drafting work.
---

# Managing Draft Branches

## Core Idea

Experimental story directions, alternative POVs, structural experiments, and alternate endings need isolation from the working draft. Draft branches create an independent workspace in the same repository, sharing the project structure but not the working draft's commit history.

## Core Principle

Never experiment on the working draft. Branch first, experiment second.

**Announce at start:** "I'm using the managing-draft-branches skill to set up an isolated draft workspace."

## Directory Selection

### 1. Check for existing branch directory

```bash
ls -d .draft-branches 2>/dev/null   # preferred (hidden)
ls -d draft-branches 2>/dev/null    # alternative
```

If found: use it. `.draft-branches` wins if both exist.

### 2. Check CLAUDE.md for preference

```bash
grep -i "draft.branch\|branch.*director" CLAUDE.md 2>/dev/null
```

If preference found: use it without asking.

### 3. If no directory and no CLAUDE.md preference, ask

```
No draft branch directory found. Where should I create draft branches?

1. .draft-branches/ (project-local, hidden)
2. ~/.config/superpowers-bookworm/branches/[project-name]/

Which?
```

## Safety Verification

For project-local directories — MUST verify directory is git-ignored:

```bash
git check-ignore -q .draft-branches 2>/dev/null
```

If NOT ignored: add to .gitignore, commit the change, then proceed. Prevents draft branch content accidentally appearing in the working draft's git history.

## Creation Steps

### 1. Identify branch name from the experiment purpose

- `alt-ending-v2` — alternate ending
- `pov-shift-ch4-8` — POV experiment on chapters 4-8
- `restructure-act2` — structural experiment on act 2
- `timeline-flashback` — alternative timeline approach

### 2. Create the draft branch

```bash
git worktree add .draft-branches/[branch-name] -b draft/[branch-name]
cd .draft-branches/[branch-name]
```

### 3. Verify clean baseline — check continuity log is intact

```bash
# Confirm key project files are present
ls docs/novel-superpowers/continuity-log.md
ls docs/novel-superpowers/bibles/
```

If files are missing: report, ask whether to proceed.
If files are present: report branch ready.

### 4. Report

```
Draft branch ready at .draft-branches/[branch-name]
Continuity log present. Story bible present.
Working on: [branch purpose]
Working draft is unchanged on [main/draft-main] branch.
```

## Quick Reference

| Situation | Action |
|-----------|--------|
| `.draft-branches/` exists | Use it (verify ignored) |
| `draft-branches/` exists | Use it (verify ignored) |
| Both exist | Use `.draft-branches/` |
| Neither exists | Check CLAUDE.md → Ask author |
| Directory not ignored | Add to .gitignore + commit first |
| Project files missing | Report + ask before proceeding |

## Common Mistakes

- Experimenting directly on the working draft — always branch first
- Assuming directory location — follow priority order
- Not verifying the directory is git-ignored — results in draft experiments appearing in commit history

## Integration

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:story-brainstorming` | When alternate story directions need exploration before committing to a bible | Story direction under consideration |
| `superpowers-bookworm:subagent-driven-drafting` | Before structural experiments in the working draft | Experiment type and scope |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:finishing-a-draft-branch` | When experimental work is complete and a decision is needed | Branch name; continuity log; what the experiment addressed |
| `superpowers-bookworm:continuity-verification` | When baseline check is needed after branch is created | Branch content; continuity log |
| `superpowers-bookworm:managing-writing-projects` | When project structure needs review before branching | Project root; git configuration |

**Returns:**
- Branch created at `.draft-branches/[name]`
- Continuity log verified as present in branch
- Story bible verified as present in branch
- Working draft confirmed unchanged on main branch
