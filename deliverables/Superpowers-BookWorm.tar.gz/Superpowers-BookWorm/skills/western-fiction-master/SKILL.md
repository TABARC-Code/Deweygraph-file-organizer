---
name: western-fiction-master
metadata:
  classification: TABARC-Code
  studio: TABARC-Studio Internal Use
description: >
  Complete craft system for writing Western fiction across all subgenres — traditional, revisionist, weird, romantic, comedic, Northern, and contemporary. Use this skill whenever the user wants to write, plan, draft, edit, or improve any Western story, novel, screenplay, or short fiction. Also triggers for: crafting frontier characters (lawmen, outlaws, settlers, Native Americans, soldiers), writing gunfights or action scenes set in the Old West, building period-accurate setting and dialogue, avoiding historical anachronisms, handling race and gender authentically in frontier fiction, developing a Western plot structure, or choosing a Western subgenre. This skill contains nine fully interlocking subskills. Always read this core file first, then navigate to the relevant subskill(s) based on the user's immediate need.
---

# Western Fiction: Core Craft System

## What This Skill Does

This is an orchestrated, multi-layer system for writing Western fiction at a professional level. It synthesises genre knowledge, historical accuracy, character psychology, weapons craft, authentic dialogue, diversity awareness, and narrative technique into a single coherent framework. The subskills are bidirectionally linked: you can enter anywhere in the system and navigate in any direction.

---

## Navigation Map

Each subskill is a self-contained module. Read the ones relevant to the task. All cross-link to each other.

| # | Subskill | When to Load |
|---|----------|--------------|
| 01 | [Genre Architecture](subskills/01-genre-architecture.md) | Choosing subgenre, understanding genre history, finding your Western's category |
| 02 | [Setting & Place](subskills/02-setting-and-place.md) | Building locations, choosing era, geography, frontier infrastructure |
| 03 | [Character Craft](subskills/03-character-craft.md) | Lawmen, outlaws, gunslingers, settlers, women, supporting cast |
| 04 | [Weapons & Violence](subskills/04-weapons-and-violence.md) | Firearms accuracy, gunfight choreography, physical realism of combat |
| 05 | [Historical Accuracy](subskills/05-historical-accuracy.md) | Anachronism prevention, research methodology, period transport and technology |
| 06 | [Dialogue & Language](subskills/06-dialogue-and-language.md) | Authentic frontier speech, era-accurate slang, profanity, ethnic voices |
| 07 | [Diversity & Representation](subskills/07-diversity-and-representation.md) | Native Americans, Hispanics, Black characters, women, LGBTQ+ in the West |
| 08 | [Narrative Craft](subskills/08-narrative-craft.md) | Plot structures, conflict engines, pacing, sex and violence, the human touch |
| 09 | [Glossary & Reference](subskills/09-glossary-reference.md) | Authentic Western terms, slang, historical timeline, quick lookup |

---

## Core Principles (Always Active)

These govern every subskill. Keep them loaded in working memory regardless of which module you're reading.

### 1. The West Is What You Make It

There is no single "correct" location or era for a Western. The frontier existed anywhere from colonial New York to twentieth-century Mexico, Yukon Canada to the sagebrush Southwest. An author who commits to a place and time and writes it with conviction is more compelling than one who plays it safe with generic iconography.

### 2. Accuracy Is Non-Negotiable at the Basics

Western readers are a knowledgeable audience. They will catch anachronistic firearms, impossible train routes, wrong-era slang, and misplaced technology. Factual errors destroy trust and can cost you sales. Historical accuracy is not optional — it is the foundation on which you build your fiction.

### 3. Characters Are Human First

No hero is without flaw. No villain is without motivation. The most compelling Western characters — lawmen who commit crimes, outlaws who show mercy, settlers who are cowards — occupy morally ambiguous territory. Cardboard heroes and cardboard villains belong in the dime novels of 1860. Modern Western readers want complexity.

### 4. Stereotype Is a Career Killer

Racial stereotypes, gender clichés, and lazy ethnic shorthand will get manuscripts rejected. The historical West was racially diverse, and that diversity should enrich your fiction — not flatten it into Hollywood's pre-1960s whitewash. Authentic portrayals require research.

### 5. The Genre Is Alive

Western fiction is not a museum piece. Publishers release new Western novels every week. The subgenres — Weird Western, romantic Western, revisionist Western, contemporary Western — are actively growing. You are not writing for nostalgia alone. You are writing for a living market.

---

## Workflow: How to Use the Subskills

### Starting a New Story
`01 → 02 → 03 → 08` (Genre → Setting → Character → Narrative structure)

### Writing an Action or Combat Scene
`04 → 05 → 06` (Weapons → Historical accuracy → Authentic dialogue under fire)

### Writing Diverse Characters
`07 → 03 → 06` (Diversity grounding → Character psychology → Voice and dialect)

### Fixing Authenticity Problems
`05 → 09 → 06` (Accuracy audit → Glossary check → Dialogue review)

### Building a World
`02 → 09 → 05` (Setting → Reference terms → Technology/timeline check)

### Writing Gunfighter or Outlaw POV
`03 → 04 → 06 → 08` (Character → Weapons → Voice → Narrative weight)

### Writing Women or Minority Characters
`07 → 03 → 06 → 08` (Representation grounding → Psychology → Voice → Narrative function)

### Subgenre Exploration
`01 → 08 → 02` (Genre identity → Narrative mechanics → Setting calibration)

These are starting paths, not rigid rules. All subskills are bidirectional: every subskill links back to this core and across to its siblings. Follow the links where your draft takes you.

---

## Quick Diagnostic: Common Western Writing Failures

Run this before submitting any Western draft for feedback.

- [ ] **Anachronism check** — Are all weapons, technology, slang, and transport correct for the year? → Load `05`
- [ ] **Character flatness** — Do heroes and villains have contradictions, flaws, and genuine motivation? → Load `03`
- [ ] **Stereotypes** — Are minority or female characters fuller than Hollywood archetypes? → Load `07`
- [ ] **Gunfight realism** — Is the violence physically plausible and emotionally consequential? → Load `04`
- [ ] **Dialogue authenticity** — Does period speech feel genuine without being impenetrable? → Load `06`
- [ ] **Subgenre coherence** — Does the story know what kind of Western it is? → Load `01`
- [ ] **Setting specificity** — Does the location feel like a real place, not a painted backdrop? → Load `02`
- [ ] **Human touch** — Do readers have reason to care about each character's fate? → Load `08`

---

## Subskill Interlinks (Bidirectional Matrix)

Every subskill is aware of every other. This matrix shows primary cross-dependencies:

```
01 (Genre)       ←→ 02 (Setting), 08 (Narrative)
02 (Setting)     ←→ 01 (Genre), 05 (Accuracy), 09 (Glossary)
03 (Character)   ←→ 04 (Weapons), 06 (Dialogue), 07 (Diversity), 08 (Narrative)
04 (Weapons)     ←→ 03 (Character), 05 (Accuracy), 08 (Narrative)
05 (Accuracy)    ←→ 02 (Setting), 04 (Weapons), 06 (Dialogue), 09 (Glossary)
06 (Dialogue)    ←→ 03 (Character), 05 (Accuracy), 07 (Diversity), 09 (Glossary)
07 (Diversity)   ←→ 03 (Character), 06 (Dialogue), 08 (Narrative)
08 (Narrative)   ←→ 01 (Genre), 03 (Character), 04 (Weapons), 07 (Diversity)
09 (Glossary)    ←→ 02 (Setting), 05 (Accuracy), 06 (Dialogue)
```

## Cross-Reference Network — System Level

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:author-craft-compass` | When Western genre is the identified genre | Author profile: stage, strength, weakness |
| `superpowers-bookworm:genre-craft` | When Western fiction needs the full craft system | Genre confirmed as Western |
| `superpowers-bookworm:using-novel-superpowers` | When author requests Western fiction support | Project context |

**Calls out to — Superpowers-BookWorm system:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:historical-fiction-master` | Period accuracy requirements; the Western is a period genre and must meet historical fiction research standards | Era, region, specific accuracy questions |
| `superpowers-bookworm:character-depth-engine` | When lawman, outlaw, settler, or gunfighter needs full wound/lie/flaw/arc profile | Character archetype, story role, Western-specific constraint |
| `superpowers-bookworm:hook-and-tension-system` | When pacing of non-action scenes needs work | Scene sequence needing tension |
| `superpowers-bookworm:humanizer` | When Western prose sounds generic or AI-generated | Draft passage |
| `superpowers-bookworm:continuity-verification` | Before any scene involving period-specific facts (firearms dates, legal institutions, rail routes) | Scene draft with period claims |
| `superpowers-bookworm:author-craft-compass` | When compatible skills for the project need identification beyond the core cluster | Author profile |

**Returns to callers:**
- Subgenre identified and genre contract established
- Historical accuracy baseline for the specific period and region
- Character archetypes grounded in historical reality
- Dialogue authenticity with period-verified vocabulary
- Quick diagnostic checklist result
