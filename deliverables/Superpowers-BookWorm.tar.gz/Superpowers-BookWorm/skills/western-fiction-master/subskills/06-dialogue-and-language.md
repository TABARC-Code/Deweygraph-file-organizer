# 06 — Dialogue & Language

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [03 Character](03-character-craft.md) | [05 Accuracy](05-historical-accuracy.md) | [07 Diversity](07-diversity-and-representation.md) | [09 Glossary](09-glossary-reference.md)

---

## The Goal: Authenticity Without Opacity

Period dialogue serves two masters: it must feel genuinely rooted in its era, and it must be readable and comprehensible to a modern audience. These goals are not mutually exclusive, but balancing them requires craft.

The wrong approach: phonetic spelling of every regional accent, full dialectal immersion that forces readers to decode rather than read, and anachronistic slang that jolts the reader into the present.

The right approach: selective deployment of period vocabulary, character-specific voice that reflects background and status, and a prose rhythm that feels of the era without being impenetrable.

---

## Era-Accurate Vocabulary: The Research Baseline

The tool is the **Online Etymology Dictionary** (etymonline.com). Before you write a line of dialogue you're uncertain about, look up the first documented usage. This is not optional — it is the craft standard for historical fiction.

**Key examples of period-specific first uses:**
- *Flash in the pan* (a misfire): period — this is where the phrase originates
- *Keep your powder dry*: period — directly from muzzle-loading firearm use
- *Don't go off half-cocked*: period — from flintlock half-cock safety position
- *Pissed off* (angry): 1946 — not period for any classical Western setting
- *High noon* as a dramatic phrase: period
- *Bite the dust*: period (documented in Homer, long before the West)
- *Shit-faced*: 1960s — not period

The glossary in [09 Glossary & Reference](09-glossary-reference.md) provides a working list of authentic frontier terms.

---

## Profanity in Western Fiction

The frontier was not genteel. Profanity existed and was used with creativity. But its use in fiction must be period-accurate.

**What's period-accurate:**
- *Shit*, *damn*, *hell*, *bastard*, *whore*, *son of a bitch* — all period
- *Piss* as a verb: attested from the 12th century
- *The flying fuck* (sex on horseback; the phrase in use figuratively from about 1800)
- *Hooker* (prostitute): attested from 1845; in John Russell Bartlett's 1859 Dictionary of Americanisms — fully period
- *Soiled dove* (prostitute): period and widespread frontier usage

**What is NOT period-accurate:**
- *Fuck off* as a dismissal: 1929
- *Shit-faced* (drunk): 1960s
- *Pissed off* (angry): 1946
- *Tits* (breasts): not documented before 1928 — not frontier usage
- *Pussie* as genital slang: not documented before 1879 (use of *pussie* as a general term for a woman is earlier and period-accurate; the sexual-anatomical sense is not)
- Modern intensifiers and compound slang of all kinds

**The euphemism tradition:** Many frontier speakers used softer alternatives in mixed company or in print. *Blame* or *dash* for *damn*, *blazes* for *hell*, *by gum* as a general oath (likely euphemising "by God"). Some editors writing for period publication cleaned up dialogue completely. Know your publication target — a Christian Western publisher will not accept frontier profanity regardless of its historical authenticity.

**HBO's Deadwood approach:** The series used profanity at Shakespearean density and invention — partly accurate in spirit, partly anachronistic in specifics. Stylistically compelling, but not a guide for period authenticity.

---

## Building Authentic Period Voice

Every character on the frontier had a distinct verbal world shaped by:

**Regional origin:** A New England schoolmarm sounds different from a Texas cowboy sounds different from a Kentucky mountain man. The regional accents and vocabulary of nineteenth-century America were more pronounced than today, partly because mass media hadn't homogenised speech.

**Literacy level:** A ranch hand with three years of schooling does not speak like a newspaper editor. Vocabulary, sentence structure, and reference points differ.

**Occupation:** Cowboys had specific vocabulary (see [09 Glossary](09-glossary-reference.md)) for their tools, animals, terrain, and tasks. A cowboy's metaphors come from cattle, horses, and open country. A miner's metaphors come from ore, shafts, and rock. A lawman's metaphors come from legal process and violence.

**Social class and aspiration:** A frontier businessman striving for respectability speaks carefully, avoids profanity, and imitates the Eastern establishment he admires. A drifter who doesn't care about social standing speaks rawly.

**National origin:** European immigrants (significant in the West — Irish, German, Scandinavian, Chinese, Italian) carried their original language and accent into English use. This should be handled carefully — see below.

---

## Minority Voices: Deft Touch Required

**→ For full treatment of minority characterisation, load [07 Diversity & Representation](07-diversity-and-representation.md)**

### The Central Rule
Stereotypical dialectal writing — eye dialect designed to signal "otherness" rather than capture genuine speech — is both artistically lazy and potentially offensive. It has cost writers editors, audiences, and reputations.

### Hispanic characters
Spanish-language insertion can authentically flavour dialogue. A border character might call out "*¡Deja tu arma y levanta las manos!*" (Drop your gun and raise your hands). The rule: use it selectively, provide context or translation, and do not make the character's foreignness the joke. Avoid the "Ay caramba!" shorthand entirely.

### Black characters
The prohibition against teaching enslaved people to read and write (and its legacy in restricted educational access for freed people) affected literacy patterns among Black frontier characters. This is a specific historical condition, not a template for making every Black character speak in exaggerated dialect. Nat Love, Frederick Douglass, and Edwin McCabe (state auditor of Kansas) were educated, articulate, sophisticated individuals. The full range of education and eloquence existed in the Black West, as it did everywhere else.

### Chinese characters
The pidgin-English caricature ("No tickee, no washee!" with every syllable mangled) is a racist relic with no place in serious fiction. Chinese residents of the West ranged from poorly-educated labourers to sophisticated merchants, tong leaders, and professionals. Their English ranged accordingly.

### Native American characters
Tonto-speak ("Him go that way. Him bad man.") is specifically a 1930s radio caricature that has no relationship to any actual Native American language or speech pattern. Native Americans speaking English in the nineteenth century had learned it as a second language — their patterns would reflect their original language's structures, not a Hollywood shorthand. This requires individual research into specific tribal languages and cultures.

### The rule in practice
A deft touch means: selective, purposeful, and grounded in research. One or two specifically researched features of a character's speech background. Never a wall of eye dialect. Never a catchphrase-level stereotype.

---

## Dialogue for Different Social Contexts

### The Saloon
The social information exchange of the frontier. Dialogue here is informal, information-dense (rumour, gossip, threat, deal-making), and often guarded. Men in saloons talk to size each other up. Watch what they don't say as carefully as what they do.

### The Courtroom or Legal Hearing
Formal, procedural, and often a stage for display. Frontier lawyers were sometimes untrained and often theatrical. The legal system in real frontier towns frequently resembled improvisation more than jurisprudence.

### Between Cowboys on the Trail
Working speech. Short, practical, about cattle and terrain. Extended philosophical monologue on the trail is cinematic, not realistic — unless something has happened to prompt it.

### A Gunfighter Calling Someone Out
Almost certainly not the measured, formal "I'm calling you out" of Hollywood. More likely a sudden escalation from a verbal dispute, often with bystanders shouting and backing away. The formal speech of the mythological Western challenge ("Draw.") exists in dime novels, not historical records.

---

## Idioms: The Period Flavour

Deploy authentic frontier idioms for texture. A few usable examples:

- *Above snakes* — alive (above ground)
- *Among the willows* — hiding from the law
- *Airin' the lungs* — cursing
- *Bake a horse* — ruin a horse by extended hard riding
- *Ballast* — money
- *Bed him down* — kill a man
- *Big jump* — death
- *Bone orchard* — cemetery
- *Boot hill* — cemetery (where men who died with their boots on are buried)
- *Burn the breeze* — ride at top speed
- *Calaboose* — jail
- *Cash in* — die
- *Equaliser* — pistol
- *Get a wiggle on* — hurry
- *Iron* — firearm (especially pistol)
- *Peel your hide* — skin you alive (a threat)
- *Range delivery* — theft (stealing cattle)

Full glossary: [09 Glossary & Reference](09-glossary-reference.md)

---

## Dialogue Common Errors Checklist

Before submitting dialogue for critique:

- [ ] **Anachronistic slang** — Has every non-obvious phrase been checked against the Online Etymology Dictionary?
- [ ] **Generic "period" voice** — Do different characters sound different, or do they all sound like "old Western movie"?
- [ ] **Stereotypical minority dialect** — Are non-white characters given the same individual voice treatment as white characters?
- [ ] **Over-phoneticism** — Is the text decipherable, or has accent-spelling made it a puzzle to read?
- [ ] **Exposition in dialogue** — Are characters explaining things to each other that they already know, simply to inform the reader?
- [ ] **Missing subtext** — Are characters saying exactly what they mean, when historical frontier speakers were often guarded, indirect, or coded in their real meaning?

---

**→ Continue to:** [07 Diversity & Representation](07-diversity-and-representation.md) | [09 Glossary](09-glossary-reference.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [05 Accuracy](05-historical-accuracy.md)
