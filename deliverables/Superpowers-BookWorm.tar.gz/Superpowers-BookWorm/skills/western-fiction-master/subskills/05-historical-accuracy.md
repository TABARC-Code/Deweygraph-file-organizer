# 05 — Historical Accuracy

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [04 Weapons](04-weapons-and-violence.md) | [02 Setting](02-setting-and-place.md) | [06 Dialogue](06-dialogue-and-language.md) | [09 Glossary](09-glossary-reference.md)

---

## The Contract with Western Readers

Western fiction fans are a self-educating readership. Many know the era's milestones and minutiae with genuine depth. When you get a detail wrong — a weapon that wasn't invented yet, a railroad that didn't reach that town until a decade later, slang that didn't enter the language until 1930 — they notice. They write to publishers. They leave one-star reviews. More fundamentally, they stop trusting you, and a reader who doesn't trust the narrator is a reader who stops reading.

The contract is simple: you can invent characters, compress timelines, and fabricate events — that's fiction — but the background reality must hold. Readers will give you the invented gunfighter; they won't forgive the Tommy gun in 1870.

---

## Anachronism: The Core Threat

An anachronism is the placement of something — object, institution, phrase, technology — in a time period before or after it actually existed.

**The word to burn into your process:** Anachronophysia — fear of anachronisms. If you don't have it, develop it.

### High-Risk Anachronism Areas

**Weapons** (covered in detail in [04 Weapons](04-weapons-and-violence.md)):
- The Winchester '73 existed from 1873. Not 1865.
- The pump-action shotgun existed from 1897. Not 1881.
- The Tommy gun is 1919. Full stop.

**Transport:**
- The transcontinental railroad was completed 10 May 1869. Your character cannot take a train from Missouri to San Francisco before that date.
- Specific regional rail lines have specific completion dates. Check them.
- The Pony Express operated April 1860 to October 1861 — a mere 19 months. It's dramatically potent precisely because it was so brief.
- Stagecoach lines operated on specific routes with specific schedules. Check Wells Fargo's actual routes for your setting.
- The automobile was commercially available from approximately 1900 (Model T from 1908). In a story set in 1895, nobody drives.

**Communication:**
- The transcontinental telegraph was completed in October 1861, directly ending the Pony Express.
- Before a telegraph office existed in your town, news travels no faster than the fastest horse.
- The telephone was invented in 1876 but was rare outside major cities until the 1890s.

**Institutions:**
- The Republican Party did not exist until 1854.
- The FBI (then Bureau of Investigation) was created in 1908.
- U.S. Marshals Service: 1789.
- Pinkerton Detective Agency: February 1855.
- The Homestead Act (free land claims): 1862.

**Women's rights:**
- Women could not vote in most states until 1920 (19th Amendment). Colorado granted women full voting rights in 1893; Wyoming Territory did so in 1869.
- Married women in most states could not own property in their own names until mid-to-late nineteenth century (New York's Married Women's Property Act: 1848).
- Female lawyers: Arabella Mansfield licensed in Iowa, 1869.

### Slang and Language Anachronisms

This is the most common error and the hardest to catch without specific research. The Online Etymology Dictionary (etymonline.com) is the essential tool — it tracks first documented usage of thousands of words and phrases.

**Dangerous phrases to audit:**
- "Pissed off" as slang for angry: 1946. Not 1876.
- "Shit-faced" (drunk): 1960s. Not 1885.
- "Flying fuck" (a specific colourful oath): attested from 1800, so permissible.
- "Fuck off" as a dismissal: 1929. Not period-accurate in most Western settings.
- Modern slang of all kinds is the most common anachronism in period dialogue and the most jarring.

---

## Research Methodology

### The Three-Layer Research Approach

**Layer 1: Dates and facts**
When was this technology invented? When did this railroad reach this town? When was this law enacted? These are findable facts. Use them as non-negotiable anchors.

**Layer 2: Regional specificity**
"Texas" in 1875 is not one thing. East Texas had Reconstruction-era racial violence and established cotton farming. West Texas was still Apache country. The Panhandle was open range. Know which Texas you're writing.

**Layer 3: Texture and atmosphere**
What did it smell like? Sound like? What did food taste like and what did it cost? What did a doctor's office look like? What happened to a wound in the absence of antibiotics? This is where the lived experience comes from and where underprepared writers are exposed.

### Recommended Research Tools

- **Online Etymology Dictionary** (etymonline.com): Period accuracy of specific words and phrases
- **Western Timeline** (see [09 Glossary & Reference](09-glossary-reference.md)): Key dates in Western history
- **Period newspapers**: Many are digitised. Contemporary accounts carry idiom, price, and social texture no secondary source can replicate.
- **Specialist histories**: Not general overviews but specific histories — of specific Indian Wars, specific outlaw gangs, specific towns, specific weapons. The bibliography at the end of each chapter in any serious Western reference is your research trail.
- **Primary sources**: Memoirs, trial transcripts, sheriff's records. These exist and are available through academic libraries and digital archives.

---

## Alternate History and Steampunk: When Anachronism Is the Point

Two subgenres deliberately deploy anachronism:

**Alternate History:** "What if the Confederacy won?" is the most common Western variant. The craft rule is that you must establish your point of divergence clearly and then follow its consequences with rigorous internal consistency. You cannot just swap flags and keep everything else the same. A Confederate victory over the Union changes economics, racial politics, technology development trajectories, and international alliances in cascading ways. Think through the cascade.

**Steampunk Western:** Industrial-era technology (steam power, clockwork mechanisms, early computation) applied in the frontier context. The craft rule: establish your world's technological rules in the first act and hold to them. Steampunk fails when the writer invents technology on demand to solve plot problems.

---

## Transport: What Characters Can Actually Do

### Horse Travel
- Comfortable travelling pace: 25–30 miles per day
- Hard push: 40–50 miles (risks the horse)
- Extended ride at full gallop kills a horse within miles
- Horses require water every 6–8 hours; food and rest overnight
- A man on foot covers 20–25 miles per day under good conditions

### Wagon Travel
- 10–20 miles per day on rough terrain
- Dependent on road or trail quality
- Wagon trains on the Oregon Trail averaged 15 miles per day

### Stagecoach
- Wells Fargo stages changed horses at relay stations every 10–15 miles
- Average speed: 5 mph
- The route from Missouri to California took approximately 25 days by Butterfield Overland Mail (established 1858)

### Railroad
- Average passenger train speed (1870s): 25–35 mph
- A journey that took weeks by wagon or stage took days by train
- Railroad arrival in a town transformed its economy, demographics, and culture within a year — this is a plot engine, not background detail

---

## Period Medicine: What Wounds Actually Do

This matters because how you write injuries reveals whether you've done your homework.

**Gunshot wounds:**
- A wound to the shoulder, arm, or leg can sever major arteries (subclavian, femoral) and kill within minutes
- Even non-arterial wounds in the abdomen were almost always fatal in the 1870s due to peritonitis
- Infection was the primary cause of death in wounded soldiers during the Civil War — about twice as many died of disease as of combat
- Surgery without anaesthesia or antiseptic: chloroform was available from 1847, but frontier doctors had limited supplies and variable training
- Amputation was often the safest available response to severe limb wounds
- The bullet had to come out (usually) — "digging for lead" was genuine surgery performed with unsterilised instruments

**The practical implication:** A character who takes a serious wound in Chapter 3 cannot be fully functional in Chapter 4 unless you account for the physiological reality. Writing around this is possible (he fights through it, collapses after) but must be acknowledged.

---

## Prisons and Punishment

**Hanging** was the standard frontier execution. Details matter:
- The "short drop" produced death by strangulation — slow, agonising
- The "long drop" (calculated by body weight to produce enough force to break the neck) was meant to be more humane — and sometimes decapitated the condemned if miscalculated (Thomas "Black Jack" Ketchum, April 1901, New Mexico)
- Many counties had no formal gallows and improvised from trees, wagons, or doorframes

**Territorial prisons** (see [02 Setting](02-setting-and-place.md)) each have specific histories: Yuma Territorial Prison (1876), Huntsville in Texas (1849), San Quentin (1852), Leavenworth (1897 federal use). Using the wrong prison for the right era is an error.

---

**→ Continue to:** [06 Dialogue & Language](06-dialogue-and-language.md) | [09 Glossary](09-glossary-reference.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [04 Weapons](04-weapons-and-violence.md)
