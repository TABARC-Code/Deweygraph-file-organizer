# 03 — Character Craft

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [04 Weapons](04-weapons-and-violence.md) | [06 Dialogue](06-dialogue-and-language.md) | [07 Diversity](07-diversity-and-representation.md) | [08 Narrative](08-narrative-craft.md) | [02 Setting](02-setting-and-place.md)

---

## The Non-Negotiable First Principle

Before any other craft consideration: **every character, regardless of role or historical function, is a human being first.** Readers empathise with complexity. They check out of cartoons.

No hero is always heroic. No villain is completely evil. The most compelling Western figures in literature are those where the line between hero and villain blurs, flexes, or breaks. Real frontier history supports this: the same man might have worn a badge and run a brothel, killed a man in self-defence and shot another in the back, been a genuine civic force and a notorious thief.

Build from that ambiguity. It's historically accurate and dramatically necessary.

---

## The Lawman

### Historical Reality vs. Fiction

Real frontier law enforcement was a web of jurisdictions, rivalries, corruption, and improvisation. Before you write a lawman, know what kind of lawman you're writing:

**Federal:** U.S. Marshal (one per federal judicial district) and Deputy U.S. Marshals. Primary duty: serve federal court orders, pursue federal fugitives. Also assigned to Indian Territory and unorganised lands. Longest-serving federal law agency, established 1789.

**Territorial:** Rangers, whose legal standing was often temporary and frequently dissolved and reformed. Texas Rangers (from 1823, formalised 1835) are the oldest and best known. Arizona Rangers (1901–1909) were famously dissolved after a cross-border incident in Mexico. New Mexico Rangers (1905–1912) were disbanded in a legislative surprise.

**County:** Sheriff, elected by county voters. Enforces state laws and county ordinances. Can collect taxes and fees — in some eras a significant source of personal income. Jurisdiction ends at county lines, which historically aided outlaw gangs who simply crossed over.

**Municipal:** Town marshal (police chief equivalent) and deputy marshals. Authority within city limits only. Many frontier town marshals were appointed, not elected, and fired when they became inconvenient to local power.

**Key craft insight:** The lines between these jurisdictions were often contested, fluid, and politically charged. A scene where a county sheriff and a federal marshal argue over who has authority over a prisoner is both historically accurate and dramatically rich.

### The Corrupt Lawman

As a proportion of the frontier law enforcement community, corrupt officers were no more common than corrupt officers today — but they existed in number and in history. Some examples from the historical record:

- Officers who worked both sides of the law simultaneously
- Sheriffs who took a cut of illegal operations in their jurisdiction
- Deputies who used their position to commit crimes with impunity
- Marshals who arrested enemies on trumped charges and ignored allies' crimes

The corrupt lawman is not a revisionist invention — it is documented frontier reality. Use it, but ground it in specificity. A corrupt lawman should have a clear motivation (money, power, survival, old loyalties) that readers can understand even if they don't excuse it.

### The Lawman Under Pressure

What makes a lawman compelling is not that he does the right thing — it's that doing the right thing costs him something. He's outgunned. The town won't back him. His jurisdiction doesn't technically cover this crime. His employer is the problem. He's afraid. The physical courage required for frontier law enforcement was genuine and frequently fatal: over 250 U.S. Marshal Service employees were killed in the line of duty in the nineteenth and early twentieth centuries.

**→ For post-traumatic stress and the psychological weight of violence, load [08 Narrative Craft](08-narrative-craft.md)**

---

## The Outlaw

### Historical Reality

Frontier outlaws ranged from calculating criminal operators to violence-addicted drifters to men pushed into crime by economic catastrophe or political persecution. The James-Younger gang traced their criminal career directly to Missouri's Civil War experience. Billy the Kid emerged from economic conflict in Lincoln County. Butch Cassidy ran a sophisticated criminal organisation that operated for years before federal pressure forced it to flee the country.

Three broad outlaw types worth distinguishing:

**The Professional:** Treats crime as a business. Plans robberies. Maintains discipline. Cultivates informants. Manages risk. This character understands that violence is a cost, not a pleasure — it draws attention, invites retaliation, and kills employees. More intelligent and more dangerous than the Hollywood version.

**The Violence-Addicted:** Some frontier killers were simply drawn to killing. John Wesley Hardin killed his first man at fifteen and is documented with thirty-odd victims, many apparently unarmed. Clay Allison killed a bunkmate for snoring. This character type exists and is historically documented. Treat them as a psychological reality, not a caricature.

**The Structural Outlaw:** Made criminal by circumstance — economic desperation, racial persecution, political dislocation. Many Hispanic bandits in California and the Southwest were men whose land had been stolen; their crime was resistance to dispossession. Many post-Civil War Missouri outlaws were ex-guerrillas who couldn't reintegrate. This character type produces the most morally complex fiction.

### The Outlaw as Antihero

The revisionist tradition made the outlaw-as-hero central. This works when:
- The character has a genuine moral code, however twisted or limited
- The forces arrayed against him are clearly worse than he is
- His violence has real consequences he has to live with
- There's something recognisably human in what he's protecting or pursuing

It fails when:
- The outlaw is simply cool and the lawmen are simply corrupt, with no genuine moral tension
- His victims are anonymous or deserving
- The narrative never interrogates his choices

### Bounty Hunters

A rich character type. After the 1872 Taylor v. Taintor Supreme Court ruling, bounty hunters had broader legal authority than most sheriffs — they could cross state lines, operate on Sundays, and break down doors. They existed in a legal grey zone that makes them ideally suited for stories about justice without institutional support.

Build bounty hunters the same way you build any character: with a clear history, a driving motivation (not just money), and a specific code of conduct.

---

## The Gunfighter

The legendary gunfighter — fast draw, dead shot, feared by all — is mostly a dime novel invention. Real frontier gunfighters were more pragmatic and less romantic.

**Historical realities:**
- Most gunfights involved multiple shooters, close range, and ended with few or no fatalities
- Many of the "deadliest men in the West" had confirmed kill counts in the single digits
- Shooting first from ambush or from behind was common and considered tactically sound
- Alcohol was often a factor in the confrontations that led to violence
- Many famous "gunfighters" spent most of their careers as gamblers, lawmen, or cattle traders

**The craft implication:** A gunfighter character should be shaped by this reality, not the myth. What does it do to a person to be known as a killer? How do they manage that reputation — use it, fear it, try to escape it? The psychological dimension is richer than the showdown choreography.

**→ For specific gunfight mechanics, load [04 Weapons & Violence](04-weapons-and-violence.md)**

---

## The Settler

Often treated as backdrop in Western fiction, settlers are dramatically rich characters with very specific pressures:

- Economic desperation that drove them to risk the frontier
- The physical brutality of homesteading (the Homestead Act's 160 acres required genuine improvement over five years)
- Vulnerability to weather, disease, hostile neighbours (human and natural)
- Social isolation and its psychological effects
- The gap between the West they imagined and the West they found

Settlers who are merely victims waiting to be rescued are wasted opportunities. Settlers who become something unexpected — harder, more violent, more adaptive, more morally compromised — are characters.

---

## Women

**→ For full treatment of women in the West, load [07 Diversity & Representation](07-diversity-and-representation.md)**

Summary: Frontier women occupied far more roles than homemaker or saloon girl. The historical record includes female stagecoach drivers, mail couriers, gunslingers, outlaws, law officers, ranchers, doctors, lawyers, and civic leaders. Build women with the same specificity and complexity you bring to male characters. The frontier was genuinely hard on women in specific ways (legal vulnerability in marriage, limited property rights until the 1848 Married Women's Property Act in New York, reproductive danger) — these are character pressures, not background details.

---

## Supporting Characters: Avoiding the Costume Rack

Every supporting character — barkeep, stable hand, deputy, dance hall girl, Indian scout, Chinese cook, Mexican farmer — needs a reason to be in the story beyond set dressing. Even a character who appears in two scenes benefits from:

- One specific detail that makes them individual (not a type)
- A clear attitude toward the protagonist
- Something at stake, even if minor

The moment you write "the Mexican farmer nodded" instead of "Esteban crossed his arms and said nothing, which meant no," you lose a human being.

---

## Historical Real-Life Characters

Western fiction frequently employs historical figures as characters. This is legitimate — and commercially popular. Rules:

- Research them properly. The gap between the legend and the person is usually the most interesting material.
- Be aware that their descendants may still be alive. Some historical figures are subject to legal and ethical considerations around defamatory portrayal.
- Composite characters can serve the same function while giving you more creative freedom.
- The most interesting use of historical figures is often in supporting roles that illuminate the protagonist, not as the protagonist themselves.

---

## Character Diagnostic

Before submitting any Western character for critique, run these:

- [ ] Does this character have a flaw that creates dramatic consequence?
- [ ] Does this character want something specific, and is there a specific obstacle to getting it?
- [ ] Does this character's past explain their present without excusing it?
- [ ] If this is a minority character, have I researched the historical specifics of their group's experience?
- [ ] Does this character's dialogue sound like them, or like a generic "period" voice?
- [ ] Would this character do something that surprises me?

If yes to all six: you have a character. If no to any: keep building.

---

**→ Continue to:** [04 Weapons & Violence](04-weapons-and-violence.md) | [06 Dialogue](06-dialogue-and-language.md) | [07 Diversity](07-diversity-and-representation.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [02 Setting](02-setting-and-place.md)
