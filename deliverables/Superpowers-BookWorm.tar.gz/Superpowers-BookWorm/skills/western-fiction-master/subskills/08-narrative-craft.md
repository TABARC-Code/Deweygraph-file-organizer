# 08 — Narrative Craft

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [01 Genre](01-genre-architecture.md) | [03 Character](03-character-craft.md) | [04 Weapons](04-weapons-and-violence.md) | [07 Diversity](07-diversity-and-representation.md)

---

## The Fundamental Obligation

Every Western, whatever its subgenre or historical period, must give its reader something to get lost in for a while. This sounds simple. It is the hardest thing in fiction to achieve.

The craft elements below serve this obligation. They are not decorative — they are the mechanisms by which you keep a reader turning pages and caring about what happens.

---

## The Conflict Engine

Every Western plot, at its core, runs on conflict. In the genre, this traditionally takes specific forms:

**Law vs. disorder:** The effort to impose civilisation on an environment that resists it, and the moral cost of doing so.

**Individual vs. institution:** The lone figure against corrupt or indifferent power. This is the core structure of most "hero gunfighter" stories.

**Settler vs. environment:** The frontier as adversary — drought, disease, cold, distance, isolation. Often the most emotionally honest conflict in Western fiction because it's genuinely about survival.

**Conquest and its consequences:** Who owns this land? What was done to take it? What does it cost to keep it? This conflict is built into the genre's historical foundation and becomes explicit in revisionist Westerns.

**Personal vs. communal:** What a character owes themselves versus what they owe the people around them. Classic Western structure often ends with a lone hero walking away from a community he saved but can never be part of.

**Moral compromise:** The good man doing bad things for good reasons, or the bad man doing good things for bad reasons. This is where the most complex characters live.

---

## Plot Structures That Work in the West

### The Quest
A character moves through the landscape toward a goal. The journey creates encounter after encounter, each raising the stakes and revealing character. Cattle drives, bounty hunts, vendetta rides, and treasure hunts are all quest structures.

### The Siege
Characters are besieged — physically, legally, socially — and must find a way to survive or escape. The siege can be a town under outlaw control, a ranch under range-war attack, a lawman surrounded by corruption, or an individual trapped by their own reputation.

### The Return
A character comes back to a place from their past and finds it changed — or finds that they are changed, while it is the same. The returning character is forced to reckon with who they were and who they are.

### The Transformation
A character who begins in one moral condition ends in another. The straight man who becomes an outlaw. The outlaw who chooses redemption. The coward who finds courage. The gunfighter who tries to lay down their weapon.

### The Revelation
The truth of a past event gradually surfaces, changing everything the reader and characters thought they understood. Mystery structure applied to Western setting.

---

## Pacing

### The Open Landscape as Breathing Room
Western fiction traditionally uses the landscape as a pacing tool. Long descriptive passages during travel create anticipation before action, allow readers to orient themselves, and give the story breath. Louis L'Amour understood this intuitively — his landscape writing is not padding, it's tempo.

### Action Must Earn Its Weight
A gunfight that comes before the reader cares about the participants is choreography. A gunfight that comes after the reader understands what each person is fighting for and what it will cost them to win or lose — that is drama.

**The rule:** Build the stakes before you pull the trigger.

### Short Chapters
Western fiction traditionally uses short, punchy chapters that end with a hook or an open question. This is not universal, but it is a genre convention that keeps pages turning. Chapter endings that resolve cleanly and completely are a different choice — they give the reader permission to put the book down. Chapter endings that leave a question open compel the reader forward.

---

## Sex and Violence: The Publisher Question

### Know Your Market
The range is vast. A Christian Western publisher will not tolerate explicit violence or sex. An adult Western series publisher may mandate two to three explicit sex scenes per manuscript. Most mainstream Western publishers fall between these poles.

**Before you write: research the publisher's existing catalogue.** Read three or four titles from the line you're targeting. Match the tone and content level.

### Violence
Realistic violence requires three elements:

**Physical accuracy:** See [04 Weapons & Violence](04-weapons-and-violence.md). Gunshots are not trivial. Primitive frontier medicine makes wounds dangerous in ways modern readers underestimate.

**Emotional consequence:** The person who commits violence is changed by it. The person who witnesses it is changed. Violence that leaves no mark on the characters who experience it is cinematic action, not fiction.

**Social consequence:** A killing, even a justified killing, changes how people relate to the person who killed. Respect, fear, suspicion, grief — these are the aftermath landscape of frontier violence.

### Sex
The mechanics of physical intimacy have not changed since the frontier era. What has changed are the social, legal, and medical contexts that shaped how characters would have experienced and thought about sex.

**Key period-specific elements:**
- Gender roles in courtship and marriage were rigidly defined; departures from those roles carried real social cost
- Contraception was rudimentary and often ineffective; pregnancy was a realistic consequence of any sexual encounter
- Venereal disease was common and often fatal before antibiotics (French pox/syphilis appears in the frontier glossary for a reason)
- Spousal rape had no legal concept — a married woman had no legal right to refuse her husband
- Prostitution was legal in some jurisdictions and widespread in most frontier towns regardless of legal status

These are not obstacles to writing sex — they are the texture that makes period sex scenes feel genuine rather than generic.

---

## The Human Touch: Making Characters Matter

### The Core Mechanism
Readers follow characters they care about. They care about characters they can empathise with. They empathise with characters who have genuine wants, understandable fears, and recognisable contradictions.

**The test:** Can you answer these questions for every major character?
1. What does this character want more than anything?
2. What are they most afraid of?
3. What do they believe about themselves that isn't true?
4. What would make them break?
5. What will they never do, regardless of circumstance?

The answers to these questions are the engine of character behaviour. Scenes flow from them.

### Post-Traumatic Stress: A Historical Reality

Combat stress and psychological trauma existed long before the clinical terminology. Herodotus documented what we would now call post-traumatic stress response in 490 BCE. Veterans of the Civil War — and every Indian War, every range war, every long career of frontier violence — carried psychological wounds that shaped their behaviour.

**Craft implications:**
- A man who has killed people does not sleep entirely soundly
- A veteran of sustained combat often has hypervigilant responses (startling easily, sitting with their back to the wall, scanning exits) that make sense psychologically
- Desensitisation is real — repeated exposure to violence produces a different response than first exposure
- Some men were simply broken by what they experienced; others functionally compartmentalised; a few seemed untouched and were usually the scariest people in the room

This is not an invitation to write every gunfighter as a trauma sufferer. It is a reminder that sustained violence has psychological consequences, and writing as if it doesn't produces characters who feel hollow.

### Villains Who Make Sense

A villain who is evil because the plot requires a villain is not a villain — they are a device. A villain with a clear motivation (greed, ideology, survival, revenge, love gone wrong) whose actions make sense from inside their own worldview is the beginning of genuine drama.

The most frightening villains in fiction are those whose logic is comprehensible. We understand why they do what they do. We might, under sufficiently extreme circumstances, do the same. That is genuinely unsettling.

---

## The Emotional Architecture of a Western

A well-built Western has an emotional arc as distinct as its plot arc. The reader's emotional experience moves through recognisable stages:

**Entry:** Orientation. Who is this world? Who are these people? What are the rules?

**Investment:** The reader finds someone — a character, a community, an idea — to care about protecting.

**Escalation:** The threat to what the reader cares about increases. Each reversal makes the situation worse.

**Crisis:** The point of maximum danger, where it seems impossible that what the reader cares about can survive.

**Resolution:** The conflict resolves. Not necessarily happily — but completely. Every significant character question that was raised must be answered. The emotional promise made at the start must be kept or consciously broken for a purpose.

---

## Western Endings

**The Walk-Away:** The hero, having saved the community, leaves it — because he's too dangerous, too wild, too marked by violence to belong. The West-as-genre has always struggled with the violence it needs to survive and the civilisation it claims to build. This ending makes that tension explicit.

**The Integration:** The hero (or antihero) finds a way to become part of the community. Usually requires genuine personal cost — something given up, some part of the old life left behind.

**The Pyrrhic Victory:** What was saved came at too high a cost. The town is safe; the man who saved it is dead, or broken, or permanently diminished. This is the revisionist Western's preferred ending.

**The Unresolved:** The conflict ends but the moral questions it raised don't. Best for literary fiction; dangerous for genre, where readers expect emotional completion.

---

**→ Continue to:** [01 Genre](01-genre-architecture.md) | [04 Weapons](04-weapons-and-violence.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [03 Character](03-character-craft.md)
