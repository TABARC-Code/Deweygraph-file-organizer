# 02 — Setting & Place

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [01 Genre](01-genre-architecture.md) | [05 Accuracy](05-historical-accuracy.md) | [09 Glossary](09-glossary-reference.md) | [03 Character](03-character-craft.md)

---

## The West Is Vast — Use All of It

Western fiction most commonly draws from post-Civil War Southwest and Great Plains (1865–1900), but the entire North American frontier is available territory. A writer who knows this has options most readers have never seen.

**Available territories include:**
- Colonial frontier (Appalachians, Ohio Valley, 1700s)
- Pre-Columbian and Native American settings (4,000+ years of material)
- The Age of Exploration (1490s–1680s) — conquistadors, early contact, missionary conflict
- Louisiana Territory and Lewis & Clark era (1800s)
- Manifest Destiny and Mexican War era (1840s)
- Civil War West (1861–65) — Texas, Arizona, New Mexico, Missouri
- Reconstruction frontier (1865–90)
- Post-1890 "closed frontier" (still wild in many places)
- Mexican Revolution border (1910–1920) — arguably the last true Wild West setting

The skill is in picking a place and era that **holds your own interest**, then researching it deeply enough to make it real.

---

## Selecting Your Setting: Core Questions

Before writing, lock in answers to these:

1. **What year is it?** This determines weapons, transport, law enforcement, communication technology, and slang. A fifteen-year error creates dozens of anachronisms.

2. **Where exactly?** Not just "Texas" — which Texas? The Rio Grande border? The Panhandle? East Texas piney woods? Each has different ecology, culture, and history.

3. **How settled is this location?** A brand-new mining camp, a decade-old cattle town, and a mature territorial capital have radically different physical environments and social dynamics.

4. **What institutions exist?** Is there a sheriff? A federal marshal? A Pinkerton office? A vigilance committee? These shape what kinds of conflict are possible.

---

## The Eras in Detail

### Pre-Columbian (Prehistory–1492)
Fertile and underused. Native civilisations were complex, diverse, politically sophisticated, and frequently at war with each other before Europeans arrived. Long before the cowboy myth, this is where the continent's real frontier stories lived. Requires anthropological research, not Hollywood shorthand.

**Craft note:** Native American characters in this setting must reflect specific cultural and tribal reality. A Cheyenne does not practice Hopi rituals. Research the specific people you're writing.

### Age of Exploration and Colonial Era (1492–1776)
Conquistadors, Jesuit missions, early colonial settlements, the fur trade, Indian alliances and wars. Rich material almost entirely untapped by popular Western fiction. Zorro lives here. James Fenimore Cooper's Natty Bumppo lives here.

**Craft note:** European characters from this era have pre-modern worldviews shaped by religious cosmology, feudal loyalty structures, and pre-Enlightenment epistemology. They do not think like nineteenth-century Americans.

### Revolution and Early Republic (1776–1820)
Daniel Boone's Kentucky. The Lewis and Clark Expedition. The Whiskey Rebellion. The Louisiana Purchase. Renegades, river pirates, and the earliest cattle drives. Often overlooked by Western writers.

### Manifest Destiny (1820–1860)
Mountain men, wagon trains, the Mexican War, California gold rush, the Mormons, Bleeding Kansas. The frontier in this era is simultaneously expanding and fracturing over slavery. Political conflict is inseparable from frontier conflict.

### Civil War West (1861–1865)
The Trans-Mississippi Theatre. Confederate Arizona. Apache wars running concurrently with Union-Confederate fighting. Black Union soldiers. Quantrill's raiders. The most complex and least fictionalised era of Western history.

**Craft note:** The West during the Civil War is not a sideshow — it's its own theatre with its own stakes. If you set your story here, do not neglect the racial dimension: slavery, Emancipation, and their effects reach all the way to New Mexico.

### The Classic Era (1865–1900)
The most written-about period. Cattle drives. Range wars. Indian wars. The transcontinental railroad. Tombstone. Dodge City. This era's over-representation in fiction is itself a problem: to write here is to compete with a century of output. Distinguish your work through specificity of location, character, and historical accuracy.

**Craft note:** The "closing" of the frontier in 1890 is a legal and bureaucratic fiction. Real outlaws, real Indian resistance, and real frontier lawlessness continued well into the 1900s. Use that.

### Post-1890 Extended West (1890–1920)
Bill Doolin's gang. The Mexican Revolution and Pancho Villa's raids. The last Apache holdouts. Butch Cassidy. The automobile arriving in cow country. World War I intersecting with the border wars. This era is dramatically rich and critically neglected.

---

## Building a Frontier Location

Your setting must work on three levels:

### Physical Reality
- **Geography:** Desert, mountain, plains, river valley, coastal range? Each has distinct ecology, water sources, and terrain challenges.
- **Climate:** The frontier killed people through heat, cold, drought, and flood. Weather is a character.
- **Distance:** Before railroads, distances that take a car an hour took a horse all day. This shapes plot. A character can't simply "ride to the next town" if the next town is sixty miles away.

### Social Infrastructure
What institutions, businesses, and social structures exist in this location?

**Possible elements:** Saloon, hotel, general store, livery stable, sheriff's office/jail, assay office (in mining towns), church, brothel, telegraph office, stagecoach depot, railroad depot, newspaper office, doctor, lawyer, school, land office, bank.

**What's missing matters as much as what's present.** A town without a doctor means different consequences for gunshot wounds. A town without a telegraph means news travels slowly. A town without a bank means different robbery targets.

### Political Jurisdiction
Who has legal authority here? (See [03 Character — Lawmen](03-character-craft.md) for detail.) At minimum, know whether the location is:
- Incorporated territory with its own courts
- Unorganised territory under federal jurisdiction
- Indian Territory with its own complex legal status
- Borderland where multiple legal systems collide

---

## The Frontier Town

Most Western fiction takes place partly or entirely in a town. Build it from the ground up:

**Physical layout:** Main street usually runs parallel to the main road or rail line. The saloon and hotel anchor social life. Churches and schools occupy respectable corners. The worst establishments cluster at the far end of town, near where transients arrive.

**Social stratification:** Even small frontier towns have hierarchy. Merchants and professionals (doctor, lawyer, banker) sit atop the social order. Working cowboys, miners, and drifters sit below. Women's status varies enormously by marital status and occupation. Racial minorities are usually legally or informally segregated.

**The saloon as stage:** The saloon is where plot happens in Western fiction for good historical reason. It was the primary social gathering place, information exchange, and conflict venue in most frontier towns. Know your saloon: who owns it, who drinks there, who deals cards, who works upstairs, who is barred.

---

## The Open Landscape

Not all Westerns are set in towns. The trail, the desert, the mountains, the river — these are characters too.

**The trail:** Cattle drives (Chisholm, Goodnight-Loving, Western) were multi-week journeys with a defined crew structure. Know the roles: trail boss, cook (cocinero), point riders, swing riders, flank riders, drag riders, wrangler. Each has different status and different duties.

**The wilderness:** Characters who go into genuinely wild territory in the nineteenth century face threats that modern readers underestimate. Lack of water. Navigation without landmarks. Encounters with wildlife — rattlesnakes, mountain lions, bears — that are not dramatic flourishes but genuine daily hazards. The elements kill people.

**The mine:** Mining camps have their own ecology: the shaft, the claim, the assay, the company store that keeps workers in debt, the saloon where the week's earnings vanish. Violence in mining camps is often economic before it is personal.

---

### The Mounted Cowboy: Tack and Equipment

Since most frontier fiction involves men and women on horseback, a working knowledge of the correct terminology pays dividends in authenticity:

**Saddle components:** Horn (for roping), cantle (rear raised portion), stirrups, fenders or leathers (side pieces), cinch (girth strap that holds the saddle).

**Bridle components:** Headstall (leather frame that holds the bit), bit (metal bar in the horse's mouth), reins, hackamore (bitless alternative using a noseband, common with young horses).

**Other tack:** Halter (for leading, not riding), martingale (strap preventing the horse raising its head too high), breastplate (chest strap preventing saddle slipping back on steep terrain).

**Chaps:** Leather leg coverings worn by cowboys for protection. Five distinct styles:
- *Shotgun* chaps — tight-fitting, full-length, closed at the bottom; better for dense brush
- *Batwing* chaps — wide, flapped, snapped around the leg rather than laced; easier to put on over boots
- *Chinks* — shorter, typically knee-length; used in warmer climates or for less arduous work
- *Farrier's apron* — worn by blacksmiths, not cowboys
- *Woollies* (or *Angoras*) — goat-hide chaps; worn in cold weather for insulation
- *Zamorros* — worn in some Mexican-border regions

**Spurs:** Many styles exist. The key distinction is between simple starburst rowels (fixed) and jingle-bob rowels (loose, producing the iconic jingle). Not all cowboys wore spurs; those who did wore them in terrain and conditions that required urging a reluctant horse.

**The correct terminology matters** because cowboys noticed when someone used the wrong word, and your characters should too. A man who calls the cinch a "strap" or the cantle the "back bit" signals that he does not know horses.

---

**→ Load [05 Historical Accuracy](05-historical-accuracy.md) for complete timeline**

Summary rules:
- **Horses:** Available everywhere from the beginning of European settlement. Know horse breeds (mustangs for wild horses, quarter horses for cow work, Thoroughbreds for speed), proper tack terminology, and how far a horse can actually travel in a day (25–30 miles at reasonable pace; 50 miles is hard use; more than that risks killing the animal).
- **Wagons:** Essential for cargo. Know the difference between a Conestoga (heavy emigrant wagon), a buckboard (light utility), a stage (passenger), and a chuck wagon (cook's rig).
- **Stagecoach:** Primary passenger and mail transport before railroads. Routes, schedules, and guard practices (Wells Fargo shotgun messengers) all have period-specific details.
- **Railroad:** The transcontinental was completed 10 May 1869 at Promontory Point, Utah. Before that date, no through rail route existed from Missouri to California. Check specific rail line dates for your region.
- **Telegraph:** The transcontinental telegraph was completed in 1861, effectively ending the Pony Express. In towns with telegraph offices, news travels at near-instant speed. In towns without one, news travels as fast as a horse.

---

## Setting as Antagonist

The landscape in Western fiction often functions as an active force working against characters, not just a backdrop. The best frontier writing uses setting this way:

- Heat and thirst as mortal pressure
- Winter storms as killers with no malice and no mercy
- The sheer scale of distance as isolation
- The desert as maze and trap
- The river as both resource and flood threat

When your characters are at the mercy of the landscape, readers feel the West rather than just reading about it.

---

**→ Continue to:** [03 Character Craft](03-character-craft.md) | [05 Historical Accuracy](05-historical-accuracy.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [01 Genre](01-genre-architecture.md)
