# 07 — Diversity & Representation

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [03 Character](03-character-craft.md) | [06 Dialogue](06-dialogue-and-language.md) | [08 Narrative](08-narrative-craft.md)

---

## The Historical Argument for Diversity

The West was not white. This is not a modern political position — it is historical fact.

Before a single Anglo-American wagon train crossed the Missouri, the American West was already inhabited by hundreds of Native nations, Spanish colonial settlements more than two centuries old, Hispanic communities, African-descended people (enslaved and free), Chinese immigrants, and a complex mixture of all of the above. When "the West" was being settled in the classic fictional era (1865–1900), Black cowboys worked the cattle drives, Chinese labourers built the railroads, Hispanic ranchers ran land that had been theirs for generations, and women ran businesses, ranches, schools, and homesteads.

A Western that presents an all-white cast is not historically realistic. It is a filtered mythology — Hollywood's pre-1960s mythology specifically. It is also bad fiction, because it throws away most of the drama.

---

## Native Americans

### The Historical Reality
Hundreds of culturally distinct nations and tribes occupied the Americas from the Arctic to Cape Horn. By 1900, genocide and epidemic disease had reduced their population by 50–80 percent. Each nation had distinct languages, social structures, religious practices, warfare traditions, and relationships with other tribes and with European settlers. There is no generic "Indian" — there is a Comanche warrior, a Cheyenne elder, a Seminole freedom fighter.

### The Craft Requirements

**Research the specific people you're writing.** If your character is Cheyenne, research Cheyenne culture, language, spiritual practice, and history. Do not assign Hopi or Comanche customs to them. A reader who knows will be jarred; an editor who knows will send the manuscript back.

**Avoid both "noble savage" and "ruthless savage" archetypes.** Both are projections. The noble savage simply inverts the direction of the cliché. Native people in the historical West were:
- Politically sophisticated actors managing complex alliances and rivalries
- Participants in economic systems (fur trade, horse trade, cattle trade) that they shaped as much as any Anglo-American
- People who made strategic decisions, sometimes including accommodation, sometimes including war, based on their actual circumstances
- Individuals with a full range of human motivation — courage, cowardice, greed, generosity, love, hatred

**Pre-European inter-tribal conflict is historical.** Native nations made war on each other, kept slaves, and committed atrocities — before any European arrived. Acknowledging this is not an excuse for European genocide; it is historical completeness. Fiction that presents pre-contact Native life as static, peaceful, and morally pure is its own form of condescension.

**Language.** Tonto-speak is a radio caricature from the 1930s. It has nothing to do with how any actual Native American spoke English. Avoid it entirely.

---

## Hispanic Americans (Brown West)

### The Historical Reality
Much of what is called "the Old West" was Mexican territory until the 1840s. The United States seized California, Arizona, Nevada, Utah, New Mexico, Texas, and roughly half of Colorado through the Mexican War (1846–48). With the land came more than half a million Hispanic residents who were immediately subjected to discrimination by their new Anglo-American rulers.

Hispanic Americans in the West worked as vaqueros (from whom the entire cowboy tradition derives — the word "buckaroo" is a corruption of "vaquero"), ranchers, farmers, merchants, miners, lawmen, and outlaws. Many of the "bandits" of the Southwest were men defending land that had been legally theirs under Mexican law and was confiscated under Anglo-American legal manoeuvres.

**The lynching record:** Historian William Carrigan documented 597 Mexicans lynched between 1848 and 1928 in the Southwest — a figure he explicitly acknowledged as incomplete. Hispanic lynch victims were counted as "white" in NAACP records, meaning the true scale of anti-Hispanic violence is systematically undercounted in the historical record.

### The Craft Requirements

**The bandit as resistance fighter.** Many Hispanic outlaws in the American Southwest are more historically understood as political actors — resisting dispossession, asserting cultural survival — than as simple criminals. This is dramatically rich material that most Western fiction ignores.

**Avoid the bandito stereotype.** "Lazy" Mexicans, lecherous *banditos*, and comic sidekicks in sombreros are the residue of anti-Hispanic propaganda. Your editors will catch these and reject them.

**Spanish language.** Selective Spanish usage in dialogue can authenticate a Hispanic character's voice. See [06 Dialogue](06-dialogue-and-language.md) for the rules around this.

---

## Black Americans (Black West)

### The Historical Reality
African-Americans participated in every aspect of Western settlement. Key historical examples:

**Cowboys:** An estimated 25 percent of Texas cowboys in the classic cattle-drive era were Black. Nat Love ("Deadwood Dick") was one of the most celebrated cowboys in the West. Bose Ikard rode for Charles Goodnight and Oliver Loving and was the real-world model for Joshua Deets in *Lonesome Dove*.

**Soldiers:** The 9th and 10th Cavalry and 24th and 25th Infantry were Black units — the "Buffalo Soldiers," named by their Plains adversaries for their tightly curled hair. Twenty-two earned the Medal of Honor in Civil War service. They served in Indian Wars, protected the mail and railroads, and policed Oklahoma Territory.

**Lawmen:** Bass Reeves served as a Deputy U.S. Marshal for 32 years (1875–1907). He killed fourteen felons in the line of duty without suffering a wound himself. His hat was shot off. His bridle was cut by flying bullets. He served warrants in Indian Territory when most officers refused the assignment. He may have been the model for the Lone Ranger.

**Outlaws:** "Cherokee Bill" Goldsby, "Isom Dart," and others existed in the historical record as genuine frontier criminals with complex backstories.

**Town founders:** Benjamin "Pap" Singleton steered an estimated twenty thousand Black settlers to Kansas (1877–79). Edwin McCabe served as state auditor of Kansas and established Langston, Oklahoma. All-Black towns in Oklahoma Territory were not uncommon.

### The Craft Requirements

**The full range:** Black characters in Western fiction should span the full range of human roles and moral conditions, not be restricted to either noble victims or exceptional heroes. Both the ordinary farmer and the ruthless outlaw belong in this history.

**Education and literacy:** The ban on teaching enslaved people to read was real and had lasting effects on literacy rates — but it was not universal in its outcomes. Many freed people educated themselves with ferocious determination. Do not default to an uneducated voice for every Black character.

**Slavery's shadow.** For stories set before 1865, slavery is unavoidable context. For stories set after 1865, the weight of Reconstruction and its failures, the terror of racial violence, and the complex political landscape of post-war racial politics are the context. Ignoring this context produces historical fiction with a hole in it.

---

## Chinese Americans (Yellow West)

### The Historical Reality
The transcontinental railroad was built substantially on Chinese labour. By 1880 California had 300,000 Chinese residents — about 10 percent of the state's population. Most were men (women were effectively banned from immigration). They worked as railroad labourers, miners, laundry operators, cooks, and merchants. Tong organisations existed and some engaged in vice — but their primary paying customers were Anglo-American "slummers," not a Chinese criminal underworld.

Anti-Chinese legislation escalated through the 1860s–1880s, culminating in the Chinese Exclusion Act (1882). Anti-Chinese riots swept California, Colorado, Wyoming, and Washington in the 1870s–1880s.

### The Craft Requirements

**No "celestial" caricature.** Chinese immigrants were called "celestials" by Anglo racists who thought them alien species. The pidgin-English caricature ("No tickee, no washee!") with syllable-mangled speech is a racist artefact. It has no place in serious fiction.

**Economic actors, not props.** Chinese merchants in frontier towns were sophisticated businesspeople managing complex community and family obligations. They were not houseboys with punchlines.

---

## Women

### The Historical Reality
Frontier women occupied far more roles than the domestic-or-saloon binary of early Western cinema.

**Occupational range:** domestic servant, farmer, rancher, school teacher, nurse, doctor (Elizabeth Blackwell, 1849), lawyer (Arabella Mansfield, 1869), journalist, mail carrier ("Stagecoach Mary" Fields), stagecoach driver (Charley Parkhurst), poker player (Poker Alice), outlaw (Belle Starr, Laura Bullion), lawman (four female Deputy U.S. Marshals in Oklahoma Territory), soldier (Cathay Williams/"William Cathay," Buffalo Soldier, 1866–1868).

**Legal vulnerability:** In most states before the late nineteenth century, married women could not own property, enter contracts, or testify in court without their husband's permission. Divorce was socially devastating and legally difficult. Spousal rape had no legal concept. This is character pressure, not background detail.

**Voting rights:** Colorado (1893), Wyoming Territory (1869), Utah (1896), Idaho (1896). Most states not until 1920.

### The Craft Requirements

**Write women as people.** Not as prizes for male characters. Not as moral centres who exist to redeem men. Not as scenery. Women on the frontier made strategic choices, survived terrible conditions, created communities, committed crimes, enforced law, loved, hated, failed, and triumphed. Give them the same character depth you give men.

**"Gentle tamers" is a partial truth.** Historian Dee Brown's term for frontier women captures one type of female frontier experience. It doesn't capture Belle Starr, Sally Skull, Poker Alice, or Calamity Jane. Use the full range.

---

## Japanese Americans

### The Historical Reality
The first officially recorded Japanese immigrants reached Honolulu in February 1855. California's first Japanese settlers arrived in the Gold Hills in 1869. By 1893, San Francisco had enough Japanese residents to prompt a school segregation movement. A 1907 "gentleman's agreement" between Washington and Tokyo limited further Japanese immigration without requiring formal legislation. California's Alien Land Law (1913) barred Japanese from owning land. The Immigration Act of 1924 banned Japanese immigration entirely.

Anti-Japanese sentiment in California and the Pacific Northwest was significant from the 1870s onward, though it never reached the same scale of mass organised violence as anti-Chinese riots. The primary arena of conflict was economic: white farmers resented Japanese success in agricultural production.

**The craft implication:** Japanese characters in post-1870 California settings face specific legal and economic pressures that differ from the Chinese experience. Know which you're writing.

---

## LGBTQ+ in the West

### The Historical Reality
Homosexuality existed on the frontier as everywhere else in human history. Sodomy was a capital crime in Spanish California (last execution 1501) and remained illegal in all U.S. states through the nineteenth century. This created systematic concealment, not absence.

Possible transgender/non-binary historical figure: Charley Parkhurst (born Mary/Charlotte Parkhurst, c. 1812), a stagecoach driver who lived as a man for decades, registered to vote in 1868 as the first biological female registered in California, and was only discovered to be biologically female upon death.

### The Craft Requirements
Writing LGBTQ+ characters in the historical West requires acknowledging the legal and social context (which would have forced concealment and shaped every choice) without making that oppression the totality of the character's existence. The craft challenge is specificity: what would this person's life have actually looked like in this specific time and place?

---

**→ Continue to:** [08 Narrative Craft](08-narrative-craft.md) | [03 Character](03-character-craft.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [06 Dialogue](06-dialogue-and-language.md)
