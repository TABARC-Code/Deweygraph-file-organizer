# 04 — Weapons & Violence

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [03 Character](03-character-craft.md) | [05 Accuracy](05-historical-accuracy.md) | [08 Narrative](08-narrative-craft.md)

---

## The Non-Negotiable First Principle

Firearms are historically and narratively central to most Western fiction. A writer who uses them inaccurately signals to knowledgeable readers that they cannot trust the rest of the story. The baseline requirement is not encyclopaedic expertise — it is the absence of obvious error.

If you've never fired a gun, consider visiting a range. If that's not possible, research until your ignorance stops producing mistakes.

---

## The Evolution of Firearms: A Craft Timeline

Getting weapons right requires knowing what existed when. This section provides the key inflection points.

### Muzzle-Loading Era (pre-1860)
**Flintlock** mechanism (1600s onward): Flint strikes steel to spark the pan charge. Misfires were common ("a flash in the pan"). Reliable but weather-sensitive. Primary weapon of early frontier, Revolutionary War, and War of 1812.

**Percussion cap** mechanism (from 1830): Mercury fulminate cap placed on hollow nipple. More reliable than flintlock in wet conditions. Used widely through the Civil War.

**All muzzle-loaders** require the shooter to pour powder, seat a ball, and ram it home before each shot. Rate of fire: 3–4 rounds per minute for an experienced shooter. This is slow. Writing a muzzle-loading character firing eight shots in a minute is an error.

### Transition: Metallic Cartridges (1850s–1860s)
**Rimfire cartridges** (primer around the rim of the base) enabled truly practical breech-loading weapons. Henry rifle (1860) and early Smith & Wesson revolvers used rimfire.

**Centre-fire cartridges** (primer in the centre of the base) followed, becoming the modern standard. More reliable and reloadable.

### The Revolver Revolution
**Colt Paterson (1836):** Samuel Colt's first commercial revolver. Five-chamber, single-action (hammer must be manually cocked before each shot), .28–.36 calibre. Available pre-Texas Ranger era.

**Walker Colt (1847):** Six-shot, .44 calibre. Collaborated between Colt and Captain Samuel Walker of the Texas Rangers. One of the most powerful revolvers of the black powder era.

**Colt 1851 Navy:** Standard sidearm for many Civil War combatants.

**Colt Single Action Army (Model 1873) — "The Peacemaker":** The defining revolver of the classic Western era. .45 calibre, adopted by the U.S. Army. Offered in barrel lengths from 4 inches ("Storekeepers") to 5.5 inches ("Artillery") to 7.5 inches (Cavalry). Available in .45 Colt, .44-40 (same cartridge as Winchester '73), and other calibres. If your story is set post-1873 and involves a revolver, this is likely the weapon.

**Smith & Wesson Model 3 ("Schofield"):** Top-break design (the frame hinges like a shotgun to eject all cartridges simultaneously). Used by Wyatt Earp, Jesse James, Billy the Kid, and Pat Garrett. Faster reloading than the Colt SAA.

**Double-action revolvers:** Later models (Colt 1877, Colt 1878) allowed firing by trigger pull alone, without cocking. Available from 1877 onward.

**Critical craft note on the "Buntline Special":** The 12-inch-barrelled Colt supposedly given by dime novelist Ned Buntline to Wyatt Earp, Bat Masterson, and others is almost certainly a myth invented by Earp biographer Stuart Lake in 1931. Do not write this gun into a factual historical account. In historical fiction where authenticity matters, avoid it.

### Long Guns: The Rifles
**American Longrifle (Pennsylvania/Kentucky rifle):** Used from 1730s onward. Single-shot, muzzle-loading. Highly accurate to 500 yards in expert hands. Davy Crockett's "Old Betsy" is the most famous individual example.

**Hawken Plains Rifle:** Heavy, short-barrelled muzzle-loader for the Great Plains and Rockies. In use from 1825 onward. Favoured by mountain men, including Kit Carson and Jim Bridger. Bolt-action and repeating rifles supplanted it post-Civil War.

**Springfield Trapdoor (1865–1892):** Breech-loading conversion of the Civil War muzzle-loader. Hinged breech ("trapdoor") allowed soldiers to fire 8–10 rounds per minute. Chambered in .45-70 Government. This is the rifle that armed the infantry in most post-Civil War Indian Wars.

**Henry Rifle (1860–1866):** First successful lever-action repeater. .44 calibre rimfire, tubular magazine holding 16 cartridges. Confederate troops called it "the rifle they load on Sunday and shoot all week." Produced until Winchester took over.

**Winchester Model 1866 ("Yellow Boy"):** Named for its brass receiver. Evolved from Henry design. .44 Henry rimfire.

**Winchester Model 1873:** The most iconic rifle of the classic Western era. .44-40 calibre (also available in .38-40 and .32-20). Chambered for the same cartridge as many Colt revolvers — a crucial logistical advantage on the frontier. This is "the gun that won the West."

**Winchester Model 1876 (Centennial):** Adopted by Canadian Mounties. Heavier, chambered for full-power rifle cartridges.

**Winchester Models 1886, 1892, 1894, 1895 (designed by John Browning):** Progressively more powerful. The 1894 introduced .30-30 with smokeless powder, eliminating the obscuring black powder cloud that revealed a shooter's position.

**Springfield 1903:** Bolt-action, the U.S. military's primary rifle from 1905 through early WWII. Not a Western-era gun unless your story is set in the twentieth-century West.

### Shotguns
Measured in **gauge**, not calibre. A 12-gauge barrel requires twelve lead balls of that diameter to make one pound. Smaller gauge = larger bore. 12-gauge is the most common. 10-gauge is heavier.

**Single and double-barrelled:** Standard until the 1890s. The "coach gun" (short double-barrelled shotgun carried by Wells Fargo guards) is the classic image. Double guns usually had external hammers and two triggers, one per barrel. Later hammerless models emerged.

**Winchester Model 1897 (pump-action):** Designed by Browning. 12-gauge or 16-gauge. Five-round tubular magazine. The external hammer allowed "slam fire" — holding the trigger while pumping produced continuous fire. Available from 1897 onward; before that date, pump-action shotguns did not exist in your story.

**Shot loads:** Buckshot (larger pellets) for fighting. Birdshot for game. Rock salt for dispersing crowds without lethal intent. Dimes — allegedly used by New Mexico lawman/assassin Bob Ollinger (killed by Billy the Kid) for maximum wound damage.

---

## Historical Gunfights: The Reality Beneath the Myth

### No Queensberry Rules
There was no standard etiquette. The duelling conventions of the Old South — seconds, formal declarations, turns — were mostly absent in the frontier West. Survival was the objective. Shooting first, from ambush, or into a man's back was common and not generally considered dishonourable by participants.

### Famous Myths vs. Reality

**Wild Bill Hickok and the McCanles "Gang":** Dime novelists described this as "the greatest one-man gunfight in history," with Hickok defeating a dozen men despite wounds. Reality: the "gang" was a group of unarmed farmers, including a twelve-year-old boy, disputing unpaid debts. Hickok shot the first victim from ambush through a curtain. Station employees killed the other two with a shotgun and a hoe.

**The O.K. Corral (Tombstone, October 26, 1881):** Three Earp brothers and Doc Holliday vs. the Clanton-McLaury faction. Duration: approximately thirty seconds. Three Cowboys killed, Holliday and two Earps wounded. One Cowboy (Tom McLaury) had no gun on him when found dead. Both sides were carrying law enforcement credentials from competing agencies.

**Famous kill counts vs. reality:** Wyatt Earp claimed "over a dozen" kills; only two are confirmed. Bat Masterson's confirmed kills: three. Pat Garrett: two kills, but one of them was Billy the Kid. The Kid himself: probably four confirmed, despite the "one for every year of his life" legend.

### The Newton, Kansas Shootout (1871)
Five dead, three wounded. Started with a personal argument between lawmen, escalated over eight days, and concluded in a chaotic multi-person melee with bystanders drawing guns. This is more representative of real frontier gunfights than a two-man draw on Main Street.

### Physical Realities of Frontier Violence
- **A shoulder wound is not trivial.** It may sever the subclavian artery and kill within minutes. Even if not immediately fatal, it will be crippling and infection is a genuine threat.
- **Pistol-whipping (being "buffaloed") produces real head injuries:** concussion, skull fracture, permanent brain damage.
- **Most frontier doctors were undertrained and underequipped.** Infection killed far more wounded men than immediate blood loss.
- **Alcohol impairs aim.** Most frontier barroom shootings involved intoxicated participants, which is why kill counts were so often low relative to rounds fired.
- **Revolvers are close-range weapons.** Effective aimed fire past 25 yards with a handgun requires genuine skill. Past 50 yards it's wishful thinking. Writing characters who shoot people at 100 yards with a revolver is fantasy.

---

## Writing Gunfight Scenes

### The Before
Tension before violence is often more gripping than the violence itself. What are each participant's stakes? Who has the psychological advantage? What is each person trying to avoid as much as trying to achieve?

### The During
- Keep it short. Real gunfights lasted seconds. Extended choreographed exchanges are cinematic, not realistic.
- Multiple weapons, multiple participants. Few historical gunfights were clean one-on-one affairs.
- Miss shots. Most bullets missed. The ones that didn't were often fired at close range.
- Noise, smoke, confusion. Black powder produced substantial smoke obscuring the field. Even smokeless powder is loud enough to cause disorientation.
- Emotional chaos. Adrenaline produces tunnel vision, loss of fine motor control, distorted time perception.

### The After
This is where most Western fiction fails. The aftermath of violence has physical, emotional, and social consequences:

- Physical: Wounds, shock, blood, the practical problem of a body and what to do with it.
- Emotional: Post-traumatic stress existed long before the clinical term (Herodotus documented it in 490 BCE after Marathon). Guilt, sleeplessness, hypervigilance, desensitisation — all existed.
- Social: Killing, even justified killing, changes a person's social position. Other people respond to the fact that this person has killed.

**→ For the narrative handling of violence's aftermath, load [08 Narrative Craft](08-narrative-craft.md)**

---

## Machine Guns and Heavy Weapons

**Gatling gun (1862):** Hand-cranked, multi-barrelled. 200 rounds per minute. Not a true automatic (requires manual crank) but functionally comparable. Used in Indian Wars and Spanish-American War. Available from 1866 in the West in limited quantities.

**Hotchkiss revolving cannon (1872):** Used at Wounded Knee (1890) and against the Nez Percé (1877).

**Maxim machine gun (1884):** First true automatic weapon. .303 calibre, 600 rounds per minute. British military adoption. Too late for most classic Western settings.

**Thompson submachine gun ("Tommy gun") (1919):** .45 calibre, full automatic. Available from 1921 commercially. This is a Prohibition and Depression-era weapon. If your story is set before 1919, a Tommy gun is an anachronism.

---

## Quick-Reference Weapon Availability Table

| Weapon | Available From |
|--------|---------------|
| Flintlock pistols/rifles | 1600s |
| Percussion cap revolvers (Colt Paterson) | 1836 |
| Walker Colt | 1847 |
| Colt 1851 Navy | 1851 |
| Henry rifle | 1860 |
| Colt Single Action Army (Peacemaker) | 1873 |
| Winchester Model 1873 | 1873 |
| Smith & Wesson Schofield | 1875 |
| Winchester Model 1876 | 1876 |
| Winchester Model 1886 | 1886 |
| Winchester Model 1892 | 1892 |
| Winchester Model 1894 (.30-30) | 1894 |
| Winchester Model 1897 (pump shotgun) | 1897 |
| Springfield 1903 bolt-action | 1905 |
| Thompson submachine gun | 1919 (commercial 1921) |

**→ Cross-check against your story's date using [05 Historical Accuracy](05-historical-accuracy.md)**

---

**→ Continue to:** [05 Historical Accuracy](05-historical-accuracy.md) | [08 Narrative Craft](08-narrative-craft.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md) | [03 Character](03-character-craft.md)
