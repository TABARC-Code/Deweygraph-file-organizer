# 01 — Genre Architecture

**Loaded from:** [Core SKILL.md](../SKILL.md)  
**Cross-links:** [02 Setting](02-setting-and-place.md) | [08 Narrative](08-narrative-craft.md) | [05 Accuracy](05-historical-accuracy.md)

---

## What Is a Western?

A Western is a work of fiction set on the American frontier — but the frontier is not a fixed location or time. At different moments in history, the "wild" edge of American settlement was the Appalachians, the Ohio Valley, the Mississippi, the Rockies, the Southwest desert, the Pacific coast. Some authors push the definition to Canada's Klondike, Mexico's revolution-era border, or even to space. One experienced Western author summarises it best: "The Old West is not a certain place in a certain time. It's a state of mind. It's whatever you want it to be."

That flexibility is your first creative asset.

---

## The Subgenres — Know Which You're Writing

Failing to understand which subgenre you're working in produces unfocused manuscripts. The categories below are not rigid walls — they can and do overlap — but knowing your primary genre gives you structural clarity.

### Traditional Western
The classic template. Set west of the Mississippi, generally 1850–1900. Recurring elements: law vs. disorder, individual vs. tyranny, settler vs. nature or hostile forces, gambling, gunfights, range wars. The frontier is depicted as morally ambiguous but ultimately tameable. Think Louis L'Amour, Zane Grey, Owen Wister.

**What editors expect:** Strong moral stakes, clear conflict engine, period authenticity, an identifiable protagonist whose journey the reader can invest in.

**Traps:** Cardboard characters, anachronistic weapons or slang, an all-white cast with no acknowledgement of historical reality.

### Revisionist Western
Deliberately subverts traditional Western assumptions. Antiheroes replace heroes. Authority figures are corrupt. Native Americans and minorities are fully humanised. The moral framework is interrogated, not assumed. Roots in the 1960s–70s (Peckinpah's films, Berger's *Little Big Man*).

**What editors expect:** A clear critique embedded in the narrative — not just darkness for its own sake. The deconstruction should serve a point.

**Traps:** Nihilism without purpose. Every character being equally despicable. Revisionism that becomes its own cliché.

### Contemporary Western
Set in the modern West. Cowboys still exist; so do ranches, rodeos, the vast landscape. But cars, phones, and modern crime exist alongside traditional frontier values. The tension between old and new is often the engine. Cormac McCarthy's Border Trilogy is the benchmark.

**What editors expect:** A genuine engagement with how frontier values have persisted, mutated, or collapsed. Not "cowboys with smartphones" as a joke, but a serious examination of what the West means now.

**Traps:** Nostalgia mistaken for substance. The modern setting deployed without thematic purpose.

### Northern
Westerns transplanted to Canada or Alaska. The Klondike gold rush, Mounties vs. outlaws, the wilderness as antagonist. The same character archetypes operate in different geography and legal frameworks. Canadian law enforcement culture (the RCMP) differs significantly from American marshal/sheriff systems — a source of both conflict and drama.

**What editors expect:** Geography and climate as genuine characters. The Mountie moral code plays differently than the American marshal's pragmatism. Exploit that.

### Weird Western
Horror, fantasy, and science fiction elements introduced into frontier settings. Vampires in Tombstone. Dinosaurs on the range. A gunslinger who is literally Death. This is not a fringe subgenre — it has roots going back to early pulps and continues to grow.

**What editors expect:** The Western elements must function as more than scenery. The weird element should change the moral stakes of the story, not just decorate them.

**Traps:** Using "Western + monsters" as a pitch that substitutes for story. The weird element needs to earn its place.

### Comedic Western
Played for laughs, but the best examples (Garner's *Support Your Local Sheriff*, Brooks's *Blazing Saddles*) understand the genre well enough to satirise it precisely. Comedic Westerns fail when they mock what they don't understand.

**What editors expect:** Real affection for the genre beneath the jokes. Satire requires mastery of what's being satirised.

### Romantic/Erotic Western
Romance from chaste to explicit. The frontier setting provides natural drama — isolation, danger, social codes around courtship — that supports romantic tension. Publishers like Harlequin have dedicated Western romance lines. "Adult" Western lines (Longarm, Slocum, The Gunsmith) mandate explicit content at a volume set by the publisher.

**What editors expect:** If you're writing for a series house, know the line's specific requirements before you write. Story still comes first, even in explicit fiction.

### Acid Western / Surrealist
Dreamlike, metaphysically charged, often psychedelic in sensibility. Think Jodorowsky's *El Topo* transplanted to prose. Rare in print, but exists. Characterised by symbolic rather than literal plotting, archetypes in place of psychologically realistic characters, and a deliberately hallucinatory landscape.

**What editors expect:** An internally consistent symbolic logic. This is the hardest subgenre to pull off because failure to achieve its metaphysical register looks like incoherence.

### Foreign/Euro Western
The tradition of Westerns made by non-American creators — Spaghetti Westerns being the most famous example. These often bring a more cynical, political, or existential reading of the frontier myth. An author from outside the United States may bring perspectives on conquest, capitalism, and manifest destiny that American authors self-censor.

---

## The Historical Arc of the Genre

Understanding where Western fiction came from prevents you from repeating what's already been exhausted — and reveals what remains available.

**Dime novel era (1860s–1890s):** Sensationalist, plot-driven, often factually loose. Real names (Jesse James, Buffalo Bill) used on fictional characters doing impossible things.

**Early golden age (1900s–1940s):** Wister's *The Virginian* (1902) established the formula. Zane Grey perfected the landscape-as-character approach. Max Brand elevated the prose. Louis L'Amour later industrialised it.

**Pulp era:** Short fiction in magazines like *Argosy*, before television killed the market.

**Television Westerns (1949–1975):** Changed reader expectations. Gunsmoke's Dillon is the template for the morally complex lawman as series hero.

**Post-Vietnam revision (1960s–70s):** Antiheroes, moral ambiguity, explicit violence, race consciousness. The genre grew up.

**Contemporary market:** Niche but active. Series titles (Longarm, Trailsman, Gunsmith) publish monthly. Literary Westerns (McCarthy, McMurtry) receive serious critical attention. New subgenres (Weird Western, romantic Western) bring new readers.

---

## Choosing Your Subgenre: Decision Points

Ask yourself these questions:

1. **What is my story actually about?** A theme of justice corrupted points toward Revisionist. A love story in hostile country points toward Romantic. A meditation on survival points toward Traditional or Contemporary.

2. **Who is my protagonist?** A morally clean hero suits Traditional. A damaged antihero suits Revisionist or Contemporary. A monster-hunter suits Weird. A woman fighting social constraints suits the more progressive corners of Revisionist or Contemporary.

3. **What do I want readers to feel?** Excitement and relief = Traditional. Discomfort and recognition = Revisionist. Dread and wonder = Weird. Desire and tension = Romantic.

4. **What publisher am I targeting?** Research their existing list before you commit. Tone and content requirements vary dramatically between, say, a Christian Western publisher and an adult series line.

---

## Subgenre Fusion

Combinations are legitimate and marketable:
- Traditional + Weird = most Weird Western fiction
- Revisionist + Romantic = the harder-edged contemporary Western romance
- Northern + Horror = fertile, underexplored territory
- Traditional + Comedy = requires genuine mastery of both

The rule: the fusion must serve a story, not just a pitch. "It's like *Tombstone* but with werewolves" is a pitch. The actual novel needs a reason for the werewolves to be there.

---

**→ Continue to:** [02 Setting & Place](02-setting-and-place.md) | [08 Narrative Craft](08-narrative-craft.md)  
**→ Back to:** [Core SKILL.md](../SKILL.md)
