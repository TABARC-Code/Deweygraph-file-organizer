---
skill: western-fiction-master
subskill: 09 — Glossary & Reference
classification: TABARC-Code
studio: TABARC-Studio Internal Use
sources:
  - Legends of America — Western Slang, Lingo, and Phrases (legendsofamerica.com/we-slang)
  - Ride South Dakota — Cowboy Dictionary (ridesouthdakota.com/rushmore-horseback-riding/cowboy-dictionary)
  - Adams, Ramon F. — Western Words: A Dictionary of the American West (University of Oklahoma Press; archive.org)
  - Internal craft synthesis
---

# 09 — Glossary & Reference

**Loaded from:** [Core SKILL.md](../SKILL.md)
**Cross-links:** [02 Setting](02-setting-and-place.md) | [05 Accuracy](05-historical-accuracy.md) | [06 Dialogue](06-dialogue-and-language.md)

---

## How to Use This Glossary

This is the master vocabulary and reference tool for Western fiction. It serves three functions:

**Function 1 — Dialogue authenticity.** Before committing to any period term you're uncertain of, look it up here first. If it isn't listed, cross-check against the Online Etymology Dictionary (etymonline.com) for first attested usage.

**Function 2 — Character voice.** Terms are not interchangeable across character types. A frontier lawyer, a drover, and a Mexican vaquero would use different subsets of this vocabulary. Deploy selectively, by character background and occupation.

**Function 3 — Anachronism prevention.** Cross-reference the Historical Timeline and Weapons tables below against your story's specific year. This glossary covers expressions that were period-current; slang invented after 1900 is not period-accurate for classic Western settings.

---

## A

- **Abisselfa** — by itself; alone
- **Abandons** — foundlings; also informally, a street prostitute
- **Above-board** — open, honest, without trickery or concealment
- **Above one's bend** — beyond one's power or reach
- **Above snakes** — above ground; alive. The alternative: six feet under
- **Absquatulate** — to leave suddenly or disappear without explanation
- **Ace in the hole** — a hidden weapon, concealed advantage, or emergency hideout
- **Ace-high** — first-rate, highly respected; or a winning poker hand (context determines which)
- **According to Hoyle** — correct; by the book. (*Hoyle* was a standard rule guide for card games)
- **Acknowledge the corn** — to admit the truth; confess an obvious personal failing
- **Acock** — knocked over; defeated; suddenly astounded
- **Acorn calf** — a weak or undersized calf
- **Across lots** — by the fastest possible route; taking the most direct way
- **Actual** — money; hard cash
- **Adam's ale** — water
- **Addle-headed** — empty-headed; stupid
- **Addle-pot** — a spoilsport; someone who ruins everyone else's enjoyment
- **Advantage** — *pocket advantage*: carrying a derringer charged and at half-cock inside a coat pocket, sometimes fired directly through the fabric
- **Afeared** — scared; frightened
- **Afterclaps** — unexpected consequences arising after an event was supposed to be finished
- **Airish** — somewhat cool (weather)
- **Airin' the lungs** — cursing; swearing
- **Airin' the paunch** — vomiting, particularly after heavy drinking
- **Airtights** — canned goods: canned beans, canned milk, canned fruit
- **Alfalfa desperado** — a cowboy's contemptuous term for a farmer or sodbuster
- **A lick and a promise** — a hasty, half-hearted job
- **All-fired** — extremely; intensely emphatic. *"He's all-fired lazy."* Also *hell-fired* and *jo-fired*
- **All my eye** — nonsense; untrue
- **All-overish** — uncomfortable; uneasy around someone
- **All the caboose** — everywhere; the whole lot
- **All to pieces** — completely; absolutely
- **All-standing** — without preparation; suddenly
- **Among the willows** — dodging the law; hiding from authorities
- **Angelicas** — young, unmarried women
- **Angoras** — goat-hide chaps with the hair left on; effective insulation in cold weather
- **Annex** — to steal (popularised around the annexation of Texas, which many regarded as theft)
- **Anti-fogmatic** — raw rum or whiskey; so-called as a preventive against morning fog
- **Anti-goglin** — lopsided; crooked
- **Apple** — the saddle horn
- **Apple jack** — liquor distilled from cider; also called *cider brandy*
- **Apple peeler** — a pocket knife
- **Apple-pie order** — perfect order; top condition
- **Arbuckle's** — cowboy slang for coffee, from the dominant commercial brand of the period. *"Get me a cup of Arbuckle's."*
- **Argufy / argy** — to argue; to carry weight as an argument
- **Arkansas toothpick** — a long, heavy fighting knife; also called a *California* or *Missouri toothpick*
- **Armas** — the Spanish forerunner of chaps; large panels of cowhide strapped to the saddle to protect the legs from thorns and brush
- **Ary** — either; any
- **At sea** — at a loss; not comprehending. *"When it comes to women, I'm at sea."*
- **Attitudinize** — to assume an affected or theatrical posture
- **Atwixt / atween** — between
- **Auger** — the boss; the man in charge of the operation

---

## B

- **Bach** — to bachelor it; to keep house without a woman (also spelled *batch*)
- **Backdoor trots** — diarrhoea
- **Bad box** — a difficult predicament. *"He was in a bad box."*
- **Bad egg** — a dishonest or worthless person
- **Bad hoss** — a bucking or unmanageable horse
- **Badlands** — from French *mauvaises terres pour traverser* ("bad lands to travel through"); applied to the barren, eroded regions of South Dakota and adjacent territories. Named by French trappers
- **Bad medicine** — bad news; an ill omen; a dangerous adversary. *"That man is bad medicine."*
- **Bag of nails** — everything in confusion; complete disorder
- **Bake** — to ruin a horse by riding it too hard, fast, or long
- **Balderdash** — nonsense; empty babble; foolishness
- **Ballast** — money
- **Balled up** — confused; tangled up
- **Ballyhoo** — exaggerated sales pitch; advertising bluster
- **Bamboozle** — to deceive; to impose upon; to confuse through trickery
- **Banco / bunko steerer** — a confidence trickster; a swindler who steers marks into games they cannot win
- **Banded** — hungry
- **Bangtail** — a wild mustang horse
- **Banjo** — a short-handled shovel (miner's term)
- **Bar dog** — a bartender
- **Barefoot** — an unshod horse
- **Bark** — to scalp
- **Barkin' at a knot** — attempting the impossible; wasting time on a useless task
- **Barking irons** — pistols
- **Barrel boarder** — a bum; a low-grade chronic drunk
- **Barrel fever** — a hangover
- **Base burner** — a drink of whiskey
- **Bat** — a frolic; a drinking spree
- **Bat wings** — a style of chaps; wide-flapped, snapped on rather than laced, easier to put on over boots
- **Bean eater** — a Mexican (period pejorative; deploy with historical awareness, not as comedy)
- **Bean master** — the camp or ranch cook
- **Bear sign** — donuts made on the trail. A cook who could produce them was held in unusually high regard
- **Bed ground** — the place where cattle are held overnight
- **Bed him down** — to kill a man
- **Bed-house** — a brothel
- **Bed-fagot** — a prostitute
- **Bedrock** — the lowest possible price or position. *"Is that your bedrock price?"*
- **Bee** — a community gathering organised around a specific task (quilting bee, barn-raising bee, husking bee)
- **Beef** — to kill. *"Doc beefed him."* (Derived from the killing of a cow for food)
- **Beef-headed** — stupid; dull as an ox
- **Been in the sun** — drunk
- **Been through the mill** — experienced; having endured hard times
- **Bellyache** — to complain
- **Belly cheater / belly robber** — the cook
- **Belly through the brush** — to dodge the law; to hide and run
- **Belly wash** — weak, poor-quality coffee
- **Belvidere** — a handsome man
- **Bend an elbow** — to have a drink
- **Bender** — a drinking spree; an extended binge
- **Benzinery** — a low-grade saloon (cheap whiskey was sometimes called *benzene*)
- **Berdache** — a Native American male who dressed and lived as a woman, fulfilling a recognised cultural and spiritual role within the tribe. Understood by most Indigenous communities as following a vision. (Modern usage: Two-Spirit)
- **Best bib and tucker** — one's finest clothes. *"Put on your best bib and tucker."*
- **Between hay and grass** — half-grown; neither fully a man nor still a boy
- **Bible** — a small packet of cigarette rolling papers. Also called a *dream book* or *prayer book*
- **Bible bump** — a cyst on the wrist or hand, said by old-timers to disappear if struck hard with a large book
- **Big augur / big sugar** — the ranch owner; the top boss
- **Big bug** — an important person; an official. *"He's one of the railroad big bugs."*
- **Big fifty** — a .50-calibre Sharps rifle used by professional buffalo hunters; 16 pounds unloaded, firing three-quarter-inch black powder cartridges at variable ranges. Used extensively in the buffalo slaughter of the 1870s
- **Big jump** — death
- **Big pasture** — the penitentiary; prison
- **Big nuts to crack** — a difficult or major undertaking
- **Bill show** — a Wild West show (from *Buffalo Bill* and *Pawnee Bill*, the era's leading promoters)
- **Bilk** — to cheat someone out of money or goods
- **Biscuit / biscuit roller / biscuit shooter** — the cook; the saddle horn (biscuit alone)
- **Bite the ground / bite the dust** — to be killed; to fall dead
- **Bit house** — a cheap, low-grade saloon
- **Black-eyed Susan / blue lightnin'** — a six-gun; a revolver
- **Black-leg** — a professional gambler; a card sharp
- **Blacksmithing** — acting as a pimp for a prostitute
- **Black snake** — a long bull whip
- **Blackstrap** — a mixture of gin and molasses; also a rough sweetener
- **Blame** — a euphemism for *damn* in polite or print usage
- **Blazes** — a euphemism for hell or the devil
- **Blatherskite** — a blustering, noisy, talkative fool
- **Blow** — to taunt or ridicule; also to inform on an accomplice to authorities
- **Blow out** — a feast; a celebration meal
- **Blue** — drunk
- **Blue belly** — a Yankee (Southern/Confederate usage; can be a fighting word)
- **Blue devils** — low spirits; depression. *"I have the blue devils today."*
- **Blusteration** — the noise of a braggart; hollow boasting
- **Bobtail guard** — the first cowboy on night cattle watch
- **Bone orchard** — a cemetery
- **Boot hill / boot yard** — a frontier cemetery, named because many buried there died violently, with their boots on
- **Brand artist** — a cattle rustler who alters brands on stolen stock; considered a more serious criminal than a simple thief
- **Brass** — audacity; nerve; boldness
- **Broken wind** — a respiratory condition in horses that permanently impairs their working ability
- **Brush** — a fight or brief skirmish
- **Buffaloed** — confused; bewildered; or pistol-whipped (struck over the head with a revolver barrel)
- **Bug juice** — cheap whiskey; bad liquor
- **Burn the breeze** — to ride at full gallop
- **Bushwhack** — to ambush; to attack someone from concealment

---

## C

- **Cahoots** — partnership; collaboration. *"In cahoots with the sheriff."*
- **Calaboose** — jail; the local lock-up
- **Calf slobbers** — meringue on a pie (cook's humorous term)
- **Calico queen** — a prostitute
- **California collar** — a hangman's noose
- **California prayer book** — a deck of playing cards
- **California widow** — a woman separated from her husband but not legally divorced; common in the West where men left families behind
- **Caporal** — a ranch foreman; the person directly supervising the hands (from Spanish *capataz*)
- **Cash in** — to die; to cash in one's chips. A poker metaphor
- **Catalogue woman** — a mail-order bride
- **Cat wagon** — a wagon used to transport prostitutes between frontier camps and towns
- **Cayuse** — a cowboy's horse; originally referring to horses of the Cayuse people of the Northwest, broadly applied to any range horse or Indian pony
- **Chisel** — to cheat; to swindle through deception
- **Chopper** — the cowboy who cuts specific cattle out of the herd during a roundup; a skilled and valued position
- **Chuck** — food; trail provisions. *"Is chuck ready?"*
- **Clinch mountain** — rye whiskey
- **Cocinero** — the trail cook (from Spanish; pronounced roughly *co-sin-AY-roh*). The second most important person on a trail drive
- **Compressed hay** — cow chips; dried cattle dung used as fuel on the treeless plains. Also called *prairie coal*
- **Converter** — a preacher; a circuit rider who saves souls
- **Corned** — drunk
- **Corral dust** — tall tales; lies; exaggerated boasting
- **Cut a rusty** — to show off; to court a woman with unnecessary flourish

---

## D

- **Daisy** — something excellent or first-rate. *"She's a real daisy."*
- **Dander** — anger. *"Got my dander up"* means provoked my anger
- **Deadshot** — strong liquor; also, a marksman who does not miss
- **Desert canary** — a donkey or burro; named for the sounds they produce
- **Dicker** — to barter; to negotiate a trade, usually involving livestock or goods
- **Doggery** — a cheap, low-grade saloon or disreputable establishment
- **Doggie** — a small, weak, or motherless calf; the one most likely to fall behind the herd
- **Don't go off half-cocked** — don't act rashly; wait until you're ready (directly from the flintlock mechanism, where firing from half-cock was dangerous and ineffective)
- **Down to the blanket** — nearly destitute; broke; at the end of one's resources
- **Dream book** — a packet of cigarette rolling papers (also *bible* or *prayer book*)
- **Dry gulch** — to ambush, especially from a ravine, gully, or concealed position
- **Dumpish** — sad; low-spirited; melancholy
- **Dunderhead** — a fool; a blockhead; someone with no good sense
- **Dusted** — thrown from a horse

---

## E

- **Eagle** — a gold ten-dollar coin; the half eagle was five dollars
- **Eatin' irons** — silverware; cutlery; any eating utensils
- **Elephant** — *"to see the elephant"*: to go to the city or the wider world for the first time; to lose one's innocence through experience; to discover that grand expectations are smaller than advertised
- **Equaliser** — a pistol; so-called because it equalises the physical odds between strong and weak, large and small
- **Eucher / euchered** — to be outsmarted; to be cheated or outmanoeuvred in a deal
- **Exodusters** — the name taken by Black emigrants who left the post-Civil War South for Kansas, inspired by the biblical Exodus account. Led significantly by Benjamin "Pap" Singleton

---

## F

- **Fag** — in cowboy usage, to get out fast; to move with urgency
- **Fagged out** — fatigued; completely worn out
- **Fair to middlin'** — feeling reasonably well; tolerable; not bad
- **Fair shake** — a fair deal; an honest exchange
- **Fandango** — from Spanish; a large, lively party featuring dancing and excitement; a celebration
- **Faro** — the dominant frontier card game. Players bet on the order in which cards would be drawn from a dealing box. Named from *pharaon* (pharaoh), the king of hearts in a French deck. Reputed to be nearly honest when unrigged; frequently rigged
- **Fat in the fire** — plans frustrated; trouble created. *"Now the fat's in the fire."*
- **Feller** — fellow; a man
- **Fetch** — to bring; also, to deliver a blow. *"Fetched him a punch in the nose."*
- **Fill a blanket** — to roll a cigarette from loose tobacco and papers
- **Fine as cream gravy** — excellent; first-rate; in top condition
- **Firewater** — liquor; whiskey; from early descriptions of the burning sensation felt by those unaccustomed to distilled spirits
- **Fish** — a rain slicker; an oilskin coat
- **Flash in the pan** — a misfire; a promising start that fails to produce results. Directly from the flintlock mechanism, where powder in the pan ignited but failed to ignite the main charge
- **Flannel mouth** — a smooth-talking flatterer; someone using charm as a tool
- **French leave** — desertion; leaving without permission or notice
- **French pox** — syphilis; widespread in frontier towns and among military garrisons
- **Funkify** — to frighten; to cause someone to lose their courage

---

## G

- **Gad** — a spur used on a horse
- **Gal-boy** — a tomboy; a girl with conventionally masculine habits or skills
- **Gallowses** — suspenders; braces holding up trousers
- **Get a wiggle on** — to hurry; to move with urgency
- **Git along** — move on (to cattle or to people)
- **Granger** — a farmer; a homesteader (often used with contempt by cattle-culture speakers)
- **Grub** — food, especially trail food; also, to eat
- **Gunsel** — originally, a young inexperienced cowboy or ranch hand. *Note: The later meaning of "small-time gunman" is post-period — use the original meaning for classic-era settings*

---

## H

- **Hay burner** — a horse (mildly contemptuous; implies the horse costs more in feed than it earns in work)
- **Heeled** — armed, particularly with a pistol. *"Is he heeled?"* — does he have a gun?
- **High-tail it** — to ride or run away at speed
- **Hog-killin' time** — a really good time; a proper celebration. *"We had a hog-killin' time."*
- **Hog-tied** — bound hand and foot; completely helpless and unable to act
- **Hooker** — a prostitute. Attested from 1845, appearing in John Russell Bartlett's 1859 *Dictionary of Americanisms* — fully period-accurate
- **Hornswoggle** — to cheat; to swindle through deception and misdirection

---

## I

- **Iron** — a firearm, particularly a pistol. *"He went for his iron."*
- **Iron horse** — a locomotive; a railroad train (used by many Native American groups on first encountering trains)

---

## J

- **Jake** — satisfactory; fine. *(Verify against etymonline.com before using in pre-1900 settings)*
- **Jinglebob** — a loose, ornamental spur rowel that produces a characteristic jingling sound when walking; also a cattle ear-mark (a slit causing the lower half of the ear to hang loose, associated with John Chisum's cattle)
- **John Barleycorn** — whiskey; alcohol personified

---

## K

- **Kack** — a saddle
- **Keep your powder dry** — remain prepared; stay ready for action. Directly from muzzle-loading firearm usage, where damp powder would not fire

---

## L

- **Lariat / lasso** — a rope used to catch cattle or horses; from Spanish *la reata* (the rope). The tool that defines the vaquero tradition
- **Lead plumb / lead poisoning** — being shot (black frontier humour)
- **Light a shuck** — to leave quickly; to get out fast. A *shuck* was a corn husk used as a torch; lighting one produced urgency
- **Loaded for bear** — well-armed; prepared for serious trouble

---

## M

- **Maverick** — an unbranded calf or steer; also a person who operates independently without allegiance to any group. From Samuel Augustus Maverick, a Texas rancher who famously neglected to brand his cattle, causing neighbouring ranchers to claim any unbranded cattle as Maverick's strays
- **Mesteño / mustang** — a wild horse; from Spanish *mesteño*, stray; animal belonging to no owner, from *mesta*, the Spanish ranchers' guild
- **Mossy horn** — an old, battle-scarred longhorn steer; by extension, an old-timer or veteran who has seen and survived everything

---

## N

- **Neck oil** — whiskey; any strong liquor
- **Nighthawk** — the cowboy responsible for guarding the remuda (horse herd) overnight; a separate role from the night cattle guards
- **No-account** — worthless; unreliable; good for nothing
- **Notch on his gun** — a reputed kill; the custom of carving a notch in a gun handle for each man killed is largely mythological in historical practice, but the metaphor was current and used

---

## O

- **On the dodge** — hiding from the law; living as a fugitive; wanted
- **On the prod** — looking for trouble; in a fighting mood; deliberately provocative
- **Outfit** — a ranch and all its associated equipment, horses, buildings, and crew; the whole operation
- **Owlhoot / owlhooter** — an outlaw; someone who travels at night to avoid detection by law enforcement

---

## P

- **Palaver** — to talk at length; to negotiate; to discuss without necessarily reaching a conclusion. From Portuguese *palavra* (word), through sailors' pidgin
- **Peeler** — a cowboy (old usage); also a police officer in regions with British legal heritage
- **Pilgrim** — a newcomer with no frontier experience; someone who does not yet understand how things work
- **Plug** — to shoot; also a poor-quality, worn-out horse not worth the feed it eats
- **Poke** — a leather pouch for carrying gold dust or coin; also a punch delivered with the fist
- **Powder burn** — to run very fast; to move at full speed

---

## Q

- **Quicken** — to spur a horse on; to urge a horse to move faster

---

## R

- **Range delivery** — cattle theft; rustling. Sardonic use of legal language for an illegal act
- **Remuda** — the herd of spare horses kept on a trail drive for swapping out tired mounts. From Spanish *remuda*, a relay or exchange of horses. Managed by the wrangler
- **Riding for the brand** — loyal to one's employer; faithful to one's obligations regardless of personal cost. One of the highest compliments in frontier culture
- **Ringtail** — a spirited, difficult horse; also a clever or unpredictable person
- **Rootin', tootin'** — energetic; boisterous; full of loud enthusiasm. Use carefully in serious fiction — tends toward self-parody
- **Round up** — to gather cattle for counting, branding, or trail driving; also the event itself. A roundup was a major social and economic event, not merely a task

---

## S

- **Saddle bum / saddle tramp** — a drifter; a cowboy who moves from outfit to outfit looking for work or a free meal without committing to any employer
- **Saddle stiff** — a cowboy; a working ranch hand
- **Sand** — guts; courage; toughness. *"He's got sand in him."* Among the highest compliments on the frontier
- **Savey / sabby** — to know; to understand. Corrupted from Spanish *saber* (to know); entered frontier speech through contact with Mexican vaqueros
- **Sawbones** — a doctor; a surgeon, particularly one associated with frontier medicine's rough-and-ready methods
- **Scamper juice** — whiskey; liquor
- **Scattergun** — a shotgun; a firearm that disperses shot over a wide area
- **Scoot** — to move fast; to run; to get going quickly
- **Señor / señora / señorita** — Mr. / Mrs. / Miss in Spanish; common throughout the Southwest and along the border; not exotic, simply correct for the region
- **Shakedown** — extortion; demanding payment under threat; also a thorough search of a person's belongings
- **Shoot the moon** — to gamble everything on a single action; to commit fully with nothing held back
- **Sky pilot** — a preacher; a minister; a circuit rider. Sometimes ironic
- **Slick** — an unbranded calf; also a smooth-talking swindler
- **Smoke** — a gunfight; an exchange of gunfire. *"He went for smoke."* — he drew his weapon
- **Sodbuster / soddie** — a farmer, particularly one breaking prairie sod. Often used with contempt by cattle-culture speakers
- **Soiled dove** — a prostitute; the most common polite frontier euphemism
- **Sombrero** — a broad-brimmed hat, Spanish in origin; not synonymous with all Western hat styles

---

## T

- **Tally man** — the person responsible for counting cattle during a roundup or at the end of a drive
- **Tenderfoot** — a newcomer with no frontier experience; the opposite of a seasoned hand; someone who does not yet know how to survive
- **Territory** — an organised land division under federal jurisdiction, prior to achieving statehood; a place with less settled law and more opportunity for those outside it
- **Throw lead** — to shoot; to open fire
- **Tie a can to it** — to put a stop to something; to dismiss or get rid of something entirely
- **Tin star** — a law enforcement badge; a lawman
- **Trail boss** — the person in full command of a cattle drive; all decisions, all responsibility, all authority

---

## U / V

- **Vamoose** — to leave quickly; to get out. From Spanish *vamos* (let's go); entered frontier speech through border contact
- **Vaquero** — a Hispanic cowboy; the originator of the entire cowboy tradition. From Spanish *vaca* (cow). The word *buckaroo* is a direct corruption of this word. The vaquero tradition preceded the Anglo-American cowboy by two centuries

---

## W

- **Waddy** — a cowboy; a general term for a working ranch hand
- **Widow-maker** — an extremely dangerous horse; also any person, situation, or weapon likely to produce widows
- **Wrangler** — the cowboy responsible for the remuda on a trail drive; typically the youngest and least experienced hand, doing the hardest unglamorous work

---

## X / Y / Z

- **Yannigan bag** — a small personal bag carried by a cowboy on the trail for small belongings; not a saddlebag
- **Yellow-bellied** — cowardly; lacking courage; unwilling to face danger

---

## Trail Drive Crew: Roles and Hierarchy

Understanding crew structure prevents anachronism in trail drive scenes. The hierarchy was real and matters for characterisation.

| Role | Function | Status |
|------|----------|--------|
| Trail Boss | Overall command; every decision | Highest |
| Segundo | Assistant trail boss; commands in absence | Second |
| Point Riders (2) | Lead the herd at the front; the best cowboys | High |
| Swing Riders (2) | Keep the middle of the herd in shape | Middle |
| Flank Riders (2) | Keep the rear third from straggling | Middle-low |
| Drag Riders (2–4) | Follow directly behind the herd; eat the dust | Lowest cowboy position |
| Wrangler | Manages the remuda; usually youngest hand | Below drag riders in status |
| Cook (Cocinero) | Feeds everyone; drives the chuck wagon | Second-highest in practice — do not antagonise the cook |
| Nighthawk | Guards the horse herd overnight; separate role | Operates on a different schedule from day crew |

---

## The Major Cattle Trails

Getting a trail wrong is a factual error. Each had a specific route, specific period of operation, and specific terminus.

| Trail | Route | Active Period |
|-------|-------|--------------|
| Shawnee Trail | Texas to Missouri / Kansas (eastern) | 1840s–1870s |
| Chisholm Trail | Texas to Abilene, Kansas | 1867–1884 |
| Western Trail | Texas to Dodge City, Kansas | 1874–1893 |
| Goodnight-Loving Trail | Texas through New Mexico to Colorado / Wyoming | 1866–1886 |
| Bozeman Trail | Wyoming north to Montana gold fields | 1863–1868 (closed by Red Cloud's War, Fort Laramie Treaty) |
| Oregon Trail | Missouri to Oregon / California | 1836–1869 (superseded by the transcontinental railroad) |

---

## Key Historical Timeline

A curated reference of the dates most critical to Western fiction accuracy. Always verify regional specifics — rail line completion, territorial status changes, and the founding of institutions varied significantly by location.

| Date | Event |
|------|-------|
| 1492 | Columbus reaches the Americas |
| 1565 | Spanish establish St. Augustine, Florida — the oldest continuously occupied European settlement in the continental U.S. |
| 1607 | Jamestown, first permanent English colony |
| 1789 | U.S. Marshals Service established |
| 1803 | Louisiana Purchase — 828,000 square miles acquired from France |
| 1821 | Mexico gains independence from Spain |
| 1823 | Monroe Doctrine |
| 1836 | Texas Revolution; the Alamo; Colt Paterson revolver (first practical revolver) |
| 1840s–1870s | Shawnee Trail operational |
| 1845 | Texas annexed by the United States |
| 1846 | Mexican War begins; Oregon Treaty |
| 1847 | Walker Colt; chloroform becomes available as an anaesthetic |
| 1848 | Mexican Cession (California, Arizona, Nevada, Utah, New Mexico, Colorado); New York Married Women's Property Act |
| 1849 | California Gold Rush; San Quentin prison opens |
| 1851 | Pinkerton Detective Agency founded (February) |
| 1854 | Republican Party founded |
| 1855 | First Japanese settlers arrive in California (Gold Hill) |
| 1860 | First dime novel published; Lincoln elected; South secedes |
| 1860–1861 | Pony Express operational — April 1860 to October 1861 (only 19 months total) |
| 1861 | Transcontinental telegraph completed (October); Civil War begins; Pony Express ceases |
| 1862 | Homestead Act; Gatling gun; Pacific Railway Act |
| 1863–1868 | Bozeman Trail operational (closed by Red Cloud's War; Fort Laramie Treaty 1868) |
| 1865 | Civil War ends; Thirteenth Amendment (abolition of slavery) |
| 1866–1886 | Goodnight-Loving Trail operational |
| 1867–1884 | Chisholm Trail at peak operation |
| 1869 | Transcontinental railroad completed, 10 May, Promontory Point, Utah; Wyoming Territory grants women full voting rights; Arabella Mansfield licensed as first female lawyer in U.S. |
| 1870 | Naturalization Act restricts citizenship; effectively bars Chinese from naturalisation |
| 1872 | Taylor v. Taintor (Supreme Court — expands bounty hunter authority across state lines) |
| 1873 | Colt Single Action Army ("Peacemaker"); Winchester Model 1873 |
| 1874–1893 | Western Trail operational |
| 1875 | Bass Reeves becomes Deputy U.S. Marshal in Indian Territory |
| 1876 | Yuma Territorial Prison opens; Battle of Little Big Horn; Winchester 1876 |
| 1877 | "Pap" Singleton steers approximately 20,000 Black settlers to Kansas |
| 1878–1879 | Exoduster migration peak — Black settlers flooding into Kansas |
| 1880 | California Chinese population approximately 300,000 (around 10% of state) |
| 1881 | Gunfight at the O.K. Corral, Tombstone, Arizona (26 October) — duration approximately 30 seconds |
| 1882 | Chinese Exclusion Act |
| 1886 | Geronimo surrenders; formal end of the Apache resistance; Winchester 1886 |
| 1889 | Oklahoma land runs begin |
| 1890 | Wounded Knee massacre (29 December); U.S. Census Bureau declares the frontier "closed" |
| 1892 | Winchester Model 1892; Coffeyville raid — Dalton gang destroyed |
| 1893 | Colorado grants women full voting rights; Anti-Pinkerton Act |
| 1893 | Burnham's Massacre (in terms of aftermath — Dawes Act effects crystallising in Indian Territory) |
| 1894 | Winchester Model 1894 (.30-30, first smokeless powder lever-action) |
| 1897 | Winchester Model 1897 pump-action shotgun |
| 1898 | Spanish-American War |
| 1901 | Arizona Rangers formed; Thomas "Black Jack" Ketchum decapitated by miscalculated long drop at hanging, New Mexico |
| 1905 | Springfield 1903 bolt-action rifle adopted by U.S. military |
| 1907 | Bass Reeves retires after 32 years as Deputy U.S. Marshal — 14 confirmed kills, never wounded; US-Japan "gentleman's agreement" limits Japanese immigration |
| 1907 | Edwin McCabe's Langston, Oklahoma — Black township established |
| 1908 | Bureau of Investigation (forerunner of FBI) created; Ford Model T commercially available |
| 1909 | Arizona Rangers disbanded following cross-border incident |
| 1910–1920 | Mexican Revolution; Pancho Villa border raids |
| 1913 | California Alien Land Law bars Japanese-Americans from owning land |
| 1916 | Pancho Villa raids Columbus, New Mexico — last foreign attack on U.S. soil until Pearl Harbor |
| 1919 | Thompson submachine gun developed |
| 1920 | Nineteenth Amendment — nationwide women's vote |
| 1921 | Thompson submachine gun commercially available (the Depression-era weapon — not frontier) |
| 1924 | Immigration Act — Japanese immigration effectively banned |

---

## Weapons Quick-Reference

For the complete technical breakdown of each weapon, load [04 Weapons & Violence](04-weapons-and-violence.md). This table is for fast date-checking.

| Weapon | Type | Available From | Key Notes |
|--------|------|---------------|-----------|
| Flintlock pistol / rifle | Single-shot muzzle-loader | 1600s | 3–4 shots per minute maximum; weather-sensitive |
| Percussion revolver (Colt Paterson) | 5-shot, single-action | 1836 | First practical revolver |
| Walker Colt | 6-shot, .44 cal | 1847 | Designed with Texas Ranger Samuel Walker |
| Colt 1851 Navy | 6-shot, .36 cal | 1851 | Standard Civil War sidearm |
| Henry rifle | 16-shot lever-action, .44 rimfire | 1860 | "Load Sunday, shoot all week" — Confederate troops' description |
| Colt Single Action Army ("Peacemaker") | 6-shot, .45 cal | 1873 | The defining revolver of the classic era |
| Winchester Model 1873 | Lever-action, .44-40 | 1873 | "The gun that won the West" — same cartridge as many Colt revolvers |
| Smith & Wesson Schofield | Top-break, .44 cal | 1875 | Faster reloading than Colt SAA; used by Earp, James, the Kid |
| Winchester Model 1876 | Heavy lever-action | 1876 | Adopted by Canadian Mounties (RCMP) |
| Winchester Model 1886 | Full-power lever-action | 1886 | John Browning design; handles large rifle cartridges |
| Winchester Model 1892 | Lighter lever-action | 1892 | Practical replacement for the 1873 |
| Winchester Model 1894 (.30-30) | Lever-action, smokeless powder | 1894 | Eliminates black powder smoke cloud from shooter's position |
| Winchester Model 1897 | Pump-action shotgun, 12/16 gauge | 1897 | Capable of "slam fire" (hold trigger, pump continuously) |
| Springfield 1903 | Bolt-action rifle | 1905 | Military standard through early WWII |
| Thompson submachine gun ("Tommy gun") | Full-auto, .45 cal | 1919 (commercial 1921) | Prohibition and Depression-era only — not a frontier weapon |

---

## Sources for Further Research

The following sources were used in constructing this glossary and are recommended for deeper research:

- **Ramon F. Adams, *Western Words: A Dictionary of the American West*** (University of Oklahoma Press, 1968) — the foundational scholarly lexicon of frontier vocabulary, compiled from period sources. Available digitally at: dn720305.ca.archive.org/0/items/westernwordsdict00adam/westernwordsdict00adam.pdf
- **Legends of America — Western Slang, Lingo, and Phrases** — legendsofamerica.com/we-slang — a comprehensive 15-page web resource drawing on period newspapers, books, and century-old dictionaries
- **Ride South Dakota — Cowboy Dictionary** — ridesouthdakota.com/rushmore-horseback-riding/cowboy-dictionary — a practical working vocabulary drawn from the cowboy tradition
- **Online Etymology Dictionary** — etymonline.com — essential for verifying first attested usage of any term before committing it to period dialogue
- **Chronicling America** — chroniclingamerica.loc.gov — digitised period newspapers; the best source for contemporary idiom, pricing, and social texture no secondary source can replicate

---

**→ Back to:** [Core SKILL.md](../SKILL.md) | [06 Dialogue](06-dialogue-and-language.md) | [05 Accuracy](05-historical-accuracy.md)
