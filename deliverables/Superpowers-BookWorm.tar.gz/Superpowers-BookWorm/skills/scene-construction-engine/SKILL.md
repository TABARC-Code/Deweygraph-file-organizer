---
name: scene-construction-engine
description: >
  Builds the internal architecture of a scene before prose is written: goal,
  conflict, outcome, beats, tension placement, and scene-sequel rhythm. Use when
  a scene entry needs to be fully specified before drafting, when a scene lacks
  internal structure, or when scene-level tension and hook placement need
  calibration. Triggers on: "how do I build this scene?", "the scene has no
  shape", "scene ending isn't landing", "scene feels flat", "I know what happens
  but not how to structure it", or when any craft skill needs scene-level
  construction before its own technique can be applied.
---

# Scene Construction Engine

A scene is not a sequence of events. It is a unit of story with a defined
goal, an opposing force, an outcome, and an emotional consequence. Build the
architecture first. Prose fills architecture; it cannot substitute for it.

---

## The Scene Specification

Every scene requires these seven elements before drafting begins. If any are
missing, the scene is not ready to write.

**1. Scene goal**
What does the POV character want to achieve or avoid in this specific scene?
This must be concrete and immediate — not "safety" but "get across the border
without the marshal seeing her." The goal must be achievable or defeatable
within the scene's timeframe.

**2. Opposing force**
What blocks the scene goal? The opposing force can be another character,
circumstance, the protagonist's own psychology, information they don't have,
or the physical world. It must be active — something that presses back.

**3. Scene outcome**
One of four results:
- **Yes, and** — goal achieved with an unexpected benefit
- **Yes, but** — goal achieved at unexpected cost or with complication
- **No, but** — goal failed but something is gained (information, relationship, new option)
- **No, and** — goal failed and the situation is now worse

Avoid "yes" without qualification — unearned victories flatten the story.
Avoid "no, and" too frequently — unrelenting failure numbs the reader.

**4. Information economy**
What does the reader know that the POV character doesn't? What does the POV
character know that the reader doesn't yet understand? What does neither know?
Information asymmetry is a primary source of tension and irony.

**5. Emotional register and arc**
What is the POV character's emotional state at the scene's opening? At the
scene's close? The emotional arc must move — same state in and out means
nothing happened to the character, only to the plot.

**6. Continuity commitments**
What facts does this scene establish that later scenes must honor? What facts
from earlier scenes does this scene depend on? These are continuity flags —
record them before drafting.

**7. Transition**
How does this scene connect to the next? The transition is not a summary
("and then she went to...") — it is the emotional or narrative momentum that
carries the reader forward. End at a decision point, a revelation, or a raised
question. Never at resolution if another scene follows.

---

## Scene-Ending Hook Selection

When the scene outcome is determined, match the scene ending to a hook type:

| Outcome | Recommended hook type | When to use |
|---|---|---|
| Yes, and | Complication hook | New possibility creates new threat |
| Yes, but | Revelation hook | The "but" reveals something unexpected |
| No, but | Question hook | Failure raises the next question explicitly |
| No, and | Ticking clock / escalation | Worse situation adds urgent new pressure |
| Any | Character decision | Scene ends the moment before the next choice |

For full hook technique, tension calibration, and genre-specific placement:
→ `superpowers-bookworm:hook-and-tension-system`

---

## Scene-Sequel Rhythm

After any scene with significant dramatic action or revelation, insert a sequel
before the next scene begins. Skipping the sequel makes characters feel robotic.

**Sequel structure:**
1. **Reaction** — the immediate physical/emotional response (involuntary)
2. **Emotion** — the slower emotional processing
3. **Thought** — what the character concludes from what happened
4. **Decision** — what they choose to do next

The sequel can be brief (two sentences) or extended (half a page). Scale to
the weight of the scene that preceded it. The decision at the end of the sequel
is the opening impulse of the next scene.

---

## Scene Construction for Specific Craft Contexts

### When called from hook-and-tension-system

Focus on scene-ending hook type and placement. Receive: scene outcome (goal
achieved / failed / partial), scene type, new complication introduced. Select
hook type from the table above. Do not rebuild the scene's goal/conflict
structure — only the ending placement.

### When called from mystery-crime-module

Focus on information economy and tension through knowledge asymmetry. Receive:
scene position in the information economy (reader knows more / less than
protagonist), which knowledge changes by scene's end, whether the scene is a
clue drop, a red herring reveal, or a misdirection. Build the scene's
information architecture around the asymmetry. The mystery's power comes from
the reader's knowledge of what the protagonist doesn't yet know.

### When called from horror-craft-module or fear-and-emotion-system

Focus on the emotional arc: how does the fear state change from scene open to
scene close? What is the POV character's vulnerability profile, and how does
the scene exploit it? The scene goal should include an element of avoidance or
protection. The outcome should make the avoided thing more likely, not less.

### When called from military-gothic-voice

Focus on interiority architecture within the scene structure. The emotional
arc runs through the character's body — physical state, damage, exhaustion,
pain as moral register. The sequel is abbreviated; aftermath is carried
forward into the next scene's opening posture, not processed in a pause.

---

## Scene Diagnosis — When the Scene Isn't Working

Before rebuilding a scene that fails, identify which of the seven elements is
broken or absent:

| Symptom | Missing element | Fix |
|---|---|---|
| Scene feels like it could be skipped | No scene goal, or goal not meaningful to character | Rebuild goal from character's want and fear |
| Scene ends flatly | No hook; outcome resolves without complication | Apply scene-ending hook from table above |
| Scene feels too long | Goal/conflict ratio off; too much sequel without action | Cut sequel; compress reaction to two beats |
| Characters feel mechanical | Emotional arc not moving | Specify opening and closing emotional states |
| Scene changes nothing | Outcome is "yes, and" with no cost or complication | Change outcome to "yes, but" or "no, but" |
| Reader lost track of what matters | Information economy unclear | State explicitly what reader knows vs. character knows |

For root cause diagnosis of failing scenes:
→ `superpowers-bookworm:systematic-scene-diagnosis`

---

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:hook-and-tension-system` | Scene ending needs hook placement | Scene outcome; scene type; new complication |
| `superpowers-bookworm:mystery-crime-module` | Scene needs information economy calibration | Scene position in info economy; knowledge change; scene type |
| `superpowers-bookworm:horror-craft-module` | Scene needs fear-state arc construction | Vulnerability profile; fear state target; scene position |
| `superpowers-bookworm:fear-and-emotion-system` | Scene needs emotional arc specification | Fear state target; amplifier type; scene type |
| `superpowers-bookworm:outline-driven-writing` | Scene spec needs internal architecture before prose | Scene outline entry: goal stated; architecture may be incomplete |
| `superpowers-bookworm:author-craft-compass` | Scene construction identified as weakness | Author profile; scene failure symptoms |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:hook-and-tension-system` | When hook type is selected and needs full technique | Hook type; scene ending; genre context |
| `superpowers-bookworm:outline-driven-writing` | When scene spec is complete and ready for prose | Complete seven-element scene spec |
| `superpowers-bookworm:systematic-scene-diagnosis` | When scene is failing and root cause needs diagnosis before reconstruction | Scene with identified symptom |
| `superpowers-bookworm:pov-and-voice-engine` | When the emotional arc requires specific interiority depth | POV type; emotional arc start/end states |
| `superpowers-bookworm:continuity-verification` | When continuity commitments from this scene need logging | New facts established; dependencies on earlier facts |

**Returns:**
- Complete seven-element scene specification
- Scene-ending hook type selected with placement note
- Sequel structure outlined
- Continuity flags listed for the continuity log
- Transition to next scene specified
