---
name: requesting-editorial-review
description: Use when completing a chapter, before claiming any draft ready, or when a fresh editorial perspective is needed. Dispatches a senior editorial reviewer subagent that reads only the chapter, story bible, and continuity log — not your session history.
---

# Requesting Editorial Review

## Core Idea

Dispatch a fresh editorial reviewer subagent with precisely crafted context — never your session's history. The reviewer reads as a senior editor: focused on what was written and whether it works, not on your thought process or intentions.

## Core Principle

Review early, review often. A problem caught at chapter three is a structural fix. Caught at chapter twenty, it's a rewrite.

## When to Request (mandatory)

- After completing each chapter in subagent-driven-drafting
- Before claiming any draft ready for a full manuscript pass
- When stuck (the reviewer's fresh read may reveal what you can no longer see)
- Before any major structural revision (baseline check: what is currently working)

## How to Dispatch the Editorial Reviewer Subagent

### Step 1 — Gather context materials

```
CHAPTER_FILE: path/to/ch[N]-[slug].md
STORY_BIBLE: docs/novel-superpowers/bibles/[latest-bible].md (summary form)
CONTINUITY_LOG: docs/novel-superpowers/continuity-log.md (up to this chapter)
CHAPTER_N: the chapter number and its position in the arc
WHAT_THIS_CHAPTER_MUST_DO: [what the scene outline specified]
```

### Step 2 — Dispatch editorial-reviewer subagent with this template (fill in placeholders)

```
You are a supervising senior editor reviewing a chapter of a novel in progress.

CONTEXT:
- Chapter: {CHAPTER_N}
- Story bible summary: {STORY_BIBLE_SUMMARY}
- Continuity log to date: {CONTINUITY_LOG}
- What this chapter was designed to accomplish: {WHAT_THIS_CHAPTER_MUST_DO}

CHAPTER TEXT:
{CHAPTER_TEXT}

YOUR REVIEW TASK:
Assess this chapter against what it was designed to accomplish.

Return a structured editorial note with exactly these sections:

## What works
[2-4 specific observations — be specific about page/scene location]

## What doesn't work
[Issues ranked: Structural → Character → Scene-level → Prose. For each: state the specific problem, where it occurs, and what story function is failing.]

## Continuity conflicts
[Any contradiction with the continuity log or story bible. Flag every one.]

## Assessment
[One of: Ready to proceed | Needs revision before proceeding | Structural rethink required]

Do NOT rewrite prose. Do NOT suggest line edits unless a sentence is structurally broken. Report what the chapter is doing and whether it works.
```

### Step 3 — Act on feedback

- **Structural issues:** Do not proceed to the next chapter until resolved. Go to `superpowers-bookworm:systematic-scene-diagnosis` to diagnose before rewriting.
- **Character issues:** Fix before proceeding.
- **Scene-level issues:** Fix before proceeding.
- **Prose notes:** Triage — some are signal, some are noise. Use `superpowers-bookworm:receiving-editorial-feedback`.
- **Continuity conflicts:** Fix immediately, always. Update continuity log.
- **Push back if reviewer is wrong:** Technical craft reasoning, not defensiveness.

## Red Flags

- Skip review because "this chapter is fine"
- Proceed past a structural issue because "it'll resolve later"
- Ignore continuity conflicts
- Accept all feedback without triage

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:subagent-driven-drafting` | After each chapter draft — mandatory between chapters | Chapter text, continuity log, story bible summary, what chapter was designed to accomplish |
| `superpowers-bookworm:finishing-a-draft-branch` | Option 3: submit branch for editorial review | Branch chapter content |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:receiving-editorial-feedback` | After reviewer returns notes — always the next step | Reviewer's structured editorial note |
| `superpowers-bookworm:systematic-scene-diagnosis` | When structural or scene-level issues are found — before any rewrite | Issue identified by reviewer with scene location |
| `superpowers-bookworm:continuity-verification` | When continuity conflicts are flagged in the review | Conflicts listed; chapter and continuity log |

**Returns:**
- Reviewer subagent dispatched with complete context package
- Structured editorial note: What works / What doesn't work / Continuity conflicts / Assessment
- Assessment: Ready to proceed / Needs revision / Structural rethink required
