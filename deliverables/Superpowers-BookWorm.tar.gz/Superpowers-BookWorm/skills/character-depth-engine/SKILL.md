---
name: character-depth-engine
description: >
  Full character development engine. Builds characters from wound
  through arc. Maps psychology using the wound/lie/flaw/desire/fear
  stack. Applies Card's characterisation theory and Ackerman/Puglisi's
  emotion amplifier system. Constructs interiority, behavioural tells,
  and transformation arcs. Replaces the existing minimal stub.
  Use for new character creation, diagnosing flat characters,
  designing transformation arcs, or building antagonists with
  internal logic. Triggers on: "develop this character", "character
  feels flat", "make them believable", "character arc", "motivation
  isn't working", "antagonist needs depth".
---

# Character Depth Engine

Characters are not described into existence. They are known through what
they do, why they do it, and what they have done. Everything else is
decoration.

---

## THE PSYCHOLOGY STACK

Build every major character through this chain. Each layer explains the next.

```
WOUND       The formative damage. Specific event or sustained condition.
   ↓
LIE         What the wound made them believe about themselves or the world.
   ↓
FLAW        How the lie manifests in repeated behaviour.
   ↓
BEHAVIOUR   The patterns readers see on the page.
   ↓
ARC         Whether the lie is confronted, accepted, or abandoned by the end.
```

**Use the wound to explain the lie.**
**Use the lie to explain the flaw.**
**Use the flaw to explain why they make bad decisions under pressure.**

Without the wound, the flaw is arbitrary. With it, the flaw is inevitable.

---

## HOW READERS KNOW A CHARACTER

In descending power (Card):

1. **What they do** — Action is the strongest characterisation. Show it.
2. **Why they do it** — Motive shifts moral meaning entirely. Same act, different motive = different person.
3. **What they've done** — The past shapes present behaviour. Imply the history.
4. **Reputation** — What others say establishes expectation. Deploy this early.
5. **Habits** — Recurring behaviour implies history without stating it.
6. **Tastes** — Preference creates specificity. What they love or hate.
7. **Physical description** — Last and weakest when used alone.

Most weak characters are described (7) and never shown acting (1-2). Invert this.

---

## THE INTERROGATION METHOD (Card)

For any character decision, ask in sequence:

1. Why would they do this?
   *(First answer is usually cliché. Ask again.)*
2. What is the cost to them specifically?
3. What do they want vs. what do they need?
   *(These should be in tension.)*
4. What do they fear most? Does this action expose that fear?
5. What would they never do? How close does this come?

Then: **exaggerate one trait** beyond the norm. **Twist one assumption** about what this type of person does.

---

## DESIRE AND FEAR

Every character needs both, and they must conflict:

**Desire:** The concrete, external thing they want (the job, the relationship,
the escape, the revenge). This drives plot.

**Fear:** The internal condition they are trying to avoid (abandonment,
failure, exposure, loss of control). This drives character.

The best plots force characters to choose between desire and fear. Getting
what they want forces them to confront what they fear.

---

## THE MICE QUOTIENT — CHARACTER DEPTH BY STORY TYPE (Card)

Story type determines how deeply characters must be built:

| Story type | Depth required |
|------------|----------------|
| **Milieu** | Minimal. Character is a lens, not the subject. Stereotypes serve. |
| **Idea** | Low-moderate. Eccentricities and clear motive suffice. |
| **Character** | Full. No shortcuts. Transformation is the plot. |
| **Event** | Flexible. Deep enough to make their choices feel earned. |

Over-characterising a milieu story slows pace. Under-characterising a character
story makes the arc meaningless. Match depth to contract.

---

## SYMPATHY MECHANICS (Card)

**Creates sympathy:**
- Physical jeopardy (works immediately, no backstory needed)
- Chosen suffering for others (sacrifice)
- A plan with concrete goal and real stakes
- Courage paired with fair play
- Endearing imperfection alongside the virtues
- Being drafted into glory, not volunteering for it

**Destroys sympathy (difficult to recover from):**
- Sadism or deliberate cruelty with no counterweight
- Breaking a promise with no cost or consequence
- Passive victimhood beyond one scene — character must act
- Two competing inner voices holding a full conversation

**The balance:** A character can be unlikeable and still be compelling. They
cannot be uninteresting. Give villains genuine nobility somewhere. It makes
them harder to defeat and harder to dismiss.

---

## EMOTION AMPLIFIERS (Ackerman/Puglisi)

Physical and mental states that heighten emotional response without adding
plot events. Deploy as background conditions:

| Amplifier | Physical tells |
|-----------|----------------|
| **Cold** | Chattering teeth, shallow breath, impaired decision-making, extremity numbness |
| **Exhaustion** | Slurred speech, bloodshot eyes, inappropriate laughter or tears, bone-weight in limbs |
| **Hunger** | Obsessive food thoughts, hollow stomach ache, willingness to compromise principles |
| **Illness** | Feverish glassy eyes, laboured breathing, loss of time sense, dry mouth |
| **Inebriation** | Poor depth perception, tunnel vision, lowered inhibition, misread emotional cues |
| **Pain** | Teeth grinding, shallow breath, coppery taste, faintness, cold sweat |
| **Stress** | Rigid muscles, clenched jaw, insomnia, arguments start faster, mind won't stop |
| **Addiction** | Tremors, fixation, evasive speech, counting minutes to next use |

**Rule:** Amplifiers work as compound pressure. A character who is also cold,
hungry, and exhausted while facing the villain is under layered stress. That
must show in their choices — not just their description. Amplifiers that exist
only as description are set dressing. Amplifiers that force decisions are
characterisation.

---

## ARC OUTCOMES

Not all characters transform. Four valid arc types (Card):

| Arc type | What happens |
|----------|-------------|
| **Transformation** | Lie is confronted. Character genuinely changes. |
| **Unmasking** | True nature revealed. No change, but revelation. |
| **Environmental shaping** | External forces alter who they become. Character is acted upon. |
| **Refusal** | Cannot or will not change. Tragedy, irony, or cautionary note results. |

Arbitrary change without accumulated cause is worse than no change. Every
transformation needs either a specific catalyst or a series of mounting
pressures that make the change feel inevitable in retrospect.

**Anti-arcs (legitimate):** Some characters are who they are. Heathcliff does
not transform. That's the point. Commit to the choice.

---

## THE HERO AND THE COMMON MAN (Card)

Every successful story character must be simultaneously believable and
interesting. Too ordinary: boring. Too extraordinary: unbelievable.
The balance is what makes a character worth following.

**The Romantic/Realistic spectrum:**

Stories drift toward extraordinary heroes (Romantic) until they become
implausible, then swing back toward ordinary people (Realistic) until
they become dull. The best characters occupy both positions at once:

- They wear the mask of the common man
- Beneath it, they are in some way extraordinary
- That extraordinary quality is hidden, even from themselves, until the
  story forces it out

This is why the reluctant hero works. The character who doesn't think
of themselves as special — but proves to be — is more interesting than
the character who always knew they were.

**What "extraordinary" actually means:**

It does not mean superpowers, wealth, or physical perfection.
It means a specific quality that others in that world lack or suppress:

- An unusual moral clarity in a corrupt environment
- A skill deployed in service of others at personal cost
- A capacity for empathy that makes them a target
- A stubbornness that everyone else calls a flaw until it becomes a virtue

The extraordinary quality is often what causes their suffering before
it becomes what saves them or others.

**The "common man" layer earns belief:**

A character who is only remarkable is unbelievable. Ground them with:
- Ordinary anxieties (money, relationships, being liked)
- Specific failures not related to the plot
- Domestic detail that has nothing to do with their heroic quality
- Moments where their extraordinary quality is a liability, not an asset

**Application:**

When a character feels flat, ask: what is the extraordinary thing about
them that only this story can reveal? If the answer is "nothing", the
story has the wrong protagonist.

When a character feels unbelievable, ask: what ordinary thing about
them has been omitted? The remarkable quality needs the mundane layer
beneath it to be legible.

---

## CHARACTER HIERARCHY

Signal importance through (Card):

- **Page time** — most reliable signal of importance
- **Capacity for meaningful choice** — characters who affect others matter more
- **Frequency of appearance** — returning characters build expectation
- **Other characters' focus on them** — being talked about confers importance
- **POV access** — most potent signal of all

**Minor characters:** One notable attribute. Eccentric, exaggerated, or
obsessive once, then absent. If a minor character demands more, decide:
promote them to the story or cut the attribute that's pulling focus.

**Walk-ons:** Stereotypes. This is correct. They are scenery that moves.
Use them to contrast with major characters, not to show range.

---

## THE IMPLIED PAST (Card)

Give characters a full life without stopping the story to describe it.
The implied past shows history through present behaviour. Three methods:

**Expectations:**
What a character expects reveals what they've experienced.
A child flinching from an extended hand tells us everything without
a flashback. A character who checks every exit upon entering a room
has been trapped before. Show the expectation; let the reader infer
the history that produced it.

```
✓  When he reached past her for the salt, she didn't move.
   She'd learned not to.
```

**Habits:**
Specific recurring behaviours that imply the life behind them.
Counting change backward from the total. Always parking facing
the exit. Never sitting with her back to a door. Each habit is a
compressed biography.

```
✓  He drew three horizontal lines in every blank space on a cheque.
   Twenty years since his father's store, and he still did it.
```

The habit does not need to be explained. The reader infers the past.
If you explain it, you've switched from showing to telling.

**Networks:**
Characters exist in webs of relationship. Strangers recognise them.
Old debts surface. Past associations emerge in dialogue, in how
people behave around them, in what they won't say in public.

```
✓  Everyone in the shop glanced at her and then away.
   Not the look you got for having something on your face.
   The other kind.
```

**Rule:** Implied past works best through contradiction. A character
who is talkative everywhere except around their family. A fighter
who won't touch the particular type of weapon that killed someone
they loved. The gap between how they behave and how you'd expect
them to behave is the story.

---

## ATTITUDE AS CHARACTERISATION (Card)

Attitude is how a character responds to the world — more revealing than
anything they do or say directly. Every scene filtered through a POV
character should show that character's attitude toward what they observe.

```
✗  The room was small and had a window.
✓  The room was built for someone who wasn't meant to stay long.
   The window faced a wall.
```

Same room. The second version tells us how the character sees it.
Attitude makes setting, people, and events mean something. Without
it, description is inventory.

**Elaboration of motive** — the deeper purpose:
Don't settle for a character's stated reason for action. Ask what
they're not saying. The woman who volunteers for overtime because
"she likes staying busy" may actually be afraid of what her apartment
feels like at 6pm. The stated motive explains the action. The real
motive explains the character.

Ask of every significant choice: is this the first answer? If so,
push further. The second or third answer is usually more interesting
and almost always more true.

---

## PHYSICAL DESCRIPTION GUIDANCE

Physical description is the weakest characterisation tool and the most
over-relied on. When using it:

- Anchor to one or two specific, unexpected details rather than cataloguing features
- Choose details that imply history (scarred knuckles, ink-stained fingers, careful posture)
- Let other characters' reactions to the physical carry more weight than inventory
- Never use the mirror scene to deliver self-description

---

## NAMING CHARACTERS

Names must fit the world's linguistic logic. When naming is needed:
hand off to `superpowers-bookworm:worldbuilding-naming-engine` with character's region, social
class, era, and trade or family role. That skill returns a name with
documented etymology and the informal shortened version locals would use.

For POV depth: avoid giving multiple major characters names that start with the
same letter or have similar rhythms. The reader needs instant differentiation.

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile (genre, stage, weakness).
  Focus on the character build most critical to the identified genre. For Western:
  prioritise archetype-to-human translation. For horror: vulnerability stack first.
  For military gothic: wound-to-body-condition mapping. For mystery: villain-first build.

- `superpowers-bookworm:character-development` — arrives with: Phase 1 findings (want, need, wound, lie)
  and arc design from Phase 3. Receive as foundation — do not rebuild. Add sympathy
  mechanics, emotion amplifier system, flaw-to-behaviour mapping, and hierarchy layer
  on top. The development skill's profile is the spine; this skill adds the muscle.

- `superpowers-bookworm:horror-craft-module` — arrives with: vulnerability profile already identified
  (physical / psychological / social / epistemic). Focus on the vulnerability
  stack, not the full arc. How does this specific weakness make the horror worse?
  What does the protagonist do that makes their situation worse because of it?

- `superpowers-bookworm:mystery-crime-module` — arrives with: antagonist focus. Prioritise villain-first
  design: method flows from personality, motive flows from wound, internal
  justification is the lie they tell themselves. The antagonist's psychology must
  make the crime feel inevitable, not arbitrary.

- `superpowers-bookworm:character-psychology-engine` — arrives with: completed wound/lie/flaw/arc stack.
  Receive it as the psychological spine. Add sympathy mechanics, emotion amplifiers,
  and hierarchy layer on top. Do not rebuild the stack.

**Sends to:**

- `superpowers-bookworm:character-psychology-engine` — when a quick psychology reference is needed
  mid-build. Hand off: character name and role. That skill provides the fast
  stack framework. Return here for amplifiers, sympathy, and arc.

- `superpowers-bookworm:worldbuilding-naming-engine` — when character naming needs cultural or
  linguistic grounding. Hand off: character's region, social class, era, and
  trade or family role. That skill returns a name with etymological coherence.

---

## WHEN CALLED

1. Ask: **new character** (building) or **existing character** (diagnosing/deepening)?
2. If building: start with wound. Everything else flows from it.
3. If diagnosing: identify where the psychology stack breaks down.
   Usually: flaw exists without wound, so behaviour seems arbitrary.
4. For arcs: establish what the lie is before plotting the confrontation.
5. State assumptions explicitly. Ask one clarifying question if needed.
