---
name: outline-driven-writing
description: Use when drafting any scene, chapter, or section — before writing a single sentence of prose. Also use when a draft feels structurally incoherent or when scenes exist that don't clearly change anything. Triggers on: "let's write the next scene", "draft this chapter", "continue the story", "write scene X", or any request to generate prose.
---

# Outline-Driven Writing

## Iron Law

`NO PROSE WITHOUT A CONFIRMED SCENE OUTLINE FIRST`

## Core Idea

No prose without a confirmed scene outline first. The scene outline is the "test" — it defines what the scene must do (goal, obstacle, change, emotional state at end). The draft is the "implementation" — it must satisfy every beat in the outline. Refactor = prose revision pass after the beats are confirmed working.

## The Cycle (Red-Green-Refactor)

**OUTLINE:** Write the scene outline. It must state: scene goal, obstacle, outcome, what changes for the POV character by the end, emotional register. This is not a paragraph — it's a structured specification.

**VERIFY OUTLINE:** Can you state clearly what this scene must accomplish? If not, the outline is not complete.

**DRAFT:** Write minimal prose that satisfies all outline beats. Don't write beyond what the outline specifies.

**VERIFY DRAFT:** Does every outline beat appear in the draft? Did anything promised in the outline fail to arrive?

**REFACTOR:** Prose revision — word choice, rhythm, voice. Does not change beats or structure. Tests (outline beats) stay green.

**REPEAT:** Next scene.

## Deleting Drafted Prose

If you drafted a scene without an outline, delete the draft and start from outline. Do not "adapt" the draft while writing the outline. Do not keep it as reference. Delete means delete.

## Rationalizations

The editor has heard all of them.

- **"The scene is simple, I don't need an outline"** — Simple scenes have beats too. Outline takes three minutes.
- **"I'll outline after, just to capture the impulse"** — Outlines written after the draft describe what you wrote, not what the scene needs. They prove nothing.
- **"I already know what happens in this scene"** — Knowing ≠ specifying. Write the spec.
- **"Outlining kills spontaneity"** — Spontaneity without structure produces scenes that feel alive but don't function. Outline the what; discover the how in the draft.
- **"I'm on a roll, I'll outline the next five scenes later"** — The roll produces unusable prose if the scenes don't serve the story. Outline first.
- **"This is a first draft, structure doesn't matter yet"** — First drafts that ignore structure require structural rewrites. Structural rewrites are ten times more expensive than outlines.
- **"Deleting X pages is wasteful"** — Sunk cost fallacy. Keeping structurally incoherent prose is the waste.

## Verification Checklist (before marking scene complete)

- [ ] Scene outline was written before drafting
- [ ] Outline states: scene goal, obstacle, outcome, emotional change, what changed
- [ ] Every outline beat appears in the draft
- [ ] Nothing in the draft contradicts the outline
- [ ] Refactor pass complete (prose, not beats)
- [ ] `superpowers-bookworm:continuity-verification` run before completion

## When Stuck

| Problem | Solution |
|---------|---------|
| Don't know what the scene's goal is | The scene doesn't belong yet. Find where it belongs in the outline, or cut it. |
| Scene outline won't cohere | Story structure problem upstream. Go to `superpowers-bookworm:plot-architecture`. |
| Draft exceeds outline | Something new arrived. Decide: update the outline to include it, or cut the excess. Never just leave it. |
| Can't see why the scene changes anything | The scene has no function. Cut it or redesign it. |

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:story-outlining` | Before any drafting begins — outline-driven-writing enforces the outline contract | Confirmed outline with per-scene entries |
| `superpowers-bookworm:drafting-scenes` | At start of every scene — must precede prose | Scene entry from outline |
| `superpowers-bookworm:systematic-scene-diagnosis` | When a scene was written without an outline and the failure mode is structural | Scene draft with no prior outline |
| `superpowers-bookworm:author-craft-compass` | When structural incoherence identified as the author's weakness | Author profile; scene failure symptoms |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:plot-architecture` | When a scene outline won't cohere — structural problem upstream | Scene's position in the story and the incoherence |
| `superpowers-bookworm:continuity-verification` | After the verification checklist — mandatory before marking complete | Scene draft + outline spec |
| `superpowers-bookworm:systematic-scene-diagnosis` | When draft exceeds or contradicts outline and the root cause isn't clear | Scene draft vs outline spec discrepancy |

**Returns:**
- Confirmed scene outline (goal, obstacle, outcome, emotional change, what changed)
- Draft that satisfies all outline beats
- Verification checklist with all boxes checked
- Handoff to continuity-verification for completion gate
