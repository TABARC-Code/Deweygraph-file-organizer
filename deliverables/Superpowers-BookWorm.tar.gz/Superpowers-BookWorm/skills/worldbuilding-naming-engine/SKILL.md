---
name: worldbuilding-naming-engine
description: >
  Generates and validates names, locations, NPCs, and world details
  according to internal cultural and linguistic logic. Applies the
  absolute naming convention rules from the project files. Ensures
  geographic, cultural, and historical coherence. Generates NPC
  blocks following WFRP/Urban Cartographer conventions. Use for
  fantasy and historical setting construction, NPC generation,
  location naming, and world coherence checks. Triggers on: "name
  this place", "worldbuilding", "make the world feel real", "naming
  conventions", "NPC names", "location names", "generate an NPC",
  "does this name make sense", "build a settlement".
---

# Worldbuilding and Naming Engine

A world feels real when its names reflect how people actually name things:
through habit, geography, conquest, and linguistic drift. Not symbolism.
Not authorial intent. Habit and geography.

---

## THE TWELVE NAMING RULES (Absolute)

These rules apply to all settings unless the setting's internal logic
explicitly contradicts them. Violation without justification breaks
world coherence.

**1. Geography drives names.**
Settlements, rivers, regions take names from physical features.
River + descriptor. Peak + characteristic. Don't name villages after
abstract concepts (Hope, Justice, Faith) unless the naming event is
documented and the name is shown to be archaic.

**2. Language roots stay consistent.**
Choose one or two base language families per region. Apply regular
sound changes over time. Mixed phonetics require documented contact
or conquest to justify them.

**3. Names shorten with use.**
Formal: Karanthos Keep. Local speech: Karn. Universal linguistic law.
Document both. The formal name appears in documents; the short name
in dialogue.

**4. Conquerors rename.**
Occupation overwrites place names partially or entirely. Old names
persist in oral speech, in older documents, in the mouths of the
conquered. Layer names to show history.

**5. Trade corridors simplify.**
Routes with constant travel push toward pronounceable, shared-dialect
names. Border regions show hybrid spelling, softened consonants.

**6. Isolation preserves archaic forms.**
Remote communities sound archaic and "out of place" to outsiders.
This is correct. Their names are older. They kept what others changed.

**7. Personal names show kin and profession.**
Before surnames: Given + father's name or Given + trade. These fossilise
as surnames over generations. Fletcher, Cooper, Brewer are occupational
surnames. Smith and Miller are everywhere because the trades were everywhere.

**8. Titles emerge from function.**
Wheat-Reeve. Stonewarden. Tidekeeper. Not symbolic or moral titles.
Leaders are titled by role or achievement, not ideology.

**9. Religious names reflect local ecology.**
Deities, saints, spirits tied to weather, landforms, and animals the
culture actually interacts with. A sea god has a name that evokes water.
A forest spirit has a name that evokes trees. Temple names mirror these.

**10. War and disaster create break points.**
Post-catastrophe settlements are renamed to mark survival or origin.
Include at least one "New X" or "Rebuilt Y" in any long-established region.

**11. Scripts matter.**
Low literacy = spelling drift. Clerical culture = standard forms freeze early.
Decide literacy rate before naming anything that would appear in documents.

**12. No retroactive justification.**
Names arise from convenience, habit, mispronunciation, accident. Do not
give a settlement a name that secretly means something relevant to the plot
unless this is tied to documented elite ideology.

---

## ADDITIONAL LOCAL LOGIC

**Local identity persists.** External authorities rename on official documents.
Daily speech stays local until enforcement makes the new name the only safe choice.

**Functional over symbolic.** Names solve navigation and taxation.
A name that reduces clarity or utility will not be widely adopted.

**Cultural logic is internal.** Do not retrofit later moral frameworks.
Describe systems as they ran, not as current viewers prefer.

**Contact zones show gradients.** Ports, markets, border towns naturally
mix names and customs. Interior settlements are conservative.
Show the gradient; don't make the interior suddenly cosmopolitan.

---

## WHEN MULTICULTURAL NAMES ARE JUSTIFIED

The test: would documented historical contact make this plausible?

- A village in dense woodland: local names only
- A port on a major trade route: mixed names, hybrid spellings, foreign surnames
- A post-conquest settlement: layered names from multiple languages
- A pilgrimage site: names from multiple religious traditions

Do not apply modern multicultural naming patterns to pre-contact societies.
This breaks world coherence and signals anachronism.

---

## OCCUPATIONAL NAMING — REFERENCE

Common occupational surnames and their trade origin:

| Surname | Trade |
|---------|-------|
| Fletcher | Arrow-maker |
| Cooper | Barrel-maker |
| Brewer / Brewster | Beer-maker |
| Smith / Smithson | Metal-worker |
| Miller / Mills | Grain mill operator |
| Thatcher | Roof-thatcher |
| Mason | Stone-worker |
| Weaver | Cloth-weaver |
| Carter | Cart driver |
| Ward / Warden | Guard or keeper |
| Fowler | Bird-catcher |
| Hunter | Game hunter |

One prominent family's name dominates a small village. Where two families
are prominent, both surnames appear frequently with slight variants
(Smith, Smithson, Smythe).

---

## NPC DESIGN PRINCIPLES (WFRP/Urban Cartographer)

NPCs are defined by function and survival need. They are not stepping stones.
They resist being used as plot devices. They have their own purposes.

**Core definition per NPC:**

| Element | What it provides |
|---------|-----------------|
| **Role in local system** | Guard, merchant, priest, beggar, courtier. Behaviour maintains position. |
| **Concrete motivation** | Food, money, favour, protection, reputation, avoiding trouble. Not abstractions. |
| **Primary flaw** | Cowardice, superstition, bitterness, distrust. Flaws are actionable in play/story. |
| **Fragment of knowledge** | Rumours, partial truths, suspicions. Not omniscient. |
| **Speech pattern** | Short, practical, local. Implicit threat or caution. No speeches. |
| **Physical tell** | One or two details implying history. Worn seams, labour-marked hands, a scar. |
| **Secret** | Something they're protecting. Not necessarily connected to the main plot. |

**NPCs resist being stepped on.** They answer questions reluctantly.
They demand something in return. They redirect blame. They try to avoid
involvement. Player/protagonist agency drives plot; NPCs do not deliver it.

---

## NPC BLOCK FORMAT (Urban Cartographer)

```
Name, Age (Role)
Skills: [3 relevant skills]
Talents/Traits: [2 defining traits, preferably including a flaw]
Gear/Purse: [Specific items; money amount]
Attitude: [1 line, present tense behaviour]
Secret: [Actionable; includes where and how to discover it]
Hook: [1-2 concrete outcomes in "if X, then Y" format]
Grit: [2-3 physical/sensory details that ground them as real]
```

---

## LOCATION BLOCK FORMAT (Urban Cartographer)

```
Name (District/Area)
Exterior: [2 concrete sensory details]
Entry: [Access method and condition]
Interior: [Layout and condition]
Security: [Hardware, routines, animals, alarms — at least one]
Staff/Owner: [Role and vice]
Trade: [What is bought/sold; pricing tendency]
Secret: [What, where, and how to reach it]
Hooks: [If X, then Y outcomes — at least two approaches implied]
```

---

## SENSORY PRIORITY (Urban Cartographer)

When describing locations:

1. **Sight first** — structure, damage, defences, wear
2. **Sound second** — hinges, dogs, water, distant arguments
3. **Smell sparingly** — one precise, useful odour per scene

Smell is the most powerful and should be rationed. When used, make it specific
("tallow candles and damp wool") not generic ("it smelled bad").

---

## SOCIAL COHERENCE AND CHARACTER BEHAVIOUR

When depicting characters within a historical or fantasy world, behaviour
must emerge from the internal logic of that world's economic, kinship,
and religious systems — not from contemporary political frameworks.

**Household economy over identity:**
In agrarian and pre-industrial settings, labour roles matter more than
categories of identity. A person who works the fields, tends animals,
or manages craft tasks earns pragmatic acceptance based on contribution.
Status attaches to function. Deviance from expected behaviour is noticed
when it costs the community something economically, not ideologically.

**Public/private distinction:**
What is privately known and what is publicly acknowledged differ in every
pre-modern society. The social cost of naming a thing is distinct from
the social cost of doing it. Represent both layers. People know things
they will not say in formal settings.

**Dress as function:**
Clothing follows climate, available materials, and work requirements.
Distinction comes through grooming, ornament, and posture rather than
through modern conceptions of gender presentation. A person dressed
"against type" in a working environment is dressed for work.

**Social friction is local, not ideological:**
Conflicts arising from non-conforming behaviour emerge from property
inheritance, guild rules, marriage alliances, and labour arrangement —
not from abstract political positions. Ground every conflict of this
type in a specific material consequence.

**Urban/rural gradient:**
Towns with active trade see wider variation and informal subcultures.
Remote villages depend on conformity for collective survival. Show the
gradient. Do not make the interior cosmopolitan without documented
contact and economic integration.

**Occupational and kinship naming (extended):**
- In small communities, one or two surnames dominate. Many people share
  the same family name with slight variants (Smith, Smythe, Smithson).
- Nicknames based on trade or physical characteristic are common and
  often displace formal names in daily use.
- Self-presentation affects nicknames more than formal records.
  Formal records follow administrative convention regardless.

**Religion as boundary:**
Belief systems define what is permissible, what is formal, and what is
ignored. Some traditions have established roles or ceremonial spaces for
social non-conformity; others do not. Establish internal religious logic
and apply it consistently. Do not import external moral frameworks.

---

## TEMPORAL CONVENTIONS

**Present tense** for current state of a location or NPC.
**Past tense** for origins and causes (1-2 sentences only).

Do not speculate about future outcomes. Express potential outcomes as
conditional hooks: "If the players antagonise the Guild Master, the
warehouse fire investigation is reassigned to the city watch within a week."

---

## ECONOMY AND NUMBERS

Prices as tendencies unless precision matters: "buys at 30% of value,
sells at 180%." Distances and sizes explicit. Money in specific amounts.

Round numbers undermine credibility. "47 guilders" is more real than "50 guilders."

---

## TONE REGISTER (WFRP)

For description in this setting style:

- Detached, observational, world-weary through detail (not through commentary)
- Misery as default state, not tragedy
- Institutions matter more than individuals
- Corruption is routine, not exceptional
- No moral commentary. Describe mechanisms and incentives.

Replace personality adjectives with motives:
```
✗  He is greedy and cruel.
✓  He controls the grain supply and uses enforcement to maintain it.
```

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, genre confirmed
  (fantasy / historical / worldbuilding-heavy), and weakness identified
  (names feel generic / world lacks coherence / NPCs are props / locations
  feel interchangeable). Establish the task type (naming / NPC / location /
  coherence check) before proceeding. Apply the twelve naming rules as the
  primary filter.

- `superpowers-bookworm:world-building` — arrives after world-building establishes the setting's
  geographic, historical, and cultural framework. Receive: region type, contact
  history (isolated / trade route / post-conquest / pilgrimage site), literacy
  level, and any language families already in use. Apply naming rules 1-6
  (geography, language roots, shortened forms, conquest layers, trade routes,
  isolation) as hard constraints. Do not generate names that contradict the
  world-building framework already established.

- `superpowers-bookworm:character-depth-engine` — arrives with: character's region, social class,
  era, trade or family role, and any relevant kin structure. Apply naming
  rules 7 (personal names show kin and profession) and 2 (language roots
  stay consistent). Return: a name with documented etymology, a shortened
  informal version if applicable, and any occupational surname logic. Do not
  generate symbolic names. Do not assign meaning to the name retrospectively
  unless elite ideology is already established in the world.

**Sends to:**

- `superpowers-bookworm:character-depth-engine` — after naming, return: the full formal name,
  the shortened local version, any occupational or kinship marker embedded
  in it, and any naming-layer that implies history (conquest, trade route
  contact, religious influence). These details feed directly into the
  character's implied past and network sections.

---

## WHEN CALLED

1. Ask: **naming** (specific name needed), **NPC** (character generation),
   **location** (place description), or **coherence check** (does this fit)?
2. For naming: establish language family and geographic context first.
3. For NPCs: use the block format. Start with role and flaw.
4. For locations: use the block format. Include at least one secret and two hooks.
5. For coherence: identify the specific rule the existing name/detail may violate,
   then offer a fix or justification.
