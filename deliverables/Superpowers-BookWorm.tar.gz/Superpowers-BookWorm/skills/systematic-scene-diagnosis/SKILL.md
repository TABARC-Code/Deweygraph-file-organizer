---
name: systematic-scene-diagnosis
description: Use when a scene, chapter, or passage isn't working, before attempting any rewrite or revision. Also triggers on: "this scene feels flat", "something's wrong with this chapter", "the opening doesn't work", "the dialogue feels off", "the pacing is wrong", "rewrite this scene".
---

# Systematic Scene Diagnosis

## Iron Law

`NO REWRITES WITHOUT ROOT CAUSE DIAGNOSIS FIRST`

## Core Idea

A scene that isn't working has a diagnosable root cause. Random rewrites produce different problems, not solutions. Identify the root cause before touching a word.

## Four Phases

### Phase 1 — Root Cause Investigation

Before attempting any rewrite:

1. Read the scene without trying to fix it. List what is wrong. Not "it's boring" — specific: "the protagonist's goal is not established in the first paragraph", "the scene ends at the same emotional level it began", "the dialogue has no subtext".
2. Check the scene outline (if one exists). What was this scene supposed to accomplish? Is it accomplishing it? If there's no outline, that's the root cause — go to `superpowers-bookworm:outline-driven-writing`.
3. Check the scene's position in the story. Is it at the right point in the arc? Is it doing a scene-function (setup, complication, reversal, climax, resolution) or is it scaffolding that was never removed?
4. For scenes with multiple problems: gather evidence from the full list before forming hypothesis. The list of symptoms is not the root cause. The root cause is what generates multiple symptoms.

### Phase 2 — Pattern Analysis

Find scenes in the same manuscript (or a comparable work) that accomplish what this scene is trying to accomplish. What is the structural difference? List every structural difference, however small.

### Phase 3 — Hypothesis and Testing

Form one specific hypothesis: "This scene fails because [specific cause] — as evidenced by [specific symptoms]." Make the smallest possible structural change to test the hypothesis. Verify before adding more changes.

### Phase 4 — Revision

Fix the root cause. One change at a time. If after three significant structural attempts the scene still fails, stop and question the scene's place in the structure — not the scene itself. Discuss with the author before attempt four.

## Red Flags

- "Quick rewrite for now, diagnose later"
- "Just try changing the opening and see if it feels better"
- "I don't fully understand why it isn't working but maybe this will help"
- "Each rewrite reveals a new problem" — architectural problem; the scene doesn't belong in the structure where it sits
- "Third failed rewrite attempt" — stop and question the structure

## When Redirected by the Author

These signals mean you assumed without diagnosing:

- **"Is that really the problem?"** — you assumed without diagnosing
- **"Why does that change help?"** — you proposed a fix without establishing cause
- **"We're going in circles"** — your hypothesis is wrong; return to Phase 1

## Cross-Reference Network

**Called by:**
| Skill | When | What is received |
|---|---|---|
| `superpowers-bookworm:requesting-editorial-review` | When structural or scene-level issues are found in the editorial review | Issue description with location |
| `superpowers-bookworm:receiving-editorial-feedback` | Before any revision — diagnose root cause first | Feedback signal with symptom description |
| `superpowers-bookworm:receiving-manuscript-feedback` | When signal feedback identifies scene failures | Scene with identified failure |
| `superpowers-bookworm:outline-driven-writing` | When draft exceeds or contradicts outline and cause isn't clear | Draft vs outline discrepancy |
| `superpowers-bookworm:author-craft-compass` | When scene failure is identified as the author's primary craft challenge | Scene failure mode description |

**Calls out to:**
| Skill | When | What is passed |
|---|---|---|
| `superpowers-bookworm:outline-driven-writing` | When diagnosis reveals no outline existed — root cause found | Scene requiring outline before revision |
| `superpowers-bookworm:plot-architecture` | When diagnosis reveals a structural (act-level) problem, not a local scene problem | Scene's arc position and structural symptom |
| `superpowers-bookworm:character-depth-engine` | When diagnosis reveals the character's behavior doesn't arise from their psychology | Character name and the behavior in question |

**Returns:**
- Root cause diagnosis (Phase 1–2 findings)
- Specific hypothesis ("this scene fails because X, evidenced by Y")
- Smallest structural change to test
- Revised scene (after confirmed root cause fix)
