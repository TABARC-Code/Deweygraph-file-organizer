---
name: author-craft-compass
description: >
  Use when an author wants to identify which craft skills their project needs,
  understand how skills combine and influence each other, or find the right
  entry point for their genre, stage, or weakness. Triggers on: "what skills
  do I need?", "where do I start?", "I'm writing a [genre]", "my weakness is
  [X]", "how do I improve my [X]?", "what should I work on?", or any request
  to navigate or understand the Superpowers-BookWorm craft system. Also invoke
  whenever a genre master skill is activated — this compass identifies which
  compatible craft skills should run alongside it.
---

# Author Craft Compass

The craft routing and skill-influence navigator for the Superpowers-BookWorm
system. Every significant writing project benefits from multiple skills working
together. This compass identifies which skills you need, in what order, and
which unexpected combinations will strengthen your work.

---

## Step 1 — Author Profile Assessment

Ask these five questions before making any routing recommendation. One question
per message; do not combine them.

**1. Genre and subgenre**
What are you writing? (Western, historical fiction, horror, grimdark/military,
mystery/crime, fantasy, science fiction, literary fiction, biography, memoir,
self-help, workbook, textbook, or something that spans categories)

**2. Project stage**
Where are you in the project? (Concept only / Story bible exists / Outline
complete / Actively drafting / In revision / Near completion)

**3. Core craft strength**
What do you do well? (Character work, plot/structure, prose voice, world-
building, dialogue, pacing, research)

**4. Identified weakness**
What consistently gives you trouble? (Same options as above, or: continuity,
authenticity, making prose sound human, historical accuracy, genre discipline,
pacing under pressure, revision discipline)

**5. Immediate need**
What do you need to do right now? (Design the story / Build a character /
Fix a broken scene / Draft the next chapter / Revise completed work / Understand
my genre better / Polish and finish)

After receiving answers: return the Author Profile Summary (genre, stage,
strength, weakness, immediate need) and proceed to routing.

---

## Step 2 — The Six Core Craft Principles

These principles emerge from the convergence of multiple genre and craft
traditions. They apply regardless of genre. Before routing to specific skills,
confirm which principles the author is already applying and which need attention.

**Principle 1: Research precedes writing.**
Every significant factual claim — period accuracy, genre convention, historical
detail, technical fact — must be verified before it appears in prose. This is
not a phase; it is a permanent posture. Fiction that outruns research produces
anachronism, stereotype, and broken reader trust. What you don't know shows.

**Principle 2: Constraint generates story.**
What characters cannot do, cannot say, cannot know drives conflict more
reliably than what they can. Social codes, period limitations, vocabulary
discipline, moral frameworks, genre rules, physical realities — these are not
restrictions on creativity. They are its architecture. A character liberated
from all constraint has nothing at stake.

**Principle 3: Specificity defeats generality.**
A generic character, object, or voice can exist in any era and therefore
belongs to none. The era-specific detail, the vocabulary fingerprint, the
named historical constraint, the particular weapon model, the exact coin
denomination, the period smell — these place a story in its time and make it
real. Generality is the tell of a writer who didn't look closely enough.

**Principle 4: Voice is earned through discipline.**
Authentic voice requires systematic elimination of synthetic patterns.
Vocabulary bans, structural prohibitions, multi-pass audit loops, and read-
aloud tests are not optional extras — they are the mechanism. Voice without
discipline is ventriloquism. The writer who "knows their voice" but hasn't
tested it against a constraint has not yet found it.

**Principle 5: Audit before proceeding.**
No chapter, scene, or passage moves forward without verification. Continuity,
period accuracy, voice consistency, structural integrity, and genre discipline
are checked systematically, not assumed. The cost of catching errors at the
scene level is low. The cost of discovering them at the manuscript level is
structural revision.

**Principle 6: Character carries theme.**
Theme is never stated; it lives in what characters do when the cost is highest.
The character's body, choices, and silences carry the story's meaning. Direct
statement of theme is always a revision target. What a character would die for,
refuse, and betray tells the reader everything the author believes about the
story's central question.

---

## Step 3 — Genre-to-Skill Cluster Map

Match the author's genre to their primary skill cluster. The **primary** skill
is the genre master. **Required alongside** skills are non-negotiable companions
— the genre master will not function at full strength without them. **Influence
skills** deepen and complicate the work; apply in order of identified weakness.

### Western Fiction

**Primary:** `superpowers-bookworm:western-fiction-master`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:historical-fiction-master` | Period accuracy, research methodology, sensory texture; the Western is a period genre and must meet historical fiction's accuracy standards |
| `superpowers-bookworm:continuity-verification` | Firearms dates, legal institutions, geography — one anachronism breaks reader trust |
| `superpowers-bookworm:character-depth-engine` | Lawmen, outlaws, settlers require contradiction and wound — archetype without psychology is caricature |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Dialogue feels false or theatrical | `superpowers-bookworm:pov-and-voice-engine` |
| Pacing slows in the non-action scenes | `superpowers-bookworm:hook-and-tension-system` |
| Prose sounds generic or AI-generated | `superpowers-bookworm:humanizer` |
| Violence lacks physical reality | `superpowers-bookworm:fear-and-emotion-system` |
| Minority and women characters feel thin | `superpowers-bookworm:character-development` (load western-fiction-master subskill 07 first) |

---

### Historical Fiction

**Primary:** `superpowers-bookworm:historical-fiction-master`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:world-building` | The historical world must be built with the same discipline as invented worlds |
| `superpowers-bookworm:continuity-verification` | Historical facts, period accuracy, character knowledge states |
| `superpowers-bookworm:character-development` | Historical constraint must press against a fully realized inner life |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Period feels like costume, not lived reality | `superpowers-bookworm:prose-craft` (sensory specificity section) |
| Research is overwhelming the story | `superpowers-bookworm:plot-architecture` (returns story to character function) |
| Characters think and speak like modern people | `superpowers-bookworm:pov-and-voice-engine` (period voice section) |
| Prose feels synthetic | `superpowers-bookworm:human-prose-style` |
| Western-era setting specifically | `superpowers-bookworm:western-fiction-master` |

---

### Horror and Dark Fiction

**Primary:** `superpowers-bookworm:horror-craft-module`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:fear-and-emotion-system` | The taxonomy of fear and its physical mechanics — horror without this is shock, not dread |
| `superpowers-bookworm:hook-and-tension-system` | Every chapter ending must escalate; tension is the engine of horror |
| `superpowers-bookworm:character-depth-engine` | Readers fear for characters they care about — fear requires investment |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Horror becomes numbing rather than escalating | `superpowers-bookworm:systematic-scene-diagnosis` |
| Villain lacks menace or motivation | `superpowers-bookworm:character-psychology-engine` |
| Atmosphere thin | `superpowers-bookworm:world-building` |
| Pacing too relentless — no release | `superpowers-bookworm:plot-architecture` |

---

### Mystery and Crime Fiction

**Primary:** `superpowers-bookworm:mystery-crime-module`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:plot-architecture` | Clue architecture, information economy, and fair-play structure require architectural planning |
| `superpowers-bookworm:character-depth-engine` | The detective and the villain both need full psychological profiles — the mystery lives in who they are |
| `superpowers-bookworm:continuity-verification` | Clue planting, suspect knowledge states, and timeline integrity are continuity problems |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Detective lacks distinctive voice | `superpowers-bookworm:pov-and-voice-engine` |
| Tension drops between set-pieces | `superpowers-bookworm:hook-and-tension-system` |
| Villain lacks genuine motivation | `superpowers-bookworm:character-psychology-engine` |
| Period setting | `superpowers-bookworm:historical-fiction-master` |

---

### Fantasy (Epic, Urban, Grimdark)

**Primary:** `superpowers-bookworm:genre-craft` (Fantasy section) + `superpowers-bookworm:world-building`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:worldbuilding-naming-engine` | Names and NPCs must have cultural and linguistic coherence |
| `superpowers-bookworm:plot-architecture` | Epic scale requires airtight structural planning |
| `superpowers-bookworm:character-development` | The world serves the characters — character profiles must precede world-building |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Grimdark voice specifically | `superpowers-bookworm:military-gothic-voice` |
| Magic system too convenient | `superpowers-bookworm:systematic-scene-diagnosis` (constraint audit) |
| Characters feel lost in the world | `superpowers-bookworm:character-depth-engine` |
| World-building overwhelming story | `superpowers-bookworm:outline-driven-writing` |

---

### Grimdark and Military Dark Fiction

**Primary:** `superpowers-bookworm:military-gothic-voice`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:character-depth-engine` | The body-as-moral-register principle requires characters with genuine wounds and thematic weight |
| `superpowers-bookworm:prose-craft` | Sentence-level precision is structural, not decorative, in this voice |
| `superpowers-bookworm:pov-and-voice-engine` | Close-third interiority and FID are technical requirements of the form |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Prose sounds generic despite dark content | `superpowers-bookworm:humanizer` |
| Bleakness without theme — nihilism | `superpowers-bookworm:plot-architecture` |
| Dialogue lacks subtext | `superpowers-bookworm:systematic-scene-diagnosis` |
| Setting lacks specificity | `superpowers-bookworm:world-building` |

---

### Literary Fiction

**Primary:** `superpowers-bookworm:genre-craft` (Literary Fiction section) + `superpowers-bookworm:prose-craft`

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:pov-and-voice-engine` | Interiority is the primary vehicle of literary fiction |
| `superpowers-bookworm:character-depth-engine` | Character arc and wound-to-theme connection must be complete |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Prose sounds AI-generated or generic | `superpowers-bookworm:human-prose-style` |
| Structure too loose | `superpowers-bookworm:plot-architecture` (literary models section) |
| Theme stated rather than embodied | `superpowers-bookworm:character-depth-engine` |

---

### Biography, Memoir, and Narrative Nonfiction

**Primary:** `superpowers-bookworm:genre-craft` (Biography/Memoir section)

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:character-development` | The subject is a character; the profile process applies even with a real person |
| `superpowers-bookworm:prose-craft` | Nonfiction still requires scene construction, pacing, and dialogue management |
| `superpowers-bookworm:continuity-verification` | Factual accuracy is a continuity problem; dates, names, and sequences must be verified |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Narrative arc missing | `superpowers-bookworm:plot-architecture` (Nonfiction Arc section) |
| Voice sounds too formal | `superpowers-bookworm:humanizer` |
| Research overwhelming the narrative | `superpowers-bookworm:story-brainstorming` (scope and gist) |

---

### Self-Help, Workbooks, and Instructional Works

**Primary:** `superpowers-bookworm:genre-craft` (Self-Help / Workbook / Textbook sections)

**Required alongside:**
| Skill | Why |
|---|---|
| `superpowers-bookworm:plot-architecture` (Nonfiction Arc) | Reader transformation requires structural arc — where they begin and end |
| `superpowers-bookworm:prose-craft` (Nonfiction section) | Clarity, active voice, and paragraph discipline are non-negotiable |

**Influence skills (apply by weakness):**
| Weakness | Skill |
|---|---|
| Voice sounds robotic or AI-generated | `superpowers-bookworm:humanizer` |
| Reader engagement drops | `superpowers-bookworm:hook-and-tension-system` |

---

## Step 4 — Craft Strength to Influence Map

Your strongest area tells you what to invest in next. The influence skill is not
the same as your strength — it is what will deepen and complicate it. A writer
who is strong in only one area is a writer with a dominant skill and a blind spot.

| Core strength | Your blind spot | Influence skill to add |
|---|---|---|
| Character work | Plot may not serve character; scenes may meander | `superpowers-bookworm:plot-architecture` — scene function test disciplines character-driven work |
| Character work | Interiority may crowd out external story | `superpowers-bookworm:hook-and-tension-system` — pacing around the interiority |
| Plot and structure | Characters may be plot functions rather than people | `superpowers-bookworm:character-depth-engine` — wound and lie structure |
| Plot and structure | Prose may be utilitarian | `superpowers-bookworm:prose-craft` — voice and rhythm |
| Prose and voice | Structure may be absent under beautiful prose | `superpowers-bookworm:outline-driven-writing` — enforces the scene spec |
| Prose and voice | Prose may drift from character consciousness | `superpowers-bookworm:pov-and-voice-engine` — POV penetration depth |
| World-building | Characters may live in the world without driving it | `superpowers-bookworm:character-development` — character precedes world |
| World-building | Story may stall while world expands | `superpowers-bookworm:plot-architecture` — scene function disciplines the world |
| Dialogue | Dialogue may be unanchored in body and psychology | `superpowers-bookworm:character-depth-engine` — lie and wound driving speech |
| Dialogue | Scenes may exist only for conversation | `superpowers-bookworm:systematic-scene-diagnosis` — scene function test |
| Research | Research may crowd out fiction | `superpowers-bookworm:story-brainstorming` — gist and scope discipline |
| Research | Research may stay in the writer's notes | `superpowers-bookworm:prose-craft` — sensory detail, telling object |

---

## Step 5 — Craft Weakness to Priority Map

Your weakness tells you which skill to load before the next session.

| Identified weakness | First skill to load | Second skill |
|---|---|---|
| Characters feel flat or unmotivated | `superpowers-bookworm:character-depth-engine` | `superpowers-bookworm:character-psychology-engine` |
| Plot feels aimless or scenes don't connect | `superpowers-bookworm:plot-architecture` | `superpowers-bookworm:outline-driven-writing` |
| Prose sounds generic or AI-generated | `superpowers-bookworm:humanizer` | `superpowers-bookworm:human-prose-style` |
| Prose sounds AI-generated specifically in fiction | `superpowers-bookworm:human-prose-style` | `superpowers-bookworm:prose-craft` |
| Pacing is off — too fast or too slow | `superpowers-bookworm:hook-and-tension-system` | `superpowers-bookworm:systematic-scene-diagnosis` |
| World feels thin or unconvincing | `superpowers-bookworm:world-building` | Genre master for your period or setting |
| Dialogue feels unnatural or expository | `superpowers-bookworm:pov-and-voice-engine` | `superpowers-bookworm:prose-craft` |
| Continuity errors accumulating | `superpowers-bookworm:continuity-verification` | `superpowers-bookworm:managing-writing-projects` |
| Historical or period detail feels wrong | `superpowers-bookworm:historical-fiction-master` | `superpowers-bookworm:western-fiction-master` (if Western) |
| Voice drifts between chapters | `superpowers-bookworm:pov-and-voice-engine` | `superpowers-bookworm:human-prose-style` |
| Scenes don't work but I can't see why | `superpowers-bookworm:systematic-scene-diagnosis` | `superpowers-bookworm:outline-driven-writing` |
| Fear / tension scenes lack power | `superpowers-bookworm:fear-and-emotion-system` | `superpowers-bookworm:hook-and-tension-system` |
| Genre conventions not being met | `superpowers-bookworm:genre-craft` | Genre master for your specific genre |
| Character names and world naming incoherent | `superpowers-bookworm:worldbuilding-naming-engine` | `superpowers-bookworm:world-building` |

---

## Step 6 — Cross-Skill Compatibility Table

When you invoke any skill, the compatible skills below should run alongside it.
Loading a skill in isolation leaves its most important lever unpulled.

| Active skill | Compatible skills to load alongside |
|---|---|
| `story-brainstorming` | `plot-architecture`, `character-development`, `world-building`, `genre-craft` |
| `story-outlining` | `plot-architecture`, `outline-driven-writing`, `continuity-verification` |
| `drafting-scenes` | `outline-driven-writing`, `prose-craft`, `continuity-verification`, `pov-and-voice-engine` |
| `subagent-driven-drafting` | `continuity-verification`, `requesting-editorial-review`, `prose-craft` |
| `character-development` | `character-depth-engine`, `character-psychology-engine`, `plot-architecture` |
| `character-depth-engine` | `character-development`, `pov-and-voice-engine`, `plot-architecture` |
| `plot-architecture` | `outline-driven-writing`, `hook-and-tension-system`, `character-development` |
| `world-building` | `worldbuilding-naming-engine`, `historical-fiction-master` (period), `genre-craft` |
| `western-fiction-master` | `historical-fiction-master`, `character-depth-engine`, `hook-and-tension-system`, `humanizer` |
| `historical-fiction-master` | `world-building`, `continuity-verification`, `character-development`, `prose-craft` |
| `military-gothic-voice` | `character-depth-engine`, `prose-craft`, `pov-and-voice-engine`, `humanizer` |
| `horror-craft-module` | `fear-and-emotion-system`, `hook-and-tension-system`, `character-depth-engine` |
| `mystery-crime-module` | `plot-architecture`, `character-depth-engine`, `continuity-verification`, `hook-and-tension-system` |
| `humanizer` | `human-prose-style`, `prose-craft`, `pov-and-voice-engine` |
| `human-prose-style` | `humanizer`, `pov-and-voice-engine`, `prose-craft` |
| `pov-and-voice-engine` | `prose-craft`, `character-depth-engine`, `human-prose-style` |
| `hook-and-tension-system` | `plot-architecture`, `systematic-scene-diagnosis`, `fear-and-emotion-system` |
| `prose-craft` | `pov-and-voice-engine`, `human-prose-style`, `outline-driven-writing` |
| `systematic-scene-diagnosis` | `outline-driven-writing`, `plot-architecture`, `receiving-editorial-feedback` |
| `continuity-verification` | `managing-writing-projects`, `drafting-scenes`, `finishing-a-manuscript` |
| `requesting-editorial-review` | `receiving-editorial-feedback`, `systematic-scene-diagnosis` |
| `finishing-a-manuscript` | `continuity-verification`, `managing-writing-projects` |

---

## Step 7 — Compatible Skill Discovery Protocol

When the author is already working with a skill and asks "what else should I
use?", apply this protocol:

**1. Identify the active skill's domain:**
- Process skill (brainstorming, outlining, drafting, finishing) → look for the
  craft skills that serve the current stage
- Genre master (western, historical, horror, mystery, military) → look for craft
  skills that serve the genre's specific demands
- Craft skill (character, plot, prose, voice) → look for skills that address the
  revealed weakness or next layer

**2. Ask what the work currently lacks:**
- "What is not working in the current draft or plan?"
- "What craft area has not been addressed yet?"

**3. Map to the compatibility table (Step 6)** and recommend the 2-3 most
   relevant compatible skills.

**4. Return the recommendation with rationale:**
- Name the skill
- State specifically what it adds that the active skill cannot provide alone
- State when to invoke it (before, during, or after the current skill)

---

## Cross-Reference Network

**Called by:**
| Skill | When |
|---|---|
| `superpowers-bookworm:using-novel-superpowers` | Any time author needs skill routing or project orientation |
| `superpowers-bookworm:story-brainstorming` | When genre identification drives craft routing decisions |
| `superpowers-bookworm:western-fiction-master` | When compatible skills needed alongside the genre master |
| `superpowers-bookworm:historical-fiction-master` | When compatible skills needed alongside the genre master |
| `superpowers-bookworm:military-gothic-voice` | When compatible skills needed alongside the genre master |
| `superpowers-bookworm:horror-craft-module` | When compatible skills needed alongside the genre master |
| `superpowers-bookworm:mystery-crime-module` | When compatible skills needed alongside the genre master |
| Any skill encountering an unfamiliar weakness | When a skill discovers a craft gap outside its domain |

**Calls out to:**
All skills in the system — this compass routes to every other skill.
Routing is determined by the author profile (Step 1) and the genre-to-skill
cluster map (Step 3).

Key routing targets by weakness:
- Scene-level structural weakness → `superpowers-bookworm:scene-construction-engine`
- Opening / pacing weakness → `superpowers-bookworm:hook-and-tension-system`
- Character flatness → `superpowers-bookworm:character-depth-engine`
- Prose sounds synthetic → `superpowers-bookworm:humanizer` then `superpowers-bookworm:human-prose-style`
- POV or voice problems → `superpowers-bookworm:pov-and-voice-engine`

**Data received from callers:**
- Genre, stage, and craft context (where known)
- Specific craft problem being experienced (if diagnostic routing)

**Data returned to callers:**
- Recommended skill cluster with rationale
- Compatibility table entries for the active skill
- Which principles (Step 2) apply most urgently
- Ordering recommendation: which skill to load first, which alongside, which next
