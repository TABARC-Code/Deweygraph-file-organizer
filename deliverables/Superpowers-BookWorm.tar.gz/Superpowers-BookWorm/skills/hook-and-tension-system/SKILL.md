---
name: hook-and-tension-system
description: >
  Applies hook theory to fiction at sentence, scene, chapter, and
  book level. Identifies which hook types suit which genres, diagnoses
  weak openings, and places tension mechanics across a manuscript.
  Draws on Buckham's hook taxonomy and suspense escalation theory.
  Use when an opening isn't working, pacing needs improvement, chapter
  endings feel flat, or a scene lacks forward momentum. Triggers on:
  "opening is weak", "needs a hook", "how do I start this", "pacing
  is slow", "reader won't turn the page", "chapter ending is flat",
  "first line isn't working".
---

# Hook and Tension System

A hook is a question raised in the reader's mind that compels them to read
further. Hooks are subjective. Layer multiple types so if one misses, another
lands.

---

## THE TEN HOOK TYPES (Buckham)

| Hook | What it does |
|------|-------------|
| **Unique Character** | Someone the reader hasn't met before, or a familiar type in an unexpected place |
| **Evocative** | Strong authorial voice; word-painting that demands attention |
| **Foreshadowing with Warning** | Signals danger is coming; raises specific dread |
| **Foreshadowing without Warning** | Hints at future significance without alarm |
| **Surprising/Shocking Dialogue** | Internal or external speech that violates expectation for that character/situation |
| **Totally Unexpected** | Reader genuinely didn't see this coming |
| **Surprising Situation** | Context defies expectation given what we know |
| **Question(s) Raised** | Explicit curiosity gap. Works everywhere. Universal baseline. |
| **Overpowering Emotion** | Visceral emotional impact that demands engagement |
| **Action/Danger** | Immediate physical stakes already in motion |

**Opening line target:** 3+ hooks in thriller/horror. 2+ in literary/romance.
1 hook is the minimum anywhere. 0 hooks is an opening that doesn't work.

**Key principle:** More hooks at key placements = higher tension. Layer,
don't rely on one type doing all the work.

---

## KEY PLACEMENTS (Buckham)

These are the natural stopping points. Readers close books here. Hook at
each or lose them:

| Placement | Why it matters |
|-----------|---------------|
| **Opening sentence** | Buying decision in a bookstore. Slush pile decision for agents. |
| **End of first paragraph** | Confirm the contract. Give them a reason to reach page two. |
| **End of page one** | Last chance before the reading decision is made. |
| **End of chapter three** | Last chance before committed readers commit. |
| **Chapter openings** | Re-earn the reader after a break. Never coast on goodwill. |
| **Chapter endings** | Prevent the book going on the nightstand permanently. |
| **Scene endings** | Prevent skim-reading. Each scene ending is a micro-cliffhanger opportunity. |
| **End of book** | Standalone: earn the resolution. Series: plant the next question. |

**Prologues:** Treat exactly as a first chapter. All hook rules apply.
A dull prologue harms the book regardless of what follows.

---

## THE SCENE GOAL HOOK (Instant hook — Buckham)

State the protagonist's goal early in the scene:

```
[Character] needed/had to/must [concrete action] before [consequence].
```

The words "needed", "had to", "must" create automatic investment.

Remind the reader of the goal 2-3 times during the scene in different
language. This is not repetition — it is tension maintenance.

---

## THE TICKING CLOCK

Add a deadline and tension multiplies. Types:

| Clock type | Example |
|------------|---------|
| **Real time** | Bomb countdown, scheduled execution, closing window |
| **Natural rhythm** | Tide coming in, sunset, changing season |
| **Other people's actions** | Villain arrives before hero does |
| **Progressing disaster** | Bridge collapsing, poison spreading, fire approaching |

**Application:** Establish deadline and consequences at scene open.
Show time passing at intervals. Achieve goal in the final possible moment.
Then show the clock reaching zero — emphasise the margin.

---

## GENRE CALIBRATION

Match hook density and type to what readers of that genre expect:

| Genre | Opening hooks | Dominant types |
|-------|--------------|----------------|
| Thriller | 5-7 | Danger, Foreshadowing+Warning, Shocking Dialogue |
| Horror | 4-6 | Foreshadowing+Warning, Unique Character, Evocative |
| Mystery | 3-5 | Foreshadowing, Question Raised, Unique Character |
| Paranormal romance | 3-4 | Unique Character, Shocking Dialogue, Foreshadowing |
| Category romance | 2-3 | Unique Character, Shocking Dialogue |
| Literary | 1-3 (Evocative dominant) | Evocative, Question Raised |
| YA | 3-4 | Unique Character, Shocking Dialogue, Totally Unexpected |
| Cosy mystery | 2-3 | Foreshadowing, Question Raised, Surprising Situation |
| Children's | 2-3 | Action/Danger, Unique Character, Totally Unexpected |

Too few hooks for the genre = reader disappointment.
Too many hooks for the genre = reader overwhelm.
Wrong hook types for the genre = mismatch with expectation.

---

## EVOCATIVE HOOK — SPECIAL NOTES

The hardest hook to execute. Either works completely or alienates entirely.
Readers will love it or put the book down. No middle ground.

**Use when:**
- The authorial voice is the primary selling point
- The story is literary or character-driven
- Readers of this specific author expect that register

**Avoid when:**
- The story depends on pace and action
- Voice is not the primary draw
- You're using it to compensate for a weak premise

**If using an Evocative hook in the opening:** The entire novel must sustain
that voice. It is a promise. Breaking it after page three loses readers who
stayed for the prose.

---

## CHAPTER ENDINGS — HOOK TYPES

Not every chapter needs a cliffhanger. Vary the approach:

| Ending type | Effect |
|-------------|--------|
| **POV in peril** | Character in immediate danger. Reader must turn page. |
| **New complication** | Goal achieved but new problem emerged. |
| **Revelation** | New information recontextualises what came before. |
| **Question planted** | Something unresolved that demands answering. |
| **Tonal shift** | Change of register — tenderness after violence, dread after relief. |
| **Ticking clock** | Deadline introduced or advanced. |

**Multiple POV books:** After a cliffhanger, switch to a different POV.
This raises tension almost unbearably before resolution. Use once or twice
per book at most. Overuse trains readers to skim.

---

## FIRST LINE DIAGNOSTIC

Run this on any opening line:

1. What hook type(s) are present?
2. How many hooks in total?
3. What question does this raise?
4. When will that question be answered?
5. Does this match the genre's hook density expectation?
6. Is there a reason to read sentence two?

If the answer to question 6 is "not really", the line needs rebuilding.

---

## SCENE OPENINGS AND ENDINGS (Buckham — Part 5)

Scenes are the second most common reading stop after chapter endings.
Hook placement inside scenes keeps readers from skim-reading.

**Scene opening hook:**
Re-establish the character's goal and a source of tension within the
first paragraph of every scene. Readers who take a break mid-chapter
return to the beginning of a scene. If that opening gives them no
reason to continue, they stop there.

The scene opening does not need a multi-hook sentence. One clear goal
and one source of unresolved tension is sufficient. The reader needs
to know what is at stake before reading further.

**Scene ending hook:**
Apply the same logic as chapter endings. The scene's question should
be answered — but incompletely, with a new question attached. 

Avoid ending scenes at a point of neutral equilibrium. End at:
- The moment just before a decision is made (reader must see the decision)
- The moment a new threat is recognised (reader must see the response)
- The moment of a revelation (reader must see the consequence)
- A line of dialogue that demands an answer

**Building within a scene (Buckham):**
Do not front-load all hooks at the scene opening then coast. Reinstate
a hook at the scene's midpoint — a brief reminder of stakes, a background
sound that deepens atmosphere, a new piece of information that shifts
the reader's understanding. Keep the pressure constant, not intermittent.

**Scene-ending examples across genres:**

*Thriller:* "He checked the time. He'd been certain the drive would
take forty minutes. It had taken twenty-two. Which meant someone
knew exactly when he would arrive."

*Horror:* "She got the door locked. She heard him trying the handle.
Then she heard him stop. Then she heard him, very quietly, begin to
whistle."

*Mystery:* "The photograph confirmed everything she'd suspected.
It also put her client at the scene two hours before he said
he'd arrived."

*Romance:* "She'd agreed to tomorrow's dinner to end the conversation.
She'd also written the time down before she left."

---

## END-OF-BOOK HOOKS (Buckham — Part 6)

The final scene of a novel makes a promise about what kind of story
this was and what the reader should carry away from it.

**Standalone novels:**
Resolution must feel earned and complete. The final image or sentence
should resonate with the novel's opening — not repeat it, but rhyme
with it. A reader who reaches the end of a standalone should feel the
story close, not suspend.

Avoid:
- Endings that tie everything too neatly (diminishes the weight of the
  story's complications)
- Endings that leave primary story questions open (violates the contract)
- The double-ending (story concludes, then there is an additional scene
  that undoes the weight of the conclusion)

**Series novels:**
The book's primary conflict must resolve. The character arc or world-
state question does not. The hook into the next book must be:

- **Earned** — emerging naturally from the story just told
- **Specific** — a concrete unresolved question, not general "the journey
  continues" vagueness
- **Character-rooted** — based in who the protagonist now is, not an
  arbitrary cliffhanger

Method: in the final third of the book, give increasing page time to a
secondary character or subplot that will anchor the next volume. By the
time the reader reaches the final scene, they already care about what
happens to it.

**The final sentence:**
Short. Evocative. It should contain one strong noun, verb, or image.
It lands harder than a long sentence. Read it aloud.

```
✓  He walked out. The door, at last, did not lock behind him.
✓  She kept the letter. She would always keep the letter.
✓  The lights were still on in the house when she turned the corner.
   She had not left them on.
```

---

## COMMON PROBLEMS AND FIXES

**Problem:** Opening is technically fine but feels flat.
**Fix:** The question raised is too expected. Give the unique character an
unexpected attribute. Put a familiar type in an impossible situation.

**Problem:** Chapter endings feel resolved.
**Fix:** Find the last moment of genuine tension in the chapter. End there.
Cut the reflection and the summary that follows.

**Problem:** Pacing drags in the middle.
**Fix:** Every scene needs a goal stated early. Run the scene goal hook
diagnostic. If the goal isn't on the page in the first paragraph, it needs
to be.

**Problem:** The opening hooks the reader but chapter two loses them.
**Fix:** Chapter two has no hooks at its key placements. Add at minimum:
a question at the chapter opening and a complication at the chapter ending.

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, genre confirmed,
  and weakness identified as opening not working / pacing slow / chapter
  endings flat / scene momentum missing. Apply genre calibration table first.
  Identify which hook types are absent at key placements before recommending
  changes.

- `superpowers-bookworm:scene-construction-engine` — arrives with: scene ending problem (goal
  achieved / not achieved / partial), scene type, and any new complication.
  Focus on scene-ending hook types and placement. Select hook type based on
  genre and what was just resolved. Do not rebuild the scene.

- `superpowers-bookworm:mystery-crime-module` — arrives with: clue placement requirements and
  information economy state (reader knows more / less than protagonist).
  Clue reveals are information-drop hooks: treat each revelation as a
  Question(s) Raised + Foreshadowing pair. Calibrate density to mystery
  subgenre expectations.

**Sends to:**

- `superpowers-bookworm:fear-and-emotion-system` — when a ticking clock or dread-state hook needs
  atmospheric calibration. Hand off: hook type selected (Foreshadowing with
  Warning / Ticking Clock), target fear state, and scene position. That skill
  handles fear type selection, euphonics, and physical symptom layering.

---

## WHEN CALLED

1. Ask: is this an **opening** (sentence/paragraph), a **scene**, or a
   **chapter ending** problem?
2. Identify which hook types are present in the existing text.
3. Identify which placements are missing hooks entirely.
4. Recommend the 1-2 changes with the highest impact first.
5. Do not rebuild everything at once. Fix the single most broken point,
   then reassess.
