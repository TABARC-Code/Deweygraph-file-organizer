---
name: pov-and-voice-engine
description: >
  Manages point-of-view choices, viewpoint consistency, penetration
  depth, and narrative voice. Applies Card's penetration spectrum
  and the human writing style patterns from the project files.
  Diagnoses head-hopping, POV contamination, and voice flatness.
  Calibrates narrative distance for emotional effect. Includes
  voice-matching protocol for user's existing prose. Triggers on:
  "POV problems", "viewpoint inconsistency", "voice feels wrong",
  "too much head-hopping", "write in my style", "narrative distance
  is off", "sounds too distant", "too close to the character".
---

# POV and Voice Engine

Point of view is not grammar. It is the emotional contract between
narrator and reader. The wrong distance makes everything feel flat
even when nothing else is wrong.

---

## POV OPTIONS (Card)

| Type | What it does | Best use | Trade-off |
|------|-------------|---------|-----------|
| **First person** | Narrator is participant; maximum intimacy | Character-driven, psychological, unreliable narrator | Time-distance problem; constraints on information access |
| **Limited third** | One POV per scene; representational; most common | Almost everything | Requires careful transitions; no free mind-hopping |
| **Omniscient** | Sees all minds and events; narrator above the story | Milieu stories, comic irony, epic scope | Emotional distance; prevents deep identification |
| **Cinematic** | Only what could be filmed; no interiority | Certain thriller styles, deliberate cold effect | Cold, distant; loses interiority entirely |

**Default recommendation:** Limited third. Most emotionally intimate without
first person's constraints. Dominant in contemporary fiction for sound reasons.

---

## PENETRATION LEVELS (Card)

Within limited third, narrative distance is a dial, not a switch:

```
LIGHT PENETRATION         DEEP PENETRATION
(narrator visits mind)    (reader lives inside)
        ←————————————————————→
```

**Light penetration:** Narrator occasionally dips into character thought.
Tags like "he thought" or "she realised" are needed. Some emotional distance maintained.

```
Pete waited. Fifteen minutes, then Nora showed up in a blue dress.
"Do you like it?" she asked.
It looks outrageous, he thought. Like neon woven into cloth.
"Terrific," he said.
```

**Deep penetration:** Reader lives inside character perception. No tags needed.
Everything coloured by their attitude, interpretation, and emotional state.
Most powerful for emotional engagement.

```
Of course she was late. And of course she'd worn something new.
A blue dress. No — not just blue. Vivid blue, the colour of neon
woven into cloth. "Do you like it?" He forced himself to smile. "Terrific."
```

**Cinematic:** No interiority. Actions and speech only.

```
Pete checked his watch. Nora arrived fifteen minutes late in a blue dress.
"Do you like it?"
"Terrific," he said.
```

**Use all three in the same manuscript.** Cool off for recovery beats.
Heat up for climax. A novel written at one penetration level throughout
is a missed opportunity.

---

## COMMON POV FAILURES

**Head-hopping:** Switching POV within a scene without a clear break.
Fix: assign one POV per scene. Mark transitions with line breaks or chapter
breaks. State the new POV character in the first sentence after the break.

**First-person camera-eye:** Narrator describes their own actions from
outside themselves. Impossible.
```
✗  I watched myself reach for the door.
✓  My hand found the door handle before I'd decided to move.
```

**Omniscient contamination in limited third:** Narrator knows things the
POV character cannot.
```
✗  Pete didn't know that Nora had been crying for an hour before he arrived.
✓  Something about her face — the slight redness, the careful composure — 
   made him wonder what had happened before he got there.
```

**Telling over showing in deep POV:** Named emotions instead of experienced ones.
```
✗  She felt a surge of love for him.
✓  The sight of him still did something to her chest that she hadn't found
   a word for after seven years.
```

**Withholding information unfairly:** POV character knows something but
the narration hides it from the reader. Acceptable in first-person mystery
narration with established rules. Unacceptable in limited third.

---

## FIRST PERSON — SPECIFIC ISSUES (Card)

**The time-distance problem:** First-person narrator tells a story that already
happened. They know the ending. This creates unconscious distance.

Fix options:
- Write the story while it's happening (journal format, present tense)
- Commit to the emotional immediacy of past tense and use it deliberately
- Address the distance explicitly: the narrator chooses not to reveal the ending

**Withholding must be justified:** Readers allow a first-person narrator to
withhold information from them only if the narrator also withholds it from
themselves at that point in time. Retroactive secrets are cheating.

**Narrator must have a reason to be telling this:** Even if not stated
explicitly, the implied purpose shapes what gets included, what gets omitted,
and what spin is placed on events.

---

## VOICE COMPONENTS

Voice is the sum of:
- **Diction** — word choice, register, vocabulary level
- **Syntax** — sentence structure, length preferences, clause patterns
- **Rhythm** — how sentences feel when read aloud
- **Attitude** — how the narrator/character relates to what they describe
- **Idiolect** — specific verbal habits, recurring phrases, quirks

The last one is most often missing from generated or edited text. Voice without
idiolect is technically correct but feels generic.

---

## HUMAN WRITING STYLE PATTERNS (project files)

These characteristics signal authentic human authorship. Apply when generating
or editing fiction. They are not errors — they are the texture of genuine voice:

| Pattern | What it does |
|---------|-------------|
| **Inconsistent structure** | Paragraph lengths and rhythms vary without visible pattern |
| **Local coherence errors** | Occasional unclear pronoun or reference. Intentional, sparse. |
| **Personal idiosyncrasies** | Recurring turns of phrase. A voice has habits. |
| **Imperfect grammar** | Sporadic tense shifts, article omissions. Not constant. |
| **Non-linear reasoning** | Ideas jump. Connections implied, not stated. |
| **Variable precision** | Some points over-explained, others barely touched. |
| **Emotional inference** | Tone shifts with subject matter. Bleeds through. |
| **Irregular figurative language** | Metaphors appear without schedule. Not every paragraph. |
| **Mixed lexicon** | Domain jargon + casual colloquial in the same breath. |
| **Hedging and overconfidence** | "Maybe" and "absolutely" both present, unpredictably. |
| **Idiolect markers** | "Anyway", "right", "so yeah", "look" — small verbal tics. |
| **Narrative drift** | Occasional digression serving association rather than argument. |
| **Implicit audience awareness** | Brief direct address, disclaimers, rhetorical questions. |

**Conan Doyle register:** When aiming for this specific tone — distinctive comma
rhythm, medium declarative sentences, expository but alive — apply it to the
syntax patterns as a register constraint, not a word-level instruction.

---

## VOICE MATCHING PROTOCOL

When user provides a sample of their own writing:

1. **Extract from the sample:**
   - Sentence length preference (short punchy / long complex / mixed)
   - Contraction pattern (uses them freely / avoids them / context-dependent)
   - Formality level
   - How opinions surface (stated directly / embedded / suppressed)
   - Characteristic rhythms (read aloud to find these)
   - First/third preference
   - How emotion is handled (shown / told / suppressed / deflected through action)

2. **Apply as hard constraints** to any generation or editing. Not guidelines. Constraints.

3. **Voice-check:** Alternate one sentence from the sample, one from the output.
   Same person? If no, revise.

4. **Do not default to "clean human prose"** — that is still generic. The goal is
   this specific human's prose.

---

## DIALOGUE VOICE DIFFERENTIATION

Each character should have a recognisably different speech pattern:

- Sentence length preference
- Vocabulary level (formal / casual / technical)
- Use of contractions
- Whether they answer questions directly or deflect
- Characteristic phrase or verbal tic
- How they handle uncomfortable silences

If all characters sound the same when dialogue tags are removed, voice
differentiation has failed.

---

## TENSE

**Past tense:** Invisible. Feels immediate despite the apparent distance.
Default for almost all fiction. Readers do not notice it.

**Present tense:** Calls attention to itself. Feels more distant than past
tense in most readers' experience, despite the apparent immediacy. Use when
there is specific narrative reason (urgency, unreliability, literary register).
Not as a default attempt at immediacy.

**Rule:** Whatever you choose, sustain it. Tense drift is one of the most
visible signs of an uncontrolled draft.

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, prose weakness
  identified (POV inconsistent / voice flat / head-hopping / distance wrong /
  character interiority missing). Identify the specific failure type from the
  common POV failures list before recommending changes. If voice-matching to
  the author's own prose is required, request a sample before proceeding.

- `superpowers-bookworm:human-prose-style` — arrives after fiction-specific AI tell removal when
  voice-matching to the user's own prose is required. Provide: voice-match
  protocol output only. Extract the six voice markers (sentence length,
  contraction pattern, formality level, how opinions surface, rhythm,
  emotion-handling method) from the user's sample. Return those as hard
  constraints for the human-prose-style pass. Do not diagnose POV problems
  unless asked.

**Sends to:**

- `superpowers-bookworm:human-prose-style` — when POV and penetration level are confirmed but
  the prose still sounds synthetic. Hand off: penetration level chosen
  (light / deep / cinematic), POV type, and any identified voice markers
  from the user's sample. That skill handles fiction-specific AI tells,
  dialogue differentiation, and interiority reconstruction.

- `superpowers-bookworm:humanizer` — when non-fiction patterns appear in fiction prose
  (rule-of-three symmetry, vague attribution, corporate diction). Hand
  off the passage with fiction context flagged. The humanizer pattern
  library applies first; human-prose-style fiction-specific layer follows.

---

## WHEN CALLED

1. Ask: is this a **POV choice** question, a **consistency** problem, a
   **penetration level** question, or a **voice** problem?
2. For consistency problems: identify the specific failure from the failure list.
3. For penetration level: identify what emotional effect is needed and adjust distance.
4. For voice matching: require a sample before proceeding.
5. Do not diagnose multiple problems simultaneously. Fix the most structural
   one first. POV before voice. Consistency before depth.
