---
name: human-prose-style
description: >
  Detects and removes AI prose patterns from fiction. Fiction-specific
  extension of the humanizer skill, with narrative-voice tells,
  rhythm reconstruction, and dialogue differentiation. Applies the
  Human Writing Style conventions from the project files alongside
  the base humanizer pattern library. Use when fiction sounds
  synthetic, generic, or machine-generated. For non-fiction text,
  use the base humanizer skill instead. Triggers on: "sounds too AI",
  "make it human", "the writing feels synthetic", "remove AI tone",
  "write naturally", "dialogue all sounds the same", "too clean",
  "no voice", "feels generic".
---

# Human Prose Style

This skill extends the base humanizer for fiction. When non-fiction AI
patterns appear in fiction text, route those patterns to `superpowers-bookworm:humanizer` first
(see CROSS-REFERENCES below), then apply this skill's fiction-specific layer.
This skill adds what the humanizer
does not cover: narrative voice, character speech differentiation,
interiority, and the specific tells of AI-generated fiction.

---

## TRIAGE FIRST

Before touching anything, rate the severity:

**Level 1 — Light touch:** A few tells but the voice is mostly intact.
Fix vocabulary, a handful of phrases, one or two rhythm problems.

**Level 2 — Moderate:** Structural patterns present. Voice is missing
but salvageable. Full pass on structure, rhythm, and character voice.

**Level 3 — Full rebuild:** Pure AI output. Generic, balanced, smooth,
voiceless, formulaic. Treat it as raw material, not a draft. Rewrite
from meaning, not from sentence.

State the level before proceeding.

---

## FICTION-SPECIFIC AI TELLS

These are in addition to the base humanizer pattern library:

**Structural tells:**
- Every scene ends with the protagonist reflecting on what they learned
- Emotional states announced before they are shown ("She felt a surge of fear")
- Dialogue is perfectly articulated — no false starts, hedges, or interruptions
- Paragraph lengths are uniform throughout the manuscript
- Action beats and dialogue beats alternate with mechanical regularity
- Every chapter opens with weather description or the character waking up
- All major scenes end on a thematically resonant line about character growth

**Character voice tells:**
- All characters sound like the same person when dialogue tags are removed
- Similes are generic: "like a knife", "cold as ice", "fast as lightning"
- Internal monologue is always coherent and grammatically perfect under pressure
- No character ever misremembers, misinterprets, or thinks something wrong
- Emotional states described as complete and named rather than partial and physical
- Every conversation advances the plot with perfect efficiency

**Rhythm tells:**
- Long sentence followed by short. Short followed by long. Perfect alternation throughout.
- Paragraph-ending sentences always carry a thematic "point"
- No fragments. No run-ons. No grammatically broken lines used for effect.
- All sentences in an action scene are short. All sentences in a reflective scene are long.
  (Mechanical application rather than earned variation.)

---

## THE CORE PROHIBITED CONSTRUCTIONS

Replace all instances of:

| Construction | Replace with |
|-------------|-------------|
| "She felt [emotion]." | Physical symptom of the emotion |
| "He experienced [emotion]." | Behaviour change or physical tell |
| "A wave of [emotion] washed over her." | What the body does, not a metaphor for the emotion |
| "She found herself [doing thing]." | She did the thing. With agency. |
| "His legs carried him toward..." | He walked. He moved. Body parts don't act independently. |
| "She tried to [action]." | She [actioned]. Or she failed to [action]. Not "tried". |
| "[Character] thought to himself/herself" | "[Character] thought" is sufficient. |
| "She couldn't help but [action]." | She [actioned]. Own it. |
| "There was a [something] feeling in his chest." | Specific physical sensation. |
| "She realised that..." | She knew / She understood / Cut the clause and state it. |

---

## DIALOGUE HUMANISATION

**False starts:**
```
✗  "I don't know what you want from me," she said.
✓  "I — look, I don't know what you want."
```

**Incomplete thoughts:**
```
✗  "I wanted to tell you something important," he said.
✓  "I wanted to — it doesn't matter."
```

**Deflection and evasion:**
```
✗  "Are you alright?" she asked.
   "Yes, I'm fine," he replied.
✓  "Are you alright?"
   He looked at his hands. "I should get going."
```

**Character idiolect** — each character needs at least one of:
- A vocabulary register (formal / casual / clipped / expansive)
- A verbal tic or recurring phrase
- A characteristic way of handling questions they don't want to answer
- A sentence-length preference (terse / elaborate)

If character A and character B are interchangeable in dialogue, one of them
does not have a voice yet.

---

## INTERIORITY HUMANISATION

AI interiority is too coherent. People under stress think in fragments,
make wrong connections, fixate on irrelevant details.

**Fragmented thought:**
```
✗  She thought about everything that had gone wrong today and felt overwhelmed.
✓  The tap was still dripping. She'd meant to fix that.
   Her mother. The call. The number she still hadn't returned.
```

**Wrong conclusion (character misreads situation):**
```
✗  She understood immediately that he was lying.
✓  He wasn't looking at her. She took that as confirmation.
   She was wrong. She'd find that out later.
```

**Sensory intrusion into thought:**
```
✗  She thought about what to say next.
✓  She thought about what to say, and the smell of the café
   kept getting in the way.
```

**Emotion distorting logic:**
Grief, fear, and anger make people jump to irrational conclusions.
Let them. Do not correct the character's internal logic in the same
passage where the emotion is present.

---

## NARRATIVE VOICE HUMANISATION

**Vary paragraph length radically.**
One sentence can be its own paragraph. A paragraph of eight sentences
followed by a one-word paragraph changes the entire rhythm of the page.
Use this.

**Allow information out of perfect order.**
Human perception is not organised. The character notices the blood
before they notice the body. The reader gets information in the order
the character encounters it, not in the order it would be clearest.

**Let the narrator have an occasional quirk.**
One vocabulary preference that's slightly unusual for the register.
One type of observation that recurs (the narrator always notices hands,
or always notes the weather with something slightly off about it).

**Permit grammatical choices that establish voice:**
Sentence fragments used for effect.
Comma splices where they serve rhythm.
Occasional colloquial construction in narrative prose.

These are not errors. They are stylistic choices. Use them sparingly
and intentionally.

---

## THE CONAN DOYLE REGISTER

When this specific register is required — formal but alive, expository
but present:

- Medium-length declarative sentences as the baseline
- Cause-effect chaining: "as", "since", "therefore", "consequently"
- Coordination preferred over subordination
- Adjectives only when they add information, not atmosphere
- Detached observational tone; the narrator sees clearly but does not judge
- Misery and corruption as defaults, presented without editorialising

---

## RHYTHM RECONSTRUCTION

Read the passage aloud before revising. Identify:

1. Where it falls into a predictable cadence (same sentence length three times in a row)
2. Where every paragraph ends the same way (with a thematic beat)
3. Where the passage feels like it's being read rather than happening

**Fix by disruption, not by formula.** If three sentences are long,
make the fourth very short. Not because of a rule about short sentences,
but because something needs to stop.

---

## PASS STRUCTURE

For Level 2 and Level 3:

**Pass 1 — Pattern removal:** Hit the prohibited constructions list.
Remove "found herself", "tried to", named emotions. Mark them.

**Pass 2 — Voice installation:** Add idiolect to dialogue.
Fragment the interiority. Allow characters to be wrong.

**Pass 3 — Rhythm:** Read aloud. Break predictable cadence.
Vary paragraph length. One-sentence paragraphs where they earn it.

**Pass 4 — Voice check:** If user provided a sample, apply
voice-matching protocol from `superpowers-bookworm:pov-and-voice-engine` (see CROSS-REFERENCES).

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile and identified weakness
  (prose sounds generic / AI-generated / synthetic in fiction context). Apply this
  skill's fiction-specific layer. For non-fiction AI patterns, route to humanizer first.

- `superpowers-bookworm:prose-craft` — arrives after prose review identifies systematic synthetic
  tells in fiction. Receive: draft passage with specific failures flagged. Apply
  fiction-specific pattern removal and rhythm reconstruction.

- `superpowers-bookworm:pov-and-voice-engine` — arrives after POV and penetration level are
  confirmed but prose still sounds synthetic. Receive: penetration level
  (light / deep / cinematic), POV type, and any voice markers extracted
  from the user's sample. Apply those as hard constraints during the voice-
  installation pass (Pass 2). Do not re-diagnose POV; handle the fiction-
  specific tell removal and rhythm reconstruction only.

**Sends to:**

- `superpowers-bookworm:pov-and-voice-engine` — when voice-matching to the user's own prose
  is required. Hand off: the user's writing sample alongside the text
  to be matched. That skill extracts the six voice markers and returns
  them as hard constraints. Apply those constraints in Pass 2 (voice
  installation) and verify in Pass 4 (voice check).

- `superpowers-bookworm:humanizer` — when non-fiction AI patterns appear in the fiction text
  (pattern list: inflated significance, vague attribution, rule-of-three
  symmetry, corporate diction, formulaic bullet substitution). Flag the
  passage as fiction-context and hand it off. The humanizer's base pattern
  library applies first. Return the output to this skill for the fiction-
  specific pass (interiority, dialogue differentiation, rhythm).

---

## WHEN CALLED

1. Rate severity (Level 1 / 2 / 3) before touching anything.
2. Ask if user has a sample of their own writing for voice-matching.
3. Check whether this is fiction (use this skill) or non-fiction (route to `superpowers-bookworm:humanizer` directly).
4. Do not apply all passes simultaneously on the first output.
   State what pass is being applied and what is being changed.
5. Never rewrite content that is already working. Identify what's
   synthetic, fix it, leave what isn't broken.
