---
name: character-psychology-engine
description: >
  Character psychology engine for wounds, lies, flaws, personas, and
  arc design. Maps characters through the wound/lie/flaw/behaviour/arc
  stack. Use when building character psychology, designing arcs,
  understanding why a character behaves as they do, or diagnosing
  why a character feels flat or motivationally incoherent.
  For full character development including sympathy mechanics,
  emotion amplifiers, and hierarchy, use `superpowers-bookworm:character-depth-engine` — this
  skill provides the psychology stack that feeds into that skill's arc,
  sympathy, and amplifier layers.
---

# Character Psychology Engine

Map every significant character through this chain before plotting their
arc. Each layer explains the next.

---

## THE PSYCHOLOGY STACK

```
WOUND
  The formative damage. One specific event or sustained condition.
  Be concrete. Not "had a hard childhood" but "was abandoned by their
  father at nine years old the week after promising to stay."

LIE
  What the wound made them believe about themselves or the world.
  Not a rational conclusion — a distorted one formed under duress.
  Examples: "I am fundamentally unlovable."
            "People always leave."
            "Showing weakness invites destruction."
            "The world only makes room for people who take it."

FLAW
  How the lie manifests in repeated behaviour. The flaw is the lie
  in action. It is what they do because they believe the lie is true.
  Examples: Pushes people away before they can leave.
            Controls everything to prevent loss.
            Never asks for help, even when help would save them.

BEHAVIOUR
  The specific patterns readers observe on the page. These are the
  symptoms of the flaw. They repeat. They escalate under pressure.
  They are what the character does instead of what they need to do.

PERSONA
  The face they present to the world. Often the opposite of the wound.
  The abandoned person performs independence. The frightened person
  performs fearlessness. The person who believes they are unlovable
  makes themselves indispensable.

DESIRE (external)
  The concrete, external thing they want. Plot-level goal.
  This drives action.

FEAR (internal)
  The psychological condition they are trying to avoid.
  This drives avoidance and shapes choices.
  Desire and Fear should be in direct tension.

ARC OUTCOME
  What happens to the lie by the end:
  - Confronted and abandoned: transformation
  - Confronted and reinforced: tragedy
  - Never confronted: revelation of unchangeable nature
  - Confronted but deferred: the ambiguous ending
```

---

## HOW TO USE THIS

**Building a new character:**
Start with the wound. Everything else flows from it.
Ask: what specific event or condition produced this specific lie?
Verify: does the flaw follow logically from the lie?
Verify: does the desire conflict with the fear?

**Diagnosing a flat character:**
Find where the chain breaks down.
Usually the flaw exists without a wound to explain it, so behaviour
seems arbitrary rather than inevitable.

**Designing the arc:**
Establish what the lie is. Design the story to force a confrontation
with it. The confrontation does not require a resolution — but it
must occur for an arc to exist.

**Building antagonists:**
The psychology stack applies to villains too. The villain's wound
explains their lie. Their lie explains their method. A villain
without a psychology stack is a force of nature, not a character.
Both are legitimate. Know which you're building.

---

## ARC TYPES

| Type | What it means |
|------|--------------|
| **Transformation** | Lie confronted and abandoned. Character genuinely changes. |
| **Unmasking** | True nature revealed. No transformation — revelation. |
| **Environmental shaping** | External forces change who they become. |
| **Refusal** | Cannot or will not change. Tragedy, irony, or cautionary result. |

Arbitrary change without accumulated cause is worse than no change.
Justify transformation with evidence or a specific catalytic event.

---

## QUICK REFERENCE QUESTIONS

When working through a character:

- What is the specific wound? (Not general. Specific.)
- What lie did it produce? (Not rational. Distorted.)
- What behaviour does the lie drive? (Repeated. Escalates under pressure.)
- What do they want? (External. Concrete. Could be photographed.)
- What do they fear? (Internal. Psychological. What they're trying to never feel again.)
- Do desire and fear conflict? (They must.)
- What is their persona? (What face do they show the world?)
- What would cracking the persona reveal?
- What would it take to force a confrontation with the lie?

---

## CROSS-REFERENCES

**Receives from:**

- `superpowers-bookworm:author-craft-compass` — arrives with: author profile, character identified
  as flat or motivationally incoherent, and weakness type (arc unclear / flaw
  without wound / desire-fear not in tension). Run the full psychology stack
  from wound through arc outcome. Return results to author-craft-compass for
  routing to character-depth-engine if sympathy mechanics are also needed.

- `superpowers-bookworm:character-development` — arrives after the Phase 1 character build
  (want/need/wound/lie summary) when the psychology stack needs full
  specification. Receive: the partial psychology summary from character-development.
  Complete all seven layers (wound through arc outcome). Do not duplicate the
  sympathy and arc work that character-depth-engine handles — stop at the
  psychology stack and hand off.

- `superpowers-bookworm:character-depth-engine` — arrives when a quick psychology stack reference
  is needed mid-build or when a character's motivation is being diagnosed.
  Provide the full wound/lie/flaw/behaviour/arc stack. Return it as a
  structured output with all five layers completed. Do not add sympathy
  mechanics, amplifiers, or hierarchy — those live in character-depth-engine.
  Return to that skill after the stack is built.

**Sends to:**

- `superpowers-bookworm:character-depth-engine` — after the psychology stack is complete, return:
  wound (specific event or condition, not general), lie (distorted belief,
  not rational conclusion), flaw (repeated behaviour pattern under pressure),
  behaviour (specific observable tells), and arc outcome (confronted /
  unmasked / shaped / refused). That skill layers sympathy mechanics, emotion
  amplifiers, and character hierarchy on top of this foundation.
