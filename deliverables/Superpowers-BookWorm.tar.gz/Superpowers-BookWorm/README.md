# Superpowers-BookWorm

Superpowers-BookWorm gives your AI writing agent a complete novel-writing methodology, built on composable skills that trigger automatically at the right moments.

It starts from the moment you open a writing session. As soon as it sees you're building a story, it *doesn't* just start generating prose. Instead, it steps back, asks what you're really writing, and works through a structured creative dialogue — refining concept, characters, world, and structure — before a single scene is drafted.

Once the story bible is locked, it builds a beat-by-beat chapter outline you can actually read and sign off on. Then it drafts — scene by scene, with continuity verification at every checkpoint.

**Because the skills trigger automatically, you don't need to do anything special. Your writing agent just has Superpowers.**

---

## Installation

### Claude Code — via Marketplace

Register the marketplace, then install:

```bash
/plugin marketplace add TABARC-Code/Superpowers-BookWorm
/plugin install superpowers-bookworm@Superpowers-BookWorm
```

### Claude Code — Direct (dev / local)

Clone the repo and point Claude Code at it:

```bash
git clone https://github.com/TABARC-Code/Superpowers-BookWorm.git ~/.claude/plugins/superpowers-bookworm
```

Then in Claude Code:
```bash
/plugin install superpowers-bookworm@local
```

### Gemini CLI

```bash
gemini extensions install https://github.com/TABARC-Code/Superpowers-BookWorm
```

### Cursor

In Cursor Agent chat:
```text
/add-plugin superpowers-bookworm
```

Or search for "superpowers-bookworm" in the plugin marketplace.

### OpenAI Codex

Clone and symlink:

```bash
git clone https://github.com/TABARC-Code/Superpowers-BookWorm.git ~/.codex/superpowers-bookworm
mkdir -p ~/.agents/skills
ln -s ~/.codex/superpowers-bookworm/skills ~/.agents/skills/superpowers-bookworm
```

---

## The Writing Workflow

BookWorm uses four core stages — your agent moves through all of them automatically:

### 1. `story-brainstorming`
Activates before any writing begins. Refines your idea through questions one at a time — genre, audience, tone, POV, structure — explores 2-3 story approaches, presents a design section by section for your approval, then saves a complete **story bible**.

### 2. `story-outlining`
Activates after the bible is approved. Breaks the story into a chapter-by-chapter, scene-by-scene outline with scene goals, conflict, outcome, continuity flags, and emotional beats for every entry. Every scene has enough detail to draft from cold.

### 3. `drafting-scenes` / `subagent-driven-drafting`
Activates with the approved outline. Writes scene by scene with a **continuity gate** before marking anything done. The subagent-driven mode dispatches a fresh agent per chapter with two-stage review (continuity compliance, then prose quality) between each.

### 4. `finishing-a-manuscript`
Activates when all scenes are drafted. Runs a final continuity pass, then presents four options: compile & export, prepare for submission, keep as-is, or archive the draft.

**The agent checks for relevant skills before any writing task. These are mandatory workflows, not suggestions.**

---

## What's Inside

### Core Workflow
- **using-novel-superpowers** — Session bootstrap, auto-loaded at start
- **story-brainstorming** — Concept → story bible via structured dialogue
- **story-outlining** — Bible → beat-level chapter/scene outline
- **drafting-scenes** — Execute outline in-session with continuity gates
- **subagent-driven-drafting** — Fresh subagent per chapter + two-stage review
- **finishing-a-manuscript** — Compile, verify, and deliver the completed draft

### Craft Skills
- **character-development** — Want / need / wound / lie profiling before writing any significant character
- **plot-architecture** — Three-act, beat sheet, hero's journey, kishōtenketsu, nonfiction arc
- **world-building** — Geography, magic systems, history, culture, technology, politics
- **genre-craft** — Full technique guides for: literary fiction, science fiction, fantasy, historical fiction, biography, memoir, self-help, workbook, textbook, technical manual
- **prose-craft** — Voice, dialogue, pacing, show vs. tell, description

### Support Skills
- **continuity-verification** — Iron-law gate before claiming any scene complete
- **requesting-manuscript-feedback** — Structured feedback requests for actionable editorial notes
- **receiving-manuscript-feedback** — Triage, diagnose, and revise without losing author voice
- **managing-writing-projects** — File structure, git for writers, draft versioning, multi-book series

### Subagent Prompt Templates
- `drafter-prompt.md` — Context package for chapter drafting agents
- `continuity-reviewer-prompt.md` — Structured continuity compliance review
- `prose-quality-reviewer-prompt.md` — Literary quality review with severity levels
- `story-bible-reviewer-prompt.md` — Bible completeness check before outlining
- `outline-reviewer-prompt.md` — Outline readiness check before drafting

---

## Slash Commands

| Command | What it does |
|---------|-------------|
| `/brainstorm` | Start story development from a concept |
| `/outline` | Create chapter/scene outline from an approved bible |
| `/draft` | Begin drafting from an approved outline |

---

## Genre Coverage

BookWorm's `genre-craft` skill covers the full spectrum:

**Fiction:** Literary, commercial, mystery, thriller, romance, science fiction, fantasy, urban fantasy, grimdark, historical fiction

**Nonfiction:** Biography, memoir, self-help, personal development, workbook, textbook, technical manual

---

## Philosophy

- **Story before prose** — Develop before drafting, always
- **Systematic over spontaneous** — Structured process produces better fiction than inspired chaos
- **Continuity is non-negotiable** — Verify before claiming completion
- **Character drives plot** — Know who they are before you decide what they do
- **Evidence over claims** — The continuity gate is the same as the original Superpowers verification gate, applied to story facts

---

## Contributing

1. Fork the repository
2. Create a branch for your work
3. Test any skill changes with at least one pressure scenario
4. Submit a PR describing the problem you solved

See `CLAUDE.md` for full contributor guidelines.

---

## License

MIT License — see `LICENSE` for details

---

## Related

- [Superpowers](https://github.com/obra/superpowers) — The original coding-agent superpowers plugin that inspired this project
