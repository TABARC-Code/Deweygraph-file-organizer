export type WritingStage =
  | 'ideation'
  | 'outlining'
  | 'drafting'
  | 'prose'
  | 'editorial'
  | 'continuity'
  | 'finishing'

export type WritingProject = {
  title: string | null
  genre: string | null
  stage: WritingStage | null
  branch: string | null
}

declare module 'claude-code' {
  interface PluginState {
    'tabarc-writers': {
      project: WritingProject
    }
  }
}
