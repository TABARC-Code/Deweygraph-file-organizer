import { atom, read, update } from 'claude-code'
import type { Register } from 'claude-code'
import type { WritingProject, WritingStage } from '../types'

const PANE_ID = 'tabarc-writers'

const project = atom(
  { plugin: 'tabarc-writers', key: 'project' } as const,
  { title: null, genre: null, stage: null, branch: null } as WritingProject,
)

// ─── Stage config ────────────────────────────────────────────────────────────

const STAGES: { id: WritingStage; label: string; skill: string; emoji: string }[] = [
  { id: 'ideation',    label: 'Ideation',    skill: 'tabarc-code:story-brainstorming',        emoji: '💡' },
  { id: 'outlining',   label: 'Outlining',   skill: 'tabarc-code:story-outlining',            emoji: '📐' },
  { id: 'drafting',    label: 'Drafting',    skill: 'tabarc-code:drafting-scenes',            emoji: '✍️'  },
  { id: 'prose',       label: 'Prose',       skill: 'tabarc-code:humanizer',                  emoji: '✨' },
  { id: 'editorial',   label: 'Editorial',   skill: 'tabarc-code:requesting-manuscript-feedback', emoji: '🔍' },
  { id: 'continuity',  label: 'Continuity',  skill: 'tabarc-code:continuity-verification',   emoji: '🔗' },
  { id: 'finishing',   label: 'Finishing',   skill: 'tabarc-code:finishing-a-manuscript',     emoji: '🏁' },
]

// ─── Keyword → stage detector ─────────────────────────────────────────────────

function detectStage(text: string): WritingStage | null {
  const t = text.toLowerCase()
  if (/brainstorm|new idea|start.{0,20}story|i have an idea/.test(t)) return 'ideation'
  if (/outline|structure|plot|chapter.{0,10}list|story beat/.test(t)) return 'outlining'
  if (/write.{0,20}scene|draft.{0,20}chapter|next scene|continue.{0,20}story|drafting/.test(t)) return 'drafting'
  if (/polish|humanize|too formal|sounds robotic|natural|voice|prose/.test(t)) return 'prose'
  if (/review|feedback|critique|edit|editorial|what.s wrong/.test(t)) return 'editorial'
  if (/continuity|contradiction|timeline|consistent|check.{0,20}facts/.test(t)) return 'continuity'
  if (/finish|final.{0,10}pass|done.{0,15}draft|ready.{0,10}submit|wrap up/.test(t)) return 'finishing'
  return null
}

// ─── System prompt injection ──────────────────────────────────────────────────

function buildSystemSection(proj: WritingProject): string {
  const stageLine = proj.stage
    ? `Current stage: ${proj.stage.toUpperCase()}`
    : 'Stage: not set — describe what you are working on'

  const projectLine = proj.title
    ? `Project: "${proj.title}"${proj.genre ? ` (${proj.genre})` : ''}${proj.branch ? ` — branch: ${proj.branch}` : ''}`
    : 'Project: not set'

  return `## TABARC-Code Writing Session

${projectLine}
${stageLine}

### Always-Active Prose Directives
- No em dashes (— or ---) as stylistic connectors. Use a period, comma, or restructure.
- Ellipsis max 2 per scene. Only for genuine trailing-off or interrupted thought.
- Contractions natural in dialogue; avoid stiff formality in prose.
- Strong precise verbs over weak verb + adverb.
- Mix short punchy sentences with longer flowing ones. Avoid monotone rhythm.

### Skill Routing
Entry point: tabarc-code:novel-writing-hub
When the user describes a writing task, invoke the matching TABARC-Code skill automatically.`
}

// ─── Main registration ────────────────────────────────────────────────────────

export const register: Register = on => {

  // Session start: register commands, open pane, set status
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'hub',       description: 'Open TABARC-Code novel writing hub' })
    await $.command.register({ name: 'brainstorm', description: 'Start a story brainstorming session' })
    await $.command.register({ name: 'draft',      description: 'Begin or continue a drafting sprint' })
    await $.command.register({ name: 'outline',    description: 'Build or review your story outline' })
    await $.command.register({ name: 'writers',    description: 'Open the TABARC Writers project dashboard' })

    $.ui.status('TABARC Writers ready')
    void $.ui.open({ id: PANE_ID, title: 'TABARC Writers' })

    return next(e)
  })

  // Inject writing context into every system prompt
  on('prompt.compose', async ($, e, next) => {
    const result = await next(e)
    const proj = await read($, project)
    return {
      ...result,
      sections: [
        ...result.sections,
        {
          id: 'tabarc-writers:context',
          text: buildSystemSection(proj),
          scope: 'session' as const,
        },
      ],
    }
  })

  // Detect writing stage from user prompt and update state + status
  on('prompt.submit', async ($, e, next) => {
    const detected = detectStage(e.text)
    if (detected) {
      const proj = await read($, project)
      if (proj.stage !== detected) {
        await update($, project, p => ({ ...p, stage: detected }))
        const stageInfo = STAGES.find(s => s.id === detected)
        $.ui.status(`${stageInfo?.emoji ?? ''} ${detected}`)
      }
    }
    return next(e)
  }).catch(($, e, next) => next(e))

  // /hub command
  on('command.run', { command: 'hub' }, async $ => {
    await $.ui.open({ id: PANE_ID, title: 'TABARC Writers' })
    return {
      text: 'Use `tabarc-code:novel-writing-hub` — describe your project or what you\'re working on and I\'ll route you to the right skill.',
    }
  })

  // /writers command
  on('command.run', { command: 'writers' }, async $ => {
    await $.ui.open({ id: PANE_ID, title: 'TABARC Writers' })
    return { text: 'TABARC Writers dashboard opened.' }
  })

  // /brainstorm command
  on('command.run', { command: 'brainstorm' }, async ($) => {
    await update($, project, p => ({ ...p, stage: 'ideation' as WritingStage }))
    $.ui.status('💡 ideation')
    return { text: 'Use `tabarc-code:story-brainstorming` — tell me your story idea and we\'ll develop it together.' }
  })

  // /draft command
  on('command.run', { command: 'draft' }, async ($) => {
    await update($, project, p => ({ ...p, stage: 'drafting' as WritingStage }))
    $.ui.status('✍️ drafting')
    return { text: 'Use `tabarc-code:drafting-scenes` — share your scene brief or continue from where we left off.' }
  })

  // /outline command
  on('command.run', { command: 'outline' }, async ($) => {
    await update($, project, p => ({ ...p, stage: 'outlining' as WritingStage }))
    $.ui.status('📐 outlining')
    return { text: 'Use `tabarc-code:story-outlining` — describe your premise and I\'ll help build the structure.' }
  })

  // ─── Band above prompt ──────────────────────────────────────────────────────
  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const proj = await read($, project)
    if (!proj.stage && !proj.title) return next(e)

    const { Box, Text, Button } = $.ui.resolve(e)
    const currentStage = STAGES.find(s => s.id === proj.stage)

    return (
      <Box>
        {proj.title && (
          <Text dimColor>{proj.title} · </Text>
        )}
        {currentStage ? (
          <Text>
            {currentStage.emoji} <Text bold>{currentStage.label}</Text>
          </Text>
        ) : (
          <Text dimColor>No stage set</Text>
        )}
        <Text dimColor>  /hub  /brainstorm  /draft  /outline</Text>
      </Box>
    )
  })

  // ─── Project dashboard pane ─────────────────────────────────────────────────
  on('ui.render', { component: 'Pane', requestId: PANE_ID }, async ($, e) => {
    const { Box, Text, Button } = $.ui.resolve(e)
    const proj = await read($, project)

    return (
      <Box flexDirection="column">
        <Text bold>TABARC-Code Writing System</Text>
        <Text> </Text>

        <Text bold>Project</Text>
        <Text>  Title:  {proj.title  ?? '— not set'}</Text>
        <Text>  Genre:  {proj.genre  ?? '— not set'}</Text>
        <Text>  Branch: {proj.branch ?? '— not set'}</Text>
        <Text>  Stage:  {proj.stage  ?? '— not set'}</Text>
        <Text> </Text>

        <Text bold>Workflow Stages</Text>
        {STAGES.map(s => (
          <Box key={s.id}>
            <Text>{s.id === proj.stage ? '▶ ' : '  '}</Text>
            <Text bold={s.id === proj.stage}>{s.emoji} {s.label}</Text>
            <Text dimColor>  →  {s.skill}</Text>
          </Box>
        ))}
        <Text> </Text>

        <Text bold>Commands</Text>
        <Text dimColor>  /hub · /brainstorm · /draft · /outline · /writers</Text>
        <Text> </Text>

        <Text bold>Prose Directives (always active)</Text>
        <Text dimColor>  No em dashes · Ellipsis max 2/scene</Text>
        <Text dimColor>  Strong verbs · Varied sentence rhythm</Text>
        <Text dimColor>  Contractions natural in dialogue</Text>
      </Box>
    )
  })
}
